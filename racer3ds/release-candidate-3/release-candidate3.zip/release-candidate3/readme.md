# Racer 3DS

## Requirements

- A host C/C++ compiler with C++20 support, Python 3, CMake 3.20+, and Make. Ninja is optional.
- [devkitPro `3ds-dev`](https://devkitpro.org/wiki/Getting_Started) and [Project_CTR `makerom`](https://github.com/3DSGuy/Project_CTR/releases) on `PATH`.
- Your own legally obtained US NEPE big-endian `.z64` ROM, SHA-256 `8d6f85683b630e25385619af37197d48279366f6609bb6edc1201ff24c08b757`.

Linux was tested; macOS and Windows via WSL are unverified. The builder detects `/opt/devkitpro`; set `DEVKITPRO` for a different installation.

## Build

From this folder, run:

```sh
./build.sh "/path/to/baserom.z64"
```

A ZIP containing one `.z64` also works. If `baserom.z64` or `baserom.z64.zip` is in this folder, run `./build.sh` without an argument. If needed, use `bash build.sh` instead. The script does not download or install prerequisites.

Outputs: `build-3ds/Racer3DS.3dsx` and `build-3ds/Racer3DS.cia`. To run the game, place the ROM at `sdmc:/3ds/racer/baserom.z64`.

## Rights and limits

No ROM, generated game code, or prebuilt binaries are included. Built binaries contain ROM-derived code; do not redistribute them without the necessary rights. The source includes ROM-analyzed metadata and audio interpreter code with microcode-related provenance; it is not certified clean-room. See `NOTICE` and the component licenses before publication. Audio and physical hardware remain unverified.
