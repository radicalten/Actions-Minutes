#!/usr/bin/env bash
# One-command local build. No ROM, toolchain or game binary is downloaded.
set -euo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)

usage() {
    cat <<'EOF'
Racer 3DS one-command build

  ./build.sh [path/to/baserom.z64-or.zip]

With no argument, the script looks for baserom.z64, then baserom.z64.zip,
in the project folder. A ZIP must contain exactly one .z64 file. You must
supply your own supported, legally obtained US NEPE ROM.

The first build compiles the host tools, recompiles the game and creates:
  build-3ds/Racer3DS.3dsx
  build-3ds/Racer3DS.cia

One-time prerequisites: a host C/C++ compiler, Python 3, CMake 3.20+, Make,
devkitPro 3ds-dev and Project_CTR makerom. See readme.md. The build does not
install software or download anything. Set JOBS=4 to change the default of 2.
EOF
}

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then usage; exit 0; fi
if [ "$#" -gt 1 ]; then usage >&2; exit 2; fi
if [ "$#" -eq 1 ]; then
    INPUT=$1
elif [ -f "$ROOT/baserom.z64" ]; then
    INPUT="$ROOT/baserom.z64"
elif [ -f "$ROOT/baserom.z64.zip" ]; then
    INPUT="$ROOT/baserom.z64.zip"
else
    printf '%s\n' 'ROM not found. Put your own baserom.z64 (or baserom.z64.zip) in this folder,' \
        'or run: ./build.sh "/path/to/your/baserom.z64"' >&2
    exit 2
fi
if [ ! -f "$INPUT" ]; then
    printf 'ROM not found: %s\n' "$INPUT" >&2
    exit 2
fi

JOBS=${JOBS:-2}
case "$JOBS" in ''|*[!0-9]*) echo 'JOBS must be a whole number from 1 to 256.' >&2; exit 2 ;; esac
if [ "${#JOBS}" -gt 3 ] || [ "$JOBS" -lt 1 ] || [ "$JOBS" -gt 256 ]; then
    echo 'JOBS must be a whole number from 1 to 256.' >&2; exit 2
fi

for tool in python3 cmake make cc c++; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        printf 'Missing host tool: %s. See readme.md for installation.\n' "$tool" >&2
        exit 2
    fi
done
if ! python3 -c 'import re,subprocess,sys; s=subprocess.check_output(["cmake","--version"],text=True); m=re.search(r"cmake version (\d+)\.(\d+)",s); sys.exit(0 if m and tuple(map(int,m.groups())) >= (3,20) else 1)' 2>/dev/null; then
    echo 'CMake 3.20 or newer is required. See readme.md.' >&2; exit 2
fi

# Standard devkitPro installs are detected without requiring a separate
# `source devkit-env.sh` command. Custom installations can set both variables.
if [ -z "${DEVKITPRO:-}" ]; then
    if [ -d /opt/devkitpro/devkitARM ]; then
        DEVKITPRO=/opt/devkitpro
    else
        echo 'devkitPro not found. Install 3ds-dev or set DEVKITPRO; see readme.md.' >&2
        exit 2
    fi
fi
DEVKITARM=${DEVKITARM:-"$DEVKITPRO/devkitARM"}
export DEVKITPRO DEVKITARM
export PATH="$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH"
for compiler in arm-none-eabi-gcc arm-none-eabi-g++; do
    if [ ! -x "$DEVKITARM/bin/$compiler" ]; then
        printf 'Missing devkitARM compiler: %s/bin/%s. Check DEVKITARM; see readme.md.\n' "$DEVKITARM" "$compiler" >&2
        exit 2
    fi
done
for tool in arm-none-eabi-gcc arm-none-eabi-g++ picasso bin2s 3dsxtool smdhtool makerom; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        printf 'Missing 3DS build tool: %s. Install 3ds-dev and Project_CTR makerom; see readme.md.\n' "$tool" >&2
        exit 2
    fi
done
for sdk_file in libctru/include/3ds.h libctru/include/citro3d.h libctru/lib/libctru.a libctru/lib/libcitro3d.a; do
    if [ ! -f "$DEVKITPRO/$sdk_file" ]; then
        printf 'Missing devkitPro file: %s/%s. Install 3ds-dev; see readme.md.\n' "$DEVKITPRO" "$sdk_file" >&2
        exit 2
    fi
done

SCRATCH=''
STARTED=0
cleanup() {
    status=$?
    trap - EXIT
    if [ -n "$SCRATCH" ] && [ -d "$SCRATCH" ]; then rm -rf "$SCRATCH"; fi
    if [ "$status" -ne 0 ] && [ "$STARTED" -eq 1 ]; then
        echo 'Build did not complete. Any older files in build-3ds/ may be stale.' >&2
    fi
    exit "$status"
}
trap cleanup EXIT
SCRATCH=$(mktemp -d "${TMPDIR:-/tmp}/racer-rom.XXXXXXXX")
# The helper validates the entire ROM before any build starts. ZIP members
# are written to a fixed private temporary filename, never to an archive path.
ROM=$(python3 "$ROOT/tools/3ds/prepare_rom.py" "$INPUT" --temp-dir "$SCRATCH" \
    --reject-under "$ROOT/build/recomp-work" --reject-under "$ROOT/platform/3ds/generated")

cd "$ROOT"
STARTED=1
printf '\n[1/3] Building the host recompiler tools (first run may take a few minutes)...\n'
RACER_ONE_STEP=1 bash ./tools/3ds/setup.sh --jobs "$JOBS"
printf '\n[2/3] Recompiling the game from your ROM...\n'
RACER_ONE_STEP=1 bash ./tools/3ds/recompile.sh --rom "$ROM"
printf '\n[3/3] Building the 3DSX and CIA...\n'
make JOBS="$JOBS"
for output in build-3ds/Racer3DS.3dsx build-3ds/Racer3DS.cia; do
    if [ ! -s "$output" ]; then
        printf 'Build did not produce %s\n' "$output" >&2
        exit 1
    fi
done
printf '\nBuild complete:\n  %s\n  %s\n' "$ROOT/build-3ds/Racer3DS.3dsx" "$ROOT/build-3ds/Racer3DS.cia"
printf '%s\n' 'The outputs contain ROM-derived code; do not redistribute them without the necessary rights.'
