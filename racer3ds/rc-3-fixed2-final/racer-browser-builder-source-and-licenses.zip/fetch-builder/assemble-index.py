#!/usr/bin/env python3
"""Render the download-on-build HTML from its source template and asset manifests."""
from pathlib import Path
import argparse, hashlib, json
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--template',type=Path,required=True)
p.add_argument('--assets',type=Path,required=True)
p.add_argument('--remote-manifest',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
local={}
for f in sorted(a.assets.glob('*.gz')):
 data=f.read_bytes();local[f.stem]={'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
remote=json.loads(a.remote_manifest.read_text(encoding='utf8'))
assert len(local)==8 and len(remote)==11 and not (set(local)&set(remote))
text=a.template.read_text(encoding='utf8')
assert text.count('%%ASSET_MANIFEST%%')==1 and text.count('%%REMOTE_MANIFEST%%')==1
text=text.replace('%%ASSET_MANIFEST%%',json.dumps(local,separators=(',',':')))
text=text.replace('%%REMOTE_MANIFEST%%',json.dumps(remote,separators=(',',':')))
a.output.write_text(text,encoding='utf8')
print(f'Wrote {a.output}: {len(local)} local assets and {len(remote)} pinned downloadable tools')
