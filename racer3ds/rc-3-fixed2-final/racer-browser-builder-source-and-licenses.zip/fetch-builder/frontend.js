'use strict';
// Local compressed assets and downloaded, uncompressed tools are pinned by SHA-256.
const ASSET_MANIFEST = %%ASSET_MANIFEST%%;
const REMOTE_MANIFEST = %%REMOTE_MANIFEST%%;
const $ = id => document.getElementById(id);
const folderInput = $('asset-folder'), romInput = $('rom'), buildButton = $('build');
const cancelButton = $('cancel'), sourceButton = $('sources');
let worker = null, outputUrls = [], chosenAssets = new Map(), activeFetches = null;

function addLog(text) {
  const el = $('log'); el.textContent = (el.textContent + text + '\n').slice(-18000); el.scrollTop = el.scrollHeight;
}
function clearOutputs() {
  for (const url of outputUrls) URL.revokeObjectURL(url);
  outputUrls = []; $('results').hidden = true;
}
function readyAssets() { return chosenAssets.size === Object.keys(ASSET_MANIFEST).length; }
function setWorking(active) {
  folderInput.disabled = active;
  romInput.disabled = active;
  buildButton.disabled = active || !readyAssets() || !romInput.files.length;
  sourceButton.disabled = active || !readyAssets();
  cancelButton.hidden = !active;
}
function setError(message) { $('error').textContent = message; $('error').hidden = false; }
function clearError() { $('error').textContent = ''; $('error').hidden = true; }
function selectAssets() {
  clearOutputs(); clearError();
  const expected = Object.keys(ASSET_MANIFEST), matching = new Map(), duplicates = [];
  for (const file of folderInput.files) {
    if (!file.name.endsWith('.gz')) continue;
    const name = file.name.slice(0, -3);
    if (!Object.hasOwn(ASSET_MANIFEST, name)) continue;
    if (matching.has(name)) duplicates.push(name); else matching.set(name, file);
  }
  const missing = expected.filter(name => !matching.has(name));
  const wrongSize = expected.filter(name => matching.has(name) && matching.get(name).size !== ASSET_MANIFEST[name].size);
  chosenAssets = new Map();
  if (duplicates.length) {
    $('asset-status').textContent = 'Choose the assets folder itself; duplicate files were found.';
    setError('The selected folder has duplicate tool files: ' + duplicates.join(', '));
  } else if (missing.length) {
    $('asset-status').textContent = 'This folder does not contain all required builder assets.';
    setError('Choose the extracted assets folder. Missing: ' + missing.slice(0, 6).map(n => n + '.gz').join(', ') + (missing.length > 6 ? '…' : ''));
  } else if (wrongSize.length) {
    $('asset-status').textContent = 'One or more tool files have the wrong size.';
    setError('These asset files are incomplete or belong to another version: ' + wrongSize.map(n => n + '.gz').join(', '));
  } else {
    chosenAssets = matching;
    $('asset-status').textContent = 'Assets folder ready (' + expected.length + ' local files found).';
  }
  setWorking(false);
}
async function verify(buffer, entry, description) {
  if (!globalThis.crypto?.subtle) throw new Error('This browser cannot verify tool files. Try a recent desktop Chrome, Edge, or Firefox.');
  if (buffer.byteLength !== entry.size) throw new Error(description + ' has the wrong size.');
  const hash = await crypto.subtle.digest('SHA-256', buffer);
  const hex = Array.from(new Uint8Array(hash), n => n.toString(16).padStart(2, '0')).join('');
  if (hex !== entry.sha256) throw new Error(description + ' failed its SHA-256 integrity check.');
  return new Uint8Array(buffer);
}
async function localAsset(name) {
  const entry = ASSET_MANIFEST[name], file = chosenAssets.get(name);
  if (!entry || !file) throw new Error('Select the extracted assets folder before building. Missing: ' + name + '.gz');
  return verify(await file.arrayBuffer(), entry, 'The local asset ' + name + '.gz');
}
async function downloadedAsset(name, signal) {
  const entry = REMOTE_MANIFEST[name];
  if (!entry) throw new Error('Unknown browser tool asset: ' + name);
  let lastError = '';
  for (const url of entry.urls) {
    if (signal?.aborted) throw new Error('Download cancelled.');
    try {
      // URLs are fixed below; GET requests have no ROM data, cookies or referrer.
      const response = await fetch(url, {method:'GET', mode:'cors', credentials:'omit', referrerPolicy:'no-referrer', signal});
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const buffer = await response.arrayBuffer();
      return await verify(buffer, entry, 'The downloaded tool ' + name);
    } catch (error) {
      if (signal?.aborted) throw error;
      // An integrity failure must be visible and must never execute the bytes.
      if (error?.message?.includes('integrity check') || error?.message?.includes('wrong size')) throw error;
      lastError = error?.message || String(error);
    }
  }
  throw new Error('Could not download ' + name + '. Check your internet connection or browser blocking settings, then retry. (' + lastError + ')');
}
async function loadAsset(name, signal) {
  if (Object.hasOwn(ASSET_MANIFEST, name)) return {bytes: await localAsset(name), compressed:true};
  if (Object.hasOwn(REMOTE_MANIFEST, name)) return {bytes: await downloadedAsset(name, signal), compressed:false};
  throw new Error('Unknown tool asset: ' + name);
}
async function sourceDownload() {
  try {
    clearError();
    if (!globalThis.DecompressionStream) throw new Error('A newer desktop browser is required for the source download.');
    const compressed = await localAsset('source-bundle');
    const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'));
    const blob = await new Response(stream).blob();
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = 'racer-browser-builder-source-and-licenses.zip'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { setError(e.message || String(e)); }
}
sourceButton.addEventListener('click', sourceDownload);
folderInput.addEventListener('change', selectAssets);
romInput.addEventListener('change', () => { clearOutputs(); clearError(); if (!worker) setWorking(false); });
cancelButton.addEventListener('click', () => {
  if (activeFetches) activeFetches.abort();
  activeFetches = null;
  if (worker) worker.terminate();
  worker = null; setWorking(false);
  $('status').textContent = 'Build cancelled'; $('detail').textContent = 'Temporary build data was discarded.'; addLog('Build cancelled.');
});
buildButton.addEventListener('click', async () => {
  if (!romInput.files.length || worker || !readyAssets()) return;
  clearOutputs(); clearError(); $('work').hidden = false; $('log').textContent = '';
  $('progress').value = 0; $('percentage').textContent = '0%'; $('status').textContent = 'Reading your file'; $('detail').textContent = 'Your ROM stays on this device.';
  setWorking(true);
  let activeWorker = null, controller = null;
  try {
    if (!globalThis.Worker || !globalThis.WebAssembly || !globalThis.DecompressionStream || !globalThis.crypto?.subtle || !globalThis.AbortController) {
      throw new Error('This browser lacks a required feature. Try a recent desktop Chrome, Edge, or Firefox.');
    }
    const file = romInput.files[0];
    if (file.size > 128 * 1024 * 1024) throw new Error('The selected file is too large to be the supported ROM or ZIP.');
    const workerUrl = URL.createObjectURL(new Blob([$('worker-source').textContent], {type:'text/javascript'}));
    activeWorker = new Worker(workerUrl); URL.revokeObjectURL(workerUrl); worker = activeWorker;
    controller = new AbortController(); activeFetches = controller;
    activeWorker.onerror = event => {
      if (worker !== activeWorker) return;
      controller.abort(); activeFetches = null;
      setError(event.message || 'The browser worker stopped unexpectedly. Try another browser or free memory.');
      addLog(event.message || 'Worker error'); activeWorker.terminate(); worker = null; setWorking(false);
    };
    activeWorker.onmessage = event => {
      const message = event.data;
      if (message.type === 'asset-request') {
        if (Object.hasOwn(REMOTE_MANIFEST, message.name)) {
          $('detail').textContent = 'Downloading and verifying ' + message.name + ' (your ROM remains local).';
          addLog('Fetching tool: ' + message.name);
        }
        loadAsset(message.name, controller.signal).then(result => {
          if (worker === activeWorker) activeWorker.postMessage({type:'asset', id:message.id, buffer:result.bytes.buffer, compressed:result.compressed}, [result.bytes.buffer]);
        }, error => {
          if (worker === activeWorker) activeWorker.postMessage({type:'asset', id:message.id, error:error.message || String(error)});
        });
      } else if (message.type === 'progress') {
        $('status').textContent = message.step; $('percentage').textContent = message.percent + '%';
        $('progress').value = message.percent; $('detail').textContent = message.detail;
      } else if (message.type === 'log') addLog(message.text);
      else if (message.type === 'failure') {
        if (worker !== activeWorker) return;
        controller.abort(); activeFetches = null;
        setError(message.message); addLog(message.stack || message.message); activeWorker.terminate(); worker = null; setWorking(false);
      } else if (message.type === 'done') {
        if (worker !== activeWorker) return;
        activeFetches = null;
        const x = URL.createObjectURL(new Blob([message.dsx], {type:'application/octet-stream'}));
        const c = URL.createObjectURL(new Blob([message.cia], {type:'application/octet-stream'}));
        outputUrls = [x, c]; $('download3dsx').href = x; $('downloadcia').href = c; $('results').hidden = false;
        activeWorker.terminate(); worker = null; setWorking(false);
      }
    };
    const buffer = await file.arrayBuffer();
    if (worker === activeWorker) activeWorker.postMessage({type:'start', buffer}, [buffer]);
  } catch (e) {
    if (controller) controller.abort();
    if (activeFetches === controller) activeFetches = null;
    if (activeWorker) activeWorker.terminate();
    if (worker === activeWorker) worker = null;
    setWorking(false); setError(e.message || String(e));
  }
});
