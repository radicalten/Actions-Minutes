'use strict';
// The manifest covers the compressed local assets, not the user's ROM.
const ASSET_MANIFEST = %%ASSET_MANIFEST%%;
const $ = id => document.getElementById(id);
const folderInput = $('asset-folder'), romInput = $('rom'), buildButton = $('build');
const cancelButton = $('cancel'), sourceButton = $('sources');
let worker = null, outputUrls = [], chosenAssets = new Map();

function addLog(text) {
  const el = $('log'); el.textContent = (el.textContent + text + '\n').slice(-18000); el.scrollTop = el.scrollHeight;
}
function clearOutputs() {
  for (const url of outputUrls) URL.revokeObjectURL(url);
  outputUrls = []; $('results').hidden = true;
}
function setWorking(active) {
  folderInput.disabled = active;
  romInput.disabled = active;
  buildButton.disabled = active || chosenAssets.size !== Object.keys(ASSET_MANIFEST).length || !romInput.files.length;
  sourceButton.disabled = active || chosenAssets.size !== Object.keys(ASSET_MANIFEST).length;
  cancelButton.hidden = !active;
}
function setError(message) { $('error').textContent = message; $('error').hidden = false; }
function clearError() { $('error').textContent = ''; $('error').hidden = true; }
function selectAssets() {
  clearOutputs(); clearError();
  const expected = Object.keys(ASSET_MANIFEST);
  const matching = new Map(), duplicates = [];
  for (const file of folderInput.files) {
    if (!file.name.endsWith('.gz')) continue;
    const name = file.name.slice(0, -3);
    if (!Object.hasOwn(ASSET_MANIFEST, name)) continue;
    if (matching.has(name)) duplicates.push(name); else matching.set(name, file);
  }
  const missing = expected.filter(name => !matching.has(name));
  const wrongSize = expected.filter(name => matching.has(name) && matching.get(name).size !== ASSET_MANIFEST[name].size);
  chosenAssets = new Map();
  if (duplicates.length) {
    $('asset-status').textContent = 'Choose the assets folder itself; duplicate files were found.';
    setError('The selected folder has duplicate tool files: ' + duplicates.join(', '));
  } else if (missing.length) {
    $('asset-status').textContent = 'This folder does not contain all required builder assets.';
    setError('Choose the extracted assets folder. Missing: ' + missing.slice(0, 6).map(n => n + '.gz').join(', ') + (missing.length > 6 ? '…' : ''));
  } else if (wrongSize.length) {
    $('asset-status').textContent = 'One or more tool files have the wrong size.';
    setError('These asset files are incomplete or belong to another version: ' + wrongSize.map(n => n + '.gz').join(', '));
  } else {
    chosenAssets = matching;
    $('asset-status').textContent = 'Assets folder ready (' + expected.length + ' tool files found).';
  }
  setWorking(false);
}
async function compressedAsset(name) {
  const entry = ASSET_MANIFEST[name], file = chosenAssets.get(name);
  if (!entry || !file) throw new Error('Select the extracted assets folder before building. Missing: ' + name + '.gz');
  if (!globalThis.crypto || !globalThis.crypto.subtle) {
    throw new Error('This browser cannot verify local assets. Try a recent desktop Chrome, Edge, or Firefox.');
  }
  const buffer = await file.arrayBuffer();
  const hash = await crypto.subtle.digest('SHA-256', buffer);
  const hex = Array.from(new Uint8Array(hash), n => n.toString(16).padStart(2, '0')).join('');
  if (hex !== entry.sha256) throw new Error('The asset ' + name + '.gz is damaged or does not match this builder. Extract the ZIP again.');
  return new Uint8Array(buffer);
}
async function sourceDownload() {
  try {
    clearError();
    if (!globalThis.DecompressionStream) throw new Error('A newer desktop browser is required for the source download.');
    const compressed = await compressedAsset('source-bundle');
    const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'));
    const blob = await new Response(stream).blob();
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = 'racer-browser-builder-source-and-licenses.zip'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { setError(e.message || String(e)); }
}
sourceButton.addEventListener('click', sourceDownload);
folderInput.addEventListener('change', selectAssets);
romInput.addEventListener('change', () => { clearOutputs(); clearError(); if (!worker) setWorking(false); });
cancelButton.addEventListener('click', () => {
  if (worker) worker.terminate();
  worker = null; setWorking(false);
  $('status').textContent = 'Build cancelled'; $('detail').textContent = 'Temporary build data was discarded.'; addLog('Build cancelled.');
});
buildButton.addEventListener('click', async () => {
  if (!romInput.files.length || worker || chosenAssets.size !== Object.keys(ASSET_MANIFEST).length) return;
  clearOutputs(); clearError(); $('work').hidden = false; $('log').textContent = '';
  $('progress').value = 0; $('percentage').textContent = '0%'; $('status').textContent = 'Reading your file'; $('detail').textContent = 'Your ROM stays on this device.';
  setWorking(true);
  let activeWorker = null;
  try {
    if (!globalThis.Worker || !globalThis.WebAssembly || !globalThis.DecompressionStream || !globalThis.crypto?.subtle) {
      throw new Error('This browser lacks a required offline feature. Try a recent desktop Chrome, Edge, or Firefox.');
    }
    const file = romInput.files[0];
    if (file.size > 128 * 1024 * 1024) throw new Error('The selected file is too large to be the supported ROM or ZIP.');
    const workerUrl = URL.createObjectURL(new Blob([$('worker-source').textContent], {type:'text/javascript'}));
    activeWorker = new Worker(workerUrl); URL.revokeObjectURL(workerUrl); worker = activeWorker;
    activeWorker.onerror = event => {
      if (worker !== activeWorker) return;
      setError(event.message || 'The browser worker stopped unexpectedly. Try another browser or free memory.');
      addLog(event.message || 'Worker error'); activeWorker.terminate(); worker = null; setWorking(false);
    };
    activeWorker.onmessage = event => {
      const message = event.data;
      if (message.type === 'asset-request') {
        compressedAsset(message.name).then(bytes => {
          if (worker === activeWorker) activeWorker.postMessage({type:'asset', id:message.id, buffer:bytes.buffer}, [bytes.buffer]);
        }, error => {
          if (worker === activeWorker) activeWorker.postMessage({type:'asset', id:message.id, error:error.message || String(error)});
        });
      } else if (message.type === 'progress') {
        $('status').textContent = message.step; $('percentage').textContent = message.percent + '%';
        $('progress').value = message.percent; $('detail').textContent = message.detail;
      } else if (message.type === 'log') addLog(message.text);
      else if (message.type === 'failure') {
        if (worker !== activeWorker) return;
        setError(message.message); addLog(message.stack || message.message); activeWorker.terminate(); worker = null; setWorking(false);
      } else if (message.type === 'done') {
        if (worker !== activeWorker) return;
        const x = URL.createObjectURL(new Blob([message.dsx], {type:'application/octet-stream'}));
        const c = URL.createObjectURL(new Blob([message.cia], {type:'application/octet-stream'}));
        outputUrls = [x, c]; $('download3dsx').href = x; $('downloadcia').href = c; $('results').hidden = false;
        activeWorker.terminate(); worker = null; setWorking(false);
      }
    };
    const buffer = await file.arrayBuffer();
    if (worker === activeWorker) activeWorker.postMessage({type:'start', buffer}, [buffer]);
  } catch (e) {
    if (activeWorker) activeWorker.terminate();
    if (worker === activeWorker) worker = null;
    setWorking(false); setError(e.message || String(e));
  }
});
