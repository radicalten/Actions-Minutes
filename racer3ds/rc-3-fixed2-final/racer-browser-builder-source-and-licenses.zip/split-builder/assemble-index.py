#!/usr/bin/env python3
"""Render the split builder's HTML from its template and local .gz assets."""
import argparse, hashlib, json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--template', type=Path, required=True)
parser.add_argument('--assets', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
required = ('pyodide-js', 'pyodide-asm-js', 'pyodide-wasm', 'pyodide-stdlib',
            'pyodide-lock', 'game-source', 'runtime', 'n64recomp', 'rsprecomp',
            'llvm-js', 'llvm-core', 'llvm-core2', 'llvm-core3', 'llvm-core4',
            'llvm-resources', 'smdhtool', '3dsxtool', 'makerom', 'source-bundle')
manifest = {}
for name in required:
    data = (args.assets / (name + '.gz')).read_bytes()
    manifest[name] = {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
template = args.template.read_text(encoding='utf8')
if template.count('%%ASSET_MANIFEST%%') != 1:
    raise ValueError('Expected exactly one manifest marker in the template')
rendered = template.replace('%%ASSET_MANIFEST%%', json.dumps(manifest, separators=(',', ':'), sort_keys=True))
args.output.write_text(rendered, encoding='utf8')
print('Wrote', args.output, 'with checksums for', len(manifest), 'local assets')
