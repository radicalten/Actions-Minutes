/* Offline Racer 3DS build worker. All binary assets are supplied by the HTML
   document; the only fetch implementation below serves those embedded assets. */
'use strict';

const pendingAssets = new Map();
let requestNumber = 0;
const decoder = new TextDecoder();
const encoder = new TextEncoder();
let started = false;

function progress(step, percent, detail = '') {
  postMessage({ type: 'progress', step, percent, detail });
}
function note(text) {
  if (text) postMessage({ type: 'log', text: String(text) });
}
function requestCompressed(name) {
  const id = ++requestNumber;
  return new Promise((resolve, reject) => {
    pendingAssets.set(id, { resolve, reject });
    postMessage({ type: 'asset-request', id, name });
  });
}
async function asset(name) {
  const buffer = await requestCompressed(name);
  if (!globalThis.DecompressionStream) {
    throw new Error('This browser does not support built-in gzip decompression. Use a recent desktop Chrome, Edge, or Firefox.');
  }
  const stream = new Blob([buffer]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
function scriptUrl(bytes) {
  return URL.createObjectURL(new Blob([bytes], { type: 'text/javascript' }));
}
async function loadClassicScript(name) {
  const url = scriptUrl(await asset(name));
  try { importScripts(url); } finally { URL.revokeObjectURL(url); }
}
async function loadModule(name, rewrite = null) {
  let bytes = await asset(name);
  if (rewrite) bytes = encoder.encode(rewrite(decoder.decode(bytes)));
  const url = scriptUrl(bytes);
  try { return await import(url); } finally { URL.revokeObjectURL(url); }
}
function checkCode(code, description, errors) {
  if (code !== undefined && code !== 0) {
    throw new Error(`${description} failed (exit ${code}).${errors ? '\n' + errors.slice(-4000) : ''}`);
  }
}
function readText(fs, path) { return fs.readFile(path, { encoding: 'utf8' }); }
function writePyFile(fs, path, data) {
  fs.mkdirTree(path.slice(0, path.lastIndexOf('/')) || '/');
  fs.writeFile(path, data);
}
function toolOutput(label) {
  let errors = '';
  return {
    options: {
      print: () => {},
      printErr: line => { errors += String(line) + '\n'; }
    },
    error: () => errors ? `${label}: ${errors}` : ''
  };
}

async function initializePython() {
  progress('Preparing offline Python', 3, 'Loading Pyodide from this file');
  // Do not allow a mistaken asset URL to turn into a network request.
  const map = {
    'pyodide.asm.wasm': 'pyodide-wasm',
    'python_stdlib.zip': 'pyodide-stdlib',
    'pyodide-lock.json': 'pyodide-lock'
  };
  globalThis.fetch = async input => {
    const url = typeof input === 'string' ? input : input.url || String(input);
    const prefix = 'https://racer.invalid/pyodide/';
    if (!url.startsWith(prefix)) throw new Error('Network access is disabled in this offline builder.');
    const name = url.slice(prefix.length);
    if (!Object.hasOwn(map, name)) throw new Error(`Unexpected offline Pyodide asset: ${name}`);
    const bytes = await asset(map[name]);
    return new Response(bytes, { headers: { 'content-type': name.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream' } });
  };
  await loadClassicScript('pyodide-js');
  await loadClassicScript('pyodide-asm-js');
  const lock = JSON.parse(decoder.decode(await asset('pyodide-lock')));
  const py = await loadPyodide({
    indexURL: 'https://racer.invalid/pyodide/',
    lockFileContents: lock,
    packageBaseUrl: 'https://racer.invalid/pyodide/'
  });
  py.setStdout({ batched: line => note(line) });
  py.setStderr({ batched: line => note(line) });
  return py;
}

async function generateSources(py, raw) {
  const fs = py.FS;
  progress('Checking your ROM', 8, 'Validating the exact supported US revision');
  writePyFile(fs, '/input.rom', raw);
  raw = null;
  writePyFile(fs, '/source.zip', await asset('game-source'));
  const romPath = py.runPython(`
import os, sys, zipfile
with zipfile.ZipFile('/source.zip') as archive:
    archive.extractall('/')  # trusted, embedded source archive
ROOT = '/release-candidate3-fixed'
sys.path.insert(0, ROOT + '/tools/3ds')
from prepare_rom import prepare
os.makedirs('/rom-stage', exist_ok=True)
rom_path = prepare('/input.rom', '/rom-stage')
rom_path.as_posix()
`);
  fs.unlink('/source.zip');
  note('ROM verified: supported US NEPE revision.');
  const root = '/release-candidate3-fixed';
  fs.mkdirTree('/work/tools'); fs.mkdirTree('/work/src'); fs.mkdirTree('/work/rsp');
  for (const name of ['recomp.toml', 'symbols.toml']) {
    writePyFile(fs, '/work/' + name, fs.readFile(root + '/recomp/' + name));
  }
  for (const name of ['fix_fallthroughs.py', 'post_recomp_patches.py', 'gen_lookup_table.py']) {
    writePyFile(fs, '/work/tools/' + name, fs.readFile(root + '/recomp/tools/' + name));
  }
  let rom = fs.readFile(romPath);

  progress('Recompiling the game', 12, 'Running N64Recomp locally');
  {
    const { default: factory } = await loadModule('n64recomp');
    const log = toolOutput('N64Recomp');
    const tool = await factory(log.options);
    tool.FS.mkdir('/work'); tool.FS.chdir('/work');
    tool.FS.writeFile('baserom.z64', rom);
    tool.FS.writeFile('recomp.toml', fs.readFile('/work/recomp.toml'));
    tool.FS.writeFile('symbols.toml', fs.readFile('/work/symbols.toml'));
    const code = tool.callMain(['recomp.toml']);
    checkCode(code, 'N64Recomp', log.error());
    const generated = tool.FS.readdir('RecompiledFuncs').filter(n => n !== '.' && n !== '..');
    if (generated.filter(n => /^funcs_\d+\.c$/.test(n)).length !== 28 || !generated.includes('lookup.cpp')) {
      throw new Error('N64Recomp did not generate the expected game sources.');
    }
    fs.mkdirTree('/work/RecompiledFuncs');
    for (const file of generated) {
      writePyFile(fs, '/work/RecompiledFuncs/' + file, tool.FS.readFile('RecompiledFuncs/' + file));
    }
    tool.FS.unlink('baserom.z64');
  }

  progress('Patching generated code', 19, 'Applying the tested Racer fixes');
  py.runPython(`
import os, runpy, sys
os.chdir('/work')
for script in ('fix_fallthroughs.py', 'post_recomp_patches.py'):
    sys.argv = [script]
    runpy.run_path('/work/tools/' + script, run_name='__main__')
`);

  progress('Recompiling audio microcode', 23, 'Running RSPRecomp locally');
  {
    const { default: factory } = await loadModule('rsprecomp');
    const log = toolOutput('RSPRecomp');
    const tool = await factory(log.options);
    tool.FS.mkdir('/work'); tool.FS.chdir('/work'); tool.FS.mkdir('rsp');
    tool.FS.writeFile('baserom.z64', rom);
    const original = readText(fs, root + '/recomp/rsp/aspMain.toml');
    const config = original.replace('rom_file_path = "../baserom.z64"', 'rom_file_path = "baserom.z64"')
                           .replace('output_file_path = "aspMain.cpp"', 'output_file_path = "rsp/aspMain.cpp"');
    tool.FS.writeFile('aspMain.toml', config);
    const code = tool.callMain(['aspMain.toml']);
    checkCode(code, 'RSPRecomp', log.error());
    const rsp = tool.FS.readFile('rsp/aspMain.cpp');
    if (!decoder.decode(rsp).includes('RspExitReason aspMain(')) throw new Error('RSP entry point was not generated.');
    writePyFile(fs, '/work/rsp/aspMain.cpp', rsp);
    tool.FS.unlink('baserom.z64');
  }
  rom = null;
  // Delete temporary copies early; the chosen input and the downloadable outputs
  // remain owned by the browser/user and are never silently modified.
  if (romPath !== '/input.rom') fs.unlink(romPath);
  fs.unlink('/input.rom');
  py.runPython(`
os.chdir('/work')
sys.argv = ['gen_lookup_table.py']
runpy.run_path('/work/tools/gen_lookup_table.py', run_name='__main__')
`);
  return root;
}

async function compileAndLink(py, root) {
  progress('Preparing the ARM compiler', 28, 'Loading the offline WebAssembly toolchain');
  // A blob module has no hierarchical base URL. Point the compiler's internal
  // resource lookups to a virtual URL; the supplied loader serves all assets.
  const llvm = await loadModule('llvm-js', text => text.replaceAll('import.meta.url', '"https://racer.invalid/llvm/bundle.js"'));
  const llvmAssets = {
    'llvm.core.wasm': 'llvm-core', 'llvm.core2.wasm': 'llvm-core2',
    'llvm.core3.wasm': 'llvm-core3', 'llvm.core4.wasm': 'llvm-core4',
    'llvm-resources.tar': 'llvm-resources'
  };
  llvm.setAssetLoader(async name => {
    if (!Object.hasOwn(llvmAssets, name)) throw new Error('Unexpected LLVM asset: ' + name);
    return await asset(llvmAssets[name]);
  });
  const s = llvm.createSession();
  const fs = py.FS;
  const copyTree = async (src, dest) => {
    for (const name of fs.readdir(src)) {
      if (name === '.' || name === '..') continue;
      const p = src + '/' + name, q = dest + '/' + name;
      const st = fs.stat(p);
      if (fs.isDir(st.mode)) await copyTree(p, q);
      else if (fs.isFile(st.mode)) await s.writeFile(q, fs.readFile(p));
    }
  };
  for (const sub of ['N64Recomp/include', 'ultramodern/include', 'librecomp/include']) {
    await copyTree(root + '/lib/N64ModernRuntime/' + sub, '/work/include/' + sub.split('/')[0]);
  }
  await s.writeFile('/work/include/racer_host_protos.h', fs.readFile(root + '/platform/3ds/racer_host_protos.h'));
  await copyTree('/work/RecompiledFuncs', '/work/src');
  await s.writeFile('/work/src/section_table.cpp', fs.readFile('/work/src/section_table.cpp'));
  await s.writeFile('/work/src/aspMain.cpp', fs.readFile('/work/rsp/aspMain.cpp'));
  const common = [
    '--target=arm-none-eabi', '--sysroot=/usr', '-march=armv6k', '-mtune=mpcore',
    '-mfloat-abi=hard', '-mfpu=vfp', '-fshort-enums', '-Wno-builtin-macro-redefined',
    '-D__INT32_TYPE__=long int', '-D__UINT32_TYPE__=long unsigned int',
    '-D__INT_LEAST32_TYPE__=long int', '-D__UINT_LEAST32_TYPE__=long unsigned int',
    '-D__INT_FAST8_TYPE__=int', '-D__UINT_FAST8_TYPE__=unsigned int',
    '-D__INT_FAST16_TYPE__=int', '-D__UINT_FAST16_TYPE__=unsigned int',
    '-D__WINT_TYPE__=unsigned int', '-ffunction-sections', '-fdata-sections',
    '-D__3DS__', '-DARM11', '-DNDEBUG', '-fno-strict-aliasing', '-w',
    '-I/work/src', '-I/work/include', '-I/work/include/N64Recomp',
    '-I/work/include/ultramodern', '-I/work/include/librecomp'
  ];
  const funcs = fs.readdir('/work/RecompiledFuncs').filter(n => /^funcs_\d+\.c$/.test(n))
    .sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]));
  const jobs = [
    ...funcs.map(name => ({ name, tool: 'clang', flags: ['-std=gnu17', '-O2', '-Wno-implicit-function-declaration', '-include', '/work/include/racer_host_protos.h'] })),
    { name: 'lookup.cpp', tool: 'clang++', flags: ['-std=gnu++20', '-O2', '-fexceptions', '-frtti', '-include', '/work/include/racer_host_protos.h'] },
    { name: 'section_table.cpp', tool: 'clang++', flags: ['-std=gnu++20', '-O2', '-fexceptions', '-frtti', '-DRECOMP_NO_MODS', '-DMINIZ_STATIC_DEFINE'] },
    { name: 'aspMain.cpp', tool: 'clang++', flags: ['-std=gnu++20', '-O3', '-fexceptions', '-frtti', '-DRECOMP_NO_MODS', '-DMINIZ_STATIC_DEFINE'] }
  ];
  let index = 0;
  for (const job of jobs) {
    progress('Compiling for Nintendo 3DS', 30 + Math.floor(48 * index / jobs.length), `${index + 1} of ${jobs.length}: ${job.name}`);
    const output = '/work/obj/' + job.name + '.o';
    let errors = '';
    const code = await s.run([job.tool, ...common, ...job.flags, '-c', '/work/src/' + job.name, '-o', output], {
      stdout: () => {}, stderr: chunk => { if (chunk) errors += decoder.decode(chunk); }
    });
    checkCode(code, 'Compiler (' + job.name + ')', errors);
    const object = await s.readFile(output);
    if (!object || object.length < 20 || object[0] !== 0x7f || object[1] !== 0x45 || object[18] !== 40) {
      throw new Error('The compiler did not produce a valid ARM object: ' + job.name);
    }
    index++;
  }

  progress('Linking the game', 80, 'Combining compiled code with the 3DS runtime');
  writePyFile(fs, '/runtime.zip', await asset('runtime'));
  py.runPython(`
import zipfile
with zipfile.ZipFile('/runtime.zip') as archive:
    archive.extractall('/runtime')  # trusted, embedded, ROM-independent libraries
`);
  fs.unlink('/runtime.zip');
  for (const name of fs.readdir('/runtime').filter(n => n !== '.' && n !== '..')) {
    await s.writeFile('/link/' + name, fs.readFile('/runtime/' + name));
  }
  const objects = ['/work/obj/section_table.cpp.o', '/work/obj/aspMain.cpp.o', '/work/obj/lookup.cpp.o', ...funcs.map(f => '/work/obj/' + f + '.o')];
  const args = [
    'ld.lld', '--defsym=__sync_synchronize=__sync_synchronize_dmb', '-m', 'armelf',
    '-T', '/link/3dsx.ld', '--emit-relocs', '--gc-sections', '-o', '/link/Racer3DS',
    '/link/3dsx_crt0.o', '/link/crti.o', '/link/crtbegin.o', '/link/main.o', '/link/api.o', ...objects,
    '/link/librecomp_3ds.a', '/link/librt64_3ds.a', '/link/libultramodern.a',
    '/link/liblibrecomp.a', '/link/libminiz.a', '/link/libcitro3d.a', '/link/libctru.a',
    '/link/libultramodern.a', '/link/libstdc++.a', '/link/libm.a',
    '--start-group', '/link/libgcc.a', '/link/libc.a', '/link/libsysbase.a', '--end-group',
    '/link/crtend.o', '/link/crtn.o'
  ];
  let errors = '';
  const code = await s.run(args, { stdout: () => {}, stderr: chunk => { if (chunk) errors += decoder.decode(chunk); } });
  checkCode(code, 'ARM linker', errors);
  const elf = await s.readFile('/link/Racer3DS');
  if (!elf || elf.length < 100000 || elf[0] !== 0x7f || elf[18] !== 40) throw new Error('Linker did not produce a valid ARM executable.');
  return elf;
}

async function packageOutputs(py, root, elf) {
  const fs = py.FS;
  progress('Preparing 3DS metadata', 85, 'Creating the homebrew icon');
  let smdhBytes;
  {
    const { default: factory } = await loadModule('smdhtool');
    const log = toolOutput('smdhtool');
    const tool = await factory(log.options);
    tool.FS.mkdir('/work'); tool.FS.chdir('/work');
    tool.FS.writeFile('icon.png', fs.readFile(root + '/platform/3ds/icon.png'));
    const code = tool.callMain(['--create', 'Star Wars Racer 3DS', 'Star Wars Episode I: Racer (N64 recompilation)', ' ', 'icon.png', 'icon.smdh']);
    checkCode(code, 'Icon tool', log.error());
    smdhBytes = tool.FS.readFile('icon.smdh');
    if (smdhBytes.length !== 14016) throw new Error('Icon metadata has an unexpected size.');
  }
  progress('Creating the 3DSX', 88, 'Packaging the homebrew application');
  let dsx;
  {
    const { default: factory } = await loadModule('3dsxtool');
    const log = toolOutput('3dsxtool');
    const tool = await factory(log.options);
    tool.FS.mkdir('/work'); tool.FS.chdir('/work');
    tool.FS.writeFile('input.elf', elf); tool.FS.writeFile('icon.smdh', smdhBytes);
    const code = tool.callMain(['input.elf', 'Racer3DS.3dsx', '--smdh=icon.smdh']);
    checkCode(code, '3DSX packager', log.error());
    dsx = tool.FS.readFile('Racer3DS.3dsx').slice();
    if (dsx.length < 100000 || decoder.decode(dsx.slice(0, 4)) !== '3DSX') throw new Error('Invalid 3DSX output.');
  }
  progress('Creating the CIA', 92, 'Packaging the installable application; this may take a little longer');
  let cia;
  {
    const { default: factory } = await loadModule('makerom');
    const log = toolOutput('makerom');
    const tool = await factory(log.options);
    tool.FS.mkdir('/work'); tool.FS.chdir('/work');
    tool.FS.writeFile('input.elf', elf); tool.FS.writeFile('icon.smdh', smdhBytes);
    let rsf = readText(fs, root + '/lib/rt64-3ds/cia/template.rsf')
      .replaceAll('@TITLE@', 'Star Wars Racer 3DS').replaceAll('@PRODUCT@', 'RACER-3DS').replaceAll('@UNIQUEID@', '0xF9048');
    tool.FS.writeFile('app.rsf', rsf);
    const code = tool.callMain(['-f', 'cia', '-o', 'Racer3DS.cia', '-elf', 'input.elf', '-rsf', 'app.rsf', '-icon', 'icon.smdh', '-exefslogo', '-target', 't']);
    checkCode(code, 'CIA packager', log.error());
    cia = tool.FS.readFile('Racer3DS.cia').slice();
    if (cia.length < 100000) throw new Error('CIA output is unexpectedly small.');
  }
  return { dsx, cia };
}

async function runBuild(buffer) {
  try {
    if (buffer.byteLength > 128 * 1024 * 1024) throw new Error('The selected file is too large to be the supported ROM or ZIP.');
    const py = await initializePython();
    const root = await generateSources(py, new Uint8Array(buffer));
    const elf = await compileAndLink(py, root);
    const { dsx, cia } = await packageOutputs(py, root, elf);
    progress('Build complete', 100, 'Both private outputs are ready to download.');
    postMessage({ type: 'done', dsx: dsx.buffer, cia: cia.buffer }, [dsx.buffer, cia.buffer]);
  } catch (error) {
    postMessage({ type: 'failure', message: error && error.message ? error.message : String(error), stack: error && error.stack ? String(error.stack) : '' });
  }
}

self.onmessage = event => {
  const data = event.data;
  if (data.type === 'asset') {
    const request = pendingAssets.get(data.id);
    if (request) {
      pendingAssets.delete(data.id);
      if (data.error) request.reject(new Error(data.error)); else request.resolve(data.buffer);
    }
  } else if (data.type === 'start' && !started) {
    started = true;
    runBuild(data.buffer);
  }
};
