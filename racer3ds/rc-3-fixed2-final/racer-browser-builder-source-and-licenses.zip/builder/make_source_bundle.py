#!/usr/bin/env python3
from pathlib import Path
import argparse, tarfile, zipfile
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Bundle builder source, component sources and licenses')
parser.add_argument('--assets-root', type=Path, required=True)
parser.add_argument('--project-zip', type=Path, required=True)
parser.add_argument('--linker-script', type=Path, default=HERE/'3dsx-lld.ld')
parser.add_argument('--output', type=Path, required=True)
args=parser.parse_args()
D=args.assets_root
out=args.output
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(p,n): z.write(p,n)
 def tree(p,n):
  for f in sorted(p.rglob('*')):
   if f.is_file(): add(f, str(Path(n)/f.relative_to(p)))
 add(HERE/'SOURCE-AND-LICENSES.md','SOURCE-AND-LICENSES.md')
 add(args.project_zip,'project/release-candidate3-fixed.zip')
 for f in ('worker.js','index.template.html','make_runtime_zip.py','make_html.py','make_source_bundle.py','make_wasm_tools.sh','makerom-CMakeLists.txt'):
  add(HERE/f,'builder/'+f)
 add(args.linker_script,'builder/3dsx-lld.ld')
 tree(D/'sources/3dstools-master','third-party/3dstools')
 tree(D/'sources/Project_CTR-master/makerom','third-party/makerom')
 add(D/'sdk-root/opt/devkitpro/licenses/3dstools/COPYING','licenses/3dstools-COPYING.txt')
 for f in (D/'sources/licenses').glob('*.txt'): add(f,'licenses/'+f.name)
 for f in (D/'sources/licenses').glob('*.patch'): add(f,'third-party/devkitpro-patches/'+f.name)
 packages=D/'sdk-root/opt/devkitpro/pacman/var/lib/pacman/local'
 for pattern in ('devkitarm-gcc-*','devkitarm-newlib-*','devkitarm-crtls-*','libctru-*','citro3d-*'):
  for p in sorted(packages.glob(pattern)):
   if (p/'desc').is_file(): add(p/'desc','third-party/devkitpro-package-metadata/'+p.name+'.txt')
 add(D/'microbit-clang/package/LICENSE.txt','licenses/microbit-clang-wasm-Apache.txt')
 add(D/'microbit-clang/package/LICENSES.md','licenses/microbit-clang-wasm-LICENSES.md')
 add(D/'sources/yowasp-runtime/package/LICENSE.txt','licenses/yowasp-runtime-ISC.txt')
 tree(D/'microbit-clang/package/lib','third-party/microbit-clang-wasm/lib')
 add(D/'microbit-clang/package/package.json','third-party/microbit-clang-wasm/package.json')
 with tarfile.open(D/'microbit-clang/package/gen/llvm-resources.tar') as tar:
  for m in tar.getmembers():
   if m.isfile() and m.name.startswith('share/licenses/'):
    z.writestr('licenses/llvm/'+m.name.removeprefix('share/licenses/'),tar.extractfile(m).read())
 print('Source bundle',out, 'entries',len(z.namelist()))
print(out.stat().st_size,'bytes')
