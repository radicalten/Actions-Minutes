#!/usr/bin/env bash
# Rebuild the Emscripten tool modules from the sources in this source bundle.
# Requires Emscripten 3.1.69, CMake, Ninja and Node. Run from any directory.
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
DEST=${1:-"$PWD/wasm-tools"}
SCRATCH=$(mktemp -d)
trap 'rm -rf "$SCRATCH"' EXIT
mkdir -p "$DEST" "$SCRATCH/project" "$SCRATCH/n64" "$SCRATCH/makerom"
unzip -q "$ROOT/project/release-candidate3-fixed.zip" -d "$SCRATCH/project"
N64="$SCRATCH/project/release-candidate3-fixed/lib/N64ModernRuntime/N64Recomp"
FLAGS='-fexceptions -sMODULARIZE=1 -sEXPORT_ES6=1 -sENVIRONMENT=web,worker,node -sEXPORTED_RUNTIME_METHODS=FS,callMain -sINVOKE_RUN=0 -sALLOW_MEMORY_GROWTH=1 -sFORCE_FILESYSTEM=1 -sEXIT_RUNTIME=0 -sSINGLE_FILE=1'
emcmake cmake -S "$N64" -B "$SCRATCH/n64" -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_FLAGS=-fexceptions -DCMAKE_CXX_FLAGS=-fexceptions \
  "-DCMAKE_EXE_LINKER_FLAGS=$FLAGS -sEXPORT_NAME=createRecompiler"
cmake --build "$SCRATCH/n64" --target N64RecompCLI RSPRecomp -j2
cp "$SCRATCH/n64/N64Recomp.js" "$DEST/N64Recomp.mjs"
cp "$SCRATCH/n64/RSPRecomp.js" "$DEST/RSPRecomp.mjs"
S="$ROOT/third-party/3dstools/src"
em++ -O2 $FLAGS -sEXPORT_NAME=createTool "$S/3dsxtool.cpp" "$S/romfs.cpp" -o "$DEST/3dsxtool.mjs"
em++ -O2 $FLAGS -sEXPORT_NAME=createTool "$S/smdhtool.cpp" "$S/lodepng/lodepng.cpp" -o "$DEST/smdhtool.mjs"
cp "$HERE/makerom-CMakeLists.txt" "$SCRATCH/makerom/CMakeLists.txt"
emcmake cmake -S "$SCRATCH/makerom" -B "$SCRATCH/makerom/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DMAKEROM_SOURCE="$ROOT/third-party/makerom" \
  "-DCMAKE_EXE_LINKER_FLAGS=$FLAGS -sEXPORT_NAME=createTool"
cmake --build "$SCRATCH/makerom/build" -j2
cp "$SCRATCH/makerom/build/makerom.js" "$DEST/makerom.mjs"
printf 'WASM tools written to %s\n' "$DEST"
