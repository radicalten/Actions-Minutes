#!/usr/bin/env python3
"""Package only ROM-independent link inputs. All paths inside ZIP are fixed."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sdk-root', type=Path, required=True, help='devkitPro root directory')
parser.add_argument('--runtime-build', type=Path, required=True, help='CMake build directory for the ROM-independent project runtime')
parser.add_argument('--linker-script', type=Path, default=Path(__file__).with_name('3dsx-lld.ld'))
parser.add_argument('--output', type=Path, required=True)
args=parser.parse_args()
SDK=args.sdk_root
ARM = SDK/'devkitARM'
B = args.runtime_build
G = ARM/'lib/gcc/arm-none-eabi/16.1.0/armv6k/fpu'
N = ARM/'arm-none-eabi/lib/armv6k/fpu'
files = {
 '3dsx.ld': args.linker_script,
 '3dsx_crt0.o':N/'3dsx_crt0.o','crti.o':G/'crti.o','crtbegin.o':G/'crtbegin.o','crtend.o':G/'crtend.o','crtn.o':G/'crtn.o',
 'main.o':B/'CMakeFiles/Racer3DS.dir/main_3ds.cpp.obj','api.o':B/'CMakeFiles/Racer3DS.dir/recomp_api_3ds.cpp.obj',
 'librecomp_3ds.a':B/'rt64-3ds/librecomp_3ds.a','librt64_3ds.a':B/'rt64-3ds/librt64_3ds.a',
 'libultramodern.a':B/'rt64-3ds/nmr/ultramodern/libultramodern.a','liblibrecomp.a':B/'rt64-3ds/nmr/librecomp/liblibrecomp.a','libminiz.a':B/'rt64-3ds/nmr/librecomp/miniz/libminiz.a',
 'libcitro3d.a':SDK/'libctru/lib/libcitro3d.a','libctru.a':SDK/'libctru/lib/libctru.a',
 'libstdc++.a':N/'libstdc++.a','libm.a':N/'libm.a','libgcc.a':G/'libgcc.a','libc.a':N/'libc.a','libsysbase.a':N/'libsysbase.a'}
out=args.output
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in files.items():
        print(name, p.stat().st_size)
        z.write(p,name)
print('Runtime asset:',out, out.stat().st_size,'bytes')
