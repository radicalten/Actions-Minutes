#!/usr/bin/env python3
"""Bundle offline, ROM-independent assets into a standalone HTML file."""
import argparse, base64, gzip
from pathlib import Path
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--assets-root', type=Path, required=True, help='directory holding the prepared Pyodide, LLVM, WASM and runtime assets')
parser.add_argument('--project-zip', type=Path, required=True, help='ROM-independent project source ZIP')
parser.add_argument('--output', type=Path, required=True)
args=parser.parse_args()
D=args.assets_root
P=D/'pyodide/package'; L=D/'microbit-clang/package/gen'
assets={
 'pyodide-js':P/'pyodide.js', 'pyodide-asm-js':P/'pyodide.asm.js',
 'pyodide-wasm':P/'pyodide.asm.wasm', 'pyodide-stdlib':P/'python_stdlib.zip', 'pyodide-lock':P/'pyodide-lock.json',
 'game-source':args.project_zip, 'runtime':D/'runtime.zip',
 'n64recomp':D/'n64build/N64Recomp.mjs', 'rsprecomp':D/'n64build/RSPRecomp.mjs',
 'llvm-js':L/'bundle.js', 'llvm-core':L/'llvm.core.wasm', 'llvm-core2':L/'llvm.core2.wasm',
 'llvm-core3':L/'llvm.core3.wasm', 'llvm-core4':L/'llvm.core4.wasm', 'llvm-resources':L/'llvm-resources.tar',
 'smdhtool':D/'tools/smdhtool.mjs', '3dsxtool':D/'tools/3dsxtool.mjs', 'makerom':D/'tools/makerom.mjs',
 'source-bundle':D/'source-and-licenses.zip'
}
out=args.output
template=(HERE/'index.template.html').read_text(encoding='utf-8')
worker=(HERE/'worker.js').read_text(encoding='utf-8')
assert '</script' not in worker.lower()
top,tail=template.replace('%%WORKER%%',worker).split('%%ASSETS%%')
with out.open('w',encoding='utf-8') as f:
 f.write(top)
 for name,path in assets.items():
  raw=path.read_bytes(); packed=gzip.compress(raw,compresslevel=6,mtime=0)
  f.write(f'<script type="application/octet-stream" id="asset-{name}">')
  f.write(base64.b64encode(packed).decode('ascii')); f.write('</script>\n')
  print(f'{name:20s} {len(raw):10d} -> {len(packed):10d}')
 f.write(tail)
print('Standalone HTML:',out, out.stat().st_size,'bytes')
