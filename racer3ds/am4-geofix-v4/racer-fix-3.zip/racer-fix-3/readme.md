# Racer 3DS — VI scanout fix 3

This is the Nintendo 3DS port of the [sp00nznet/racer](https://github.com/sp00nznet/racer) static recompilation of *Star Wars Episode I: Racer*, based on the source archive in [radicalten/Actions-Minutes4](https://github.com/radicalten/Actions-Minutes4). It includes the patched source, build tools, and newly compiled `bin/Racer3DS.3dsx` and `bin/Racer3DS.cia`. The project is unofficial and is not affiliated with the game's rightsholders.

## What changed

The renderer no longer treats `VI_WIDTH_REG` (the framebuffer's row pitch) as the displayed picture's width when following Racer's VI. It computes the active source width from the horizontal VI window and the low 12-bit, 2.10 fixed-point X scale:

```
visible source pixels = round((H_END - H_START) * X_SCALE / 1024)
```

It rechecks the window and scale as well as the pitch, keeps the last valid geometry while the VI is blank or unset, and retains the existing explicit debug-width override. The game's 240-line height and 4:3 fit are unchanged. For the affected mode observed in the emulator, the pitch is 640, the active window is 108–748, and the X scale is `0x200`: the displayed source is **320**, not 640, pixels wide. This prevents the 320-pixel 3D display list from being squeezed into the left half of the picture without changing the normal 320×240 2D placement.

The reusable calculation is in `lib/rt64-3ds/src/renderer/rt64_3ds_vi.h`; the integration is in `rt64_3ds_context.cpp`. `make test` runs ROM-free regression tests for both VI scanout and screen placement, including pitch changes, active 640-pixel modes, blanking, and 2D placement.

## ROM and redistribution

**No ROM or `baserom.z64.zip` is included.** Both the prebuilt program and a fresh build require your own matching, legally obtained US big-endian ROM:

| Requirement | Value |
|---|---|
| SD card path | `sdmc:/3ds/racer/baserom.z64` |
| Format / size | US `NEPE`, big-endian `.z64`, 32 MiB |
| Header CRC1 | `0x72F70398` |
| Runtime XXH3-64 | `0x9B89D0F9EBC12D32` |

The generated C/C++ directory `platform/3ds/generated/` is not included; regenerate it from your own ROM when rebuilding. **The supplied CIA and 3DSX nevertheless contain compiled game code and audio microcode derived from the ROM.** The raw ROM and game assets still have to be supplied separately at runtime. Do not redistribute the binaries unless you have the necessary rights. See `NOTICE` and the component license files.

## Installing

1. Create `sdmc:/3ds/racer/` and place your matching ROM there as `baserom.z64`. The game checks its hash before starting.
2. For Homebrew Launcher, copy `bin/Racer3DS.3dsx` to a folder under `sdmc:/3ds/` and launch it. Alternatively, copy `bin/Racer3DS.cia` to the SD card, install it with FBI or GodMode9, and launch **Star Wars Racer 3DS** from HOME Menu.
3. Saves and `settings.ini` are created beside the ROM. SELECT opens the port's settings menu. If an old `settings.ini` contains a `dbg_frame_w` override, remove it or set it to `0` to use the corrected automatic sizing.

The program uses the system's NDSP audio service; 3DS homebrew may require DSP firmware dumped from your own console. No firmware is supplied here.

Default controls: 3DS A/B map to N64 A/B, Y or ZL to Z, R or ZR to R, X to C-Up, C-Stick to C buttons, and Start, D-pad and Circle Pad to their N64 counterparts. Settings are adjustable on the touch screen.

## Build from source

Install a host C/C++ compiler, CMake 3.20+, Ninja or Make, Python 3 and devkitPro's `3ds-dev` toolchain (devkitARM, libctru, citro3d, picasso, `3dsxtool` and `smdhtool`). Put Project_CTR `makerom` on `PATH` for the CIA; `bannertool` is optional because `smdhtool` provides the icon fallback. Set `DEVKITPRO` and `DEVKITARM` for your installation. See `BUILDING.md` for complete prerequisites and options.

```sh
# Optional: the screen/VI tests need only a host C++20 compiler, not a ROM.
make test

# Build the vendored host recompilers; generate game code from your ROM.
make setup JOBS=1
make recompile ROM=/path/to/your/baserom.z64

# Cross-compile and package both formats. Increase JOBS if memory permits.
make JOBS=1
# Outputs: build-3ds/Racer3DS.3dsx and build-3ds/Racer3DS.cia
```

`make cia` and `make 3dsx` build the individual packages; `make clean` removes build outputs and `make distclean` also removes the ROM-derived generated sources. The source dependencies are vendored; the build itself does not fetch them from the network. The included binaries were built with devkitARM GCC 16.1.0, libctru/citro3d, `3dsxtool`, `smdhtool`, and makerom 0.19.0.

## Verification and limits

- The host `make test` geometry suites pass, including the 320/640-pitch transition and blanking fallback. A clean extraction also completed `make setup`, ROM recompilation, and the devkitARM cross-build of both formats.
- The included 3DSX was run in Azahar 2126.2 with the width override disabled. The startup/title 2D screen and a 3D selection-area scene were observed, and live VI logs showed both 320- and 640-pitch modes using a 320×240 picture. The original binary showed the 3D area at half width; the patched scene occupied the full intended 4:3 width.
- This is a targeted, limited emulator check, not an exhaustive playthrough. The emulator reported intermittent stalls and some graphical artifacts; other renderer issues, racing scenes and physical 3DS behavior remain to be tested. The CIA's extracted NCCH program was also booted to a startup screen in Azahar, but CIA installation itself was not tested. Audio was disabled/unavailable in the emulator because DSP firmware was absent, so sound was not reverified in this test.
- Panda3DS was also attempted, but the version tested stopped at an unimplemented system call before producing a frame. No claim of Panda3DS or on-hardware verification is made.

## Source layout

- `platform/3ds/` — game entry, host functions and 3DS CMake target.
- `lib/rt64-3ds/` — renderer, 3DS runtime, VI fix and host tests.
- `lib/N64ModernRuntime/` — patched runtime and vendored host recompilers.
- `recomp/` and `tools/3ds/` — ROM-recompilation configuration and scripts.
- `bin/` — newly built packages; `BUILDING.md` and `NOTICE` provide build and license details.
