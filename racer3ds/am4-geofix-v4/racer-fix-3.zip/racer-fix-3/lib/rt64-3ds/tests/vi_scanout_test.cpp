// ROM-free regression tests for the exact VI width calculation used by the
// 3DS renderer. Run with `make test` at the Racer source root.
#include <cmath>
#include <cstdint>
#include <cstdio>

#include "rt64_3ds_types.h"
#include "rt64_3ds_vi.h"

namespace {
int failures = 0;
void equal(const char* name, int got, int expected) {
    const bool pass = got == expected;
    std::printf("%-55s %4d expected %4d %s\n", name, got, expected, pass ? "ok" : "FAIL");
    if (!pass) ++failures;
}
void near(const char* name, float got, float expected) {
    const bool pass = std::fabs(got - expected) < 0.001f;
    std::printf("%-55s %7.3f expected %7.3f %s\n", name, got, expected, pass ? "ok" : "FAIL");
    if (!pass) ++failures;
}
constexpr uint32_t h(uint32_t start, uint32_t end) { return (start << 16) | end; }
}

int main() {
    using rt64_3ds::ScreenGeometry;
    using rt64_3ds::vi_geometry_width;
    using rt64_3ds::vi_scanout_width;
    constexpr uint32_t ntsc = h(108, 748); // 640 output clocks

    // The same source width for Racer's ordinary 320-pitch mode and the
    // 640-pitch mode that exposed the bug. Row pitch is deliberately NOT the
    // output width. A genuinely 640-pixel scanout must still be supported.
    equal("320 pitch, 0x200 scale -> 320 active pixels", vi_scanout_width(320, ntsc, 0x200), 320);
    equal("640 pitch, 0x200 scale -> 320 active pixels", vi_scanout_width(640, ntsc, 0x200), 320);
    equal("640 pitch, 0x400 scale -> 640 active pixels", vi_scanout_width(640, ntsc, 0x400), 640);
    equal("fractional 0x333 scale rounds 511.875 to 512", vi_scanout_width(640, ntsc, 0x333), 512);
    equal("X offset bits do not change window width", vi_scanout_width(640, ntsc, 0x01A00200), 320);
    equal("different active span changes the width", vi_scanout_width(640, h(100, 612), 0x200), 256);

    // Blank, unset and corrupt registers must not trigger a zero or huge
    // projection; a true 640-pixel mode remains in force until scanout returns.
    equal("blank VI has no active window", vi_scanout_width(640, 0, 0x200), 0);
    equal("zero step is invalid", vi_scanout_width(640, ntsc, 0), 0);
    equal("inverted active interval is invalid", vi_scanout_width(640, h(748, 108), 0x200), 0);
    equal("unset stride is invalid", vi_scanout_width(0, ntsc, 0x200), 0);
    equal("oversized scanout is invalid", vi_scanout_width(640, ntsc, 0xFFF), 0);
    equal("blank transition holds 640", vi_geometry_width(320, 0, 0x200, 640), 640);
    equal("active transition selects 320", vi_geometry_width(640, ntsc, 0x200, 640), 320);
    equal("active transition selects real 640", vi_geometry_width(640, ntsc, 0x400, 320), 640);
    equal("explicit width override wins", vi_geometry_width(640, ntsc, 0x400, 320, 400), 400);
    equal("override also works while blank", vi_geometry_width(640, 0, 0, 320, 400), 400);

    const ScreenGeometry two_d = ScreenGeometry::make_fit(320, 240, 4.0f / 3.0f);
    const int racer_active = vi_geometry_width(640, ntsc, 0x200, 320);
    const ScreenGeometry three_d = ScreenGeometry::make_fit(racer_active, 240, 4.0f / 3.0f);
    near("2D left", two_d.screen_x(0), 40);
    near("2D right", two_d.screen_x(320), 360);
    near("640-pitch 3D left matches 2D", three_d.screen_x(0), two_d.screen_x(0));
    near("640-pitch 3D right matches 2D", three_d.screen_x(320), two_d.screen_x(320));
    near("3D vertical scale remains unchanged", three_d.screen_y(240), 240);
    const ScreenGeometry old_bug = ScreenGeometry::make_fit(640, 240, 4.0f / 3.0f);
    near("old bug: 320 source pixels ended at screen x=200", old_bug.screen_x(320), 200);
    const ScreenGeometry real_wide = ScreenGeometry::make_fit(vi_scanout_width(640, ntsc, 0x400), 240, 4.0f / 3.0f);
    near("true 640 active-pixel mode still fits", real_wide.screen_x(640), 360);

    std::puts(failures ? "VI scanout regression FAILED" : "VI scanout regression passed");
    return failures != 0;
}
