// VI scanout geometry, shared by the 3DS renderer and ROM-free host tests.
#ifndef RT64_3DS_VI_H
#define RT64_3DS_VI_H

#include <cstdint>

namespace rt64_3ds {

// VI_WIDTH is the pitch, in source pixels, between adjacent RDRAM rows. It
// need not equal the number of pixels actually scanned out. H_START/H_END
// describe the active output interval; X_SCALE's low 12 bits are a 2.10
// fixed-point increment of source pixels per output pixel.
//
// Return the nearest integral number of source pixels in the active interval,
// or 0 when the VI is blank, unset or outside this renderer's supported
// geometry. Ignore X_SCALE's upper subpixel-offset field when measuring width.
// This measures the window; it does not emulate VI filtering or offsets.
inline int vi_scanout_width(uint32_t vi_width, uint32_t h_video, uint32_t x_scale) {
    const uint32_t stride = vi_width & 0xFFFu;
    const uint32_t start = (h_video >> 16) & 0x3FFu;
    const uint32_t end = h_video & 0x3FFu;
    const uint32_t step = x_scale & 0xFFFu;
    if (stride < 8u || end <= start || step == 0u) return 0;

    const uint32_t pixels = ((end - start) * step + 512u) / 1024u;
    return pixels >= 64u && pixels <= 800u ? static_cast<int>(pixels) : 0;
}

// Invalid/blank registers are common during osViBlack and mode transitions.
// Keep the last valid geometry (or the RenderDesc's initial geometry) until
// an active scanout arrives; a deliberate debug width always takes precedence.
inline int vi_geometry_width(uint32_t vi_width, uint32_t h_video, uint32_t x_scale,
                             int previous_width, int debug_width = 0) {
    if (debug_width > 0) return debug_width;
    const int active = vi_scanout_width(vi_width, h_video, x_scale);
    return active != 0 ? active : previous_width;
}

} // namespace rt64_3ds

#endif
