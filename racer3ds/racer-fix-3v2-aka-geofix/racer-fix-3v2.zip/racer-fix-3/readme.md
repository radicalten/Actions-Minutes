# Racer 3DS — full-frame top-screen fix

This is the Nintendo 3DS port of the [sp00nznet/racer](https://github.com/sp00nznet/racer) static recompilation of *Star Wars Episode I: Racer*, based on the source archive in [radicalten/Actions-Minutes4](https://github.com/radicalten/Actions-Minutes4). It includes the patched source, build tools, and newly compiled `bin/Racer3DS.3dsx` and `bin/Racer3DS.cia`. The project is unofficial and is not affiliated with the game's rightsholders.

## What changed

The renderer no longer treats `VI_WIDTH_REG` (the framebuffer's row pitch) as the displayed picture's width when following Racer's VI. It computes the active source width from the horizontal VI window and the low 12-bit, 2.10 fixed-point X scale:

```
visible source pixels = round((H_END - H_START) * X_SCALE / 1024)
```

For the affected mode observed in the emulator, the field stride is 640, the active window is 108–748, and the X scale is `0x200`: the source is **320**, not 640, pixels wide. The mode is serrated/interlaced and the doubled field stride skips alternate image rows. Its full display-list frame is **320×480**, not 320×240. Treating it as 240 lines cropped the lower part of menus such as the garage's main menu.

The renderer now switches automatically between the progressive 320×240 source and the 320×480 interlaced source, holding the last valid dimensions while the VI is blank or unset. This interlaced-height rule is explicitly enabled for Racer and is not a general-purpose VI emulator. Debug width and height overrides still take precedence.

Both modes are fitted to the entire **400×240 top screen**. To fill that wider screen without cutting anything off, the original 4:3 picture is stretched horizontally by 25%; this is not an expanded native widescreen view. Game render targets are assigned to the top screen only; the bottom screen remains the port's FPS/status/settings/debug console.

The reusable calculations are in `lib/rt64-3ds/src/renderer/rt64_3ds_vi.h`; the integration is in `rt64_3ds_context.cpp`. `make test` runs ROM-free regression tests for progressive/interlaced changes, blanking, debug overrides, full top-screen placement, and direct game-output routing.

## ROM and redistribution

**No ROM or `baserom.z64.zip` is included.** Both the prebuilt program and a fresh build require your own matching, legally obtained US big-endian ROM:

| Requirement | Value |
|---|---|
| SD card path | `sdmc:/3ds/racer/baserom.z64` |
| Format / size | US `NEPE`, big-endian `.z64`, 32 MiB |
| Header CRC1 | `0x72F70398` |
| Runtime XXH3-64 | `0x9B89D0F9EBC12D32` |

The generated C/C++ directory `platform/3ds/generated/` is not included; regenerate it from your own ROM when rebuilding. **The supplied CIA and 3DSX nevertheless contain compiled game code and audio microcode derived from the ROM.** The raw ROM and game assets still have to be supplied separately at runtime. Do not redistribute the binaries unless you have the necessary rights. See `NOTICE` and the component license files.

## Installing

1. Create `sdmc:/3ds/racer/` and place your matching ROM there as `baserom.z64`. The game checks its hash before starting.
2. For Homebrew Launcher, copy `bin/Racer3DS.3dsx` to a folder under `sdmc:/3ds/` and launch it. Alternatively, copy `bin/Racer3DS.cia` to the SD card, install it with FBI or GodMode9, and launch **Star Wars Racer 3DS** from HOME Menu.
3. Saves and `settings.ini` are created beside the ROM. SELECT opens the port's settings menu. If an old `settings.ini` contains `dbg_frame_w` or `dbg_frame_h`, remove those entries or set both to `0` and restart to use the corrected automatic sizing.

The program uses the system's NDSP audio service; 3DS homebrew may require DSP firmware dumped from your own console. No firmware is supplied here.

Default controls: 3DS A/B map to N64 A/B, Y or ZL to Z, R or ZR to R, X to C-Up, C-Stick to C buttons, and Start, D-pad and Circle Pad to their N64 counterparts. Settings are adjustable on the touch screen.

## Build from source

Install a host C/C++ compiler, CMake 3.20+, Ninja or Make, Python 3 and devkitPro's `3ds-dev` toolchain (devkitARM, libctru, citro3d, picasso, `3dsxtool` and `smdhtool`). Put Project_CTR `makerom` on `PATH` for the CIA; `bannertool` is optional because `smdhtool` provides the icon fallback. Set `DEVKITPRO` and `DEVKITARM` for your installation. See `BUILDING.md` for complete prerequisites and options.

```sh
# Optional: tests need a host C++20 compiler and Python 3, not a ROM.
make test

# Build the vendored host recompilers; generate game code from your ROM.
make setup JOBS=1
make recompile ROM=/path/to/your/baserom.z64

# Cross-compile and package both formats. Increase JOBS if memory permits.
make JOBS=1
# Outputs: build-3ds/Racer3DS.3dsx and build-3ds/Racer3DS.cia
```

`make cia` and `make 3dsx` build the individual packages; `make clean` removes build outputs and `make distclean` also removes the ROM-derived generated sources. The source dependencies are vendored; the build itself does not fetch them from the network. The included binaries were built with devkitARM GCC 16.1.0, libctru/citro3d, `3dsxtool`, `smdhtool`, and makerom 0.19.0.

## Verification and limits

- The ROM-free `make test` suites pass, including the 320×240-to-320×480 transition, full-screen edges, blanking fallback, debug overrides, and a source-level check that direct game outputs target the top screen. The host recompilers, ROM-code generation, and devkitARM builds of both formats completed successfully, including a rebuild from a clean ZIP extraction. Rebuilt hashes may differ because source paths are embedded; `SHA256SUMS` verifies the included binaries.
- The included 3DSX was run in Azahar 2126.2 with no width or height override. The 2D title, player and vehicle selection, and garage main menu were checked. The full main-menu list, from **Start Race** through **Options**, was visible on the top screen, which used the full width; the bottom screen showed the debug console. VI logs confirmed 320×240 progressive and 320×480 interlaced source geometries.
- This is a targeted emulator check, not an exhaustive playthrough or a physical-console test. On an attempted race, the HUD appeared but the 3D world was black, and the emulator reported long intermittent stalls; a working race was not verified. The preceding build showed the same black race scene in the same Azahar setup, but the underlying cause is not established. CIA installation was not tested. Audio was disabled/unavailable in the emulator because DSP firmware was absent, so sound was not reverified.
- Panda3DS was attempted during the preceding revision, but the version tested stopped at an unimplemented system call before producing a frame. No claim of Panda3DS or on-hardware verification is made.

## Source layout

- `platform/3ds/` — game entry, host functions and 3DS CMake target.
- `lib/rt64-3ds/` — renderer, 3DS runtime, VI fix and host tests.
- `lib/N64ModernRuntime/` — patched runtime and vendored host recompilers.
- `recomp/` and `tools/3ds/` — ROM-recompilation configuration and scripts.
- `bin/` — newly built packages; `BUILDING.md` and `NOTICE` provide build and license details.
