# Building Racer 3DS

## One-command build

After the one-time prerequisites below are installed, open a terminal in the
project folder and run:

```sh
./build.sh "/path/to/your/baserom.z64"
```

A ZIP containing exactly one `.z64` works too. Alternatively, put your own
`baserom.z64` or `baserom.z64.zip` in this folder and just run `./build.sh`.
The outputs are `build-3ds/Racer3DS.3dsx` and `build-3ds/Racer3DS.cia`.
The default is two parallel jobs; use `JOBS=4 ./build.sh "..."` to change it.
If the executable bit was lost during extraction, run `bash build.sh "..."`.

The script checks prerequisites and the full ROM SHA-256 before building. It
performs the three stages below automatically. No downloads or system package
installation are performed by the script. Linux was tested; macOS and Windows
via WSL may work, but were not tested.

## How it works

The build has three stages:

1. **host tools** — compile N64Recomp and RSPRecomp for the build machine
   (`tools/3ds/setup.sh`);
2. **recompilation** — turn your own ROM into C/C++ under the gitignored
   `platform/3ds/generated/` (`tools/3ds/recompile.sh`);
3. **cross build** — devkitARM compiles everything for ARMv6K and makerom
   packages `Racer3DS.cia` (CMake/Ninja).

Nothing in stages 1–2 needs devkitPro. After the prerequisites are installed,
the build does not touch the network: project source dependencies are vendored
in this tree, while the separate host and 3DS toolchains must be installed.

---

## 0. Prerequisites

### Host (stages 1–2)

- A host C/C++ compiler with C++20 support, CMake 3.20+, Make, Python 3.
  Ninja is optional and used automatically when available.
- Debian/Ubuntu or WSL Ubuntu: `sudo apt install build-essential cmake ninja-build python3`

### Target (stage 3)

A standard [devkitPro](https://devkitpro.org/wiki/Getting_Started) 3DS
installation:

```sh
# Debian/Ubuntu
wget https://apt.devkitpro.org/install-devkitpro-pacman
sudo bash install-devkitpro-pacman
sudo dkp-pacman -S --needed 3ds-dev
```

`3ds-dev` provides devkitARM (newlib for `arm-none-eabi`, including the
pthread/gloss glue), libctru, citro3d, and the `picasso`, `bin2s`,
`smdhtool` and `3dsxtool` tools. Separately install
[Project_CTR `makerom`](https://github.com/3DSGuy/Project_CTR/releases)
for your operating system and put it on `PATH` (or in
`$DEVKITPRO/tools/bin`) for the CIA; `bannertool` is optional. The build uses:

| Tool | Needed for | Required? |
|---|---|---|
| `arm-none-eabi-gcc/g++` | compiling the game, runtime and renderer | yes |
| libctru / citro3d | system and GPU libraries | yes |
| `picasso` | compiling `rt64_3ds.v.pica` into a shader object | yes |
| `bin2s` | embedding shader/data blobs | yes |
| `makerom` | building the `.cia` | yes for the CIA target |
| `bannertool` | optional CIA SMDH/banner generator | optional — `smdhtool` is used as the icon fallback |
| `3dsxtool` | building `.3dsx` | yes for the 3DSX target |
| `smdhtool` | creating the 3DSX icon and CIA icon fallback | yes for these build paths |

`build.sh` detects a standard `/opt/devkitpro` installation automatically.
For a custom location, set `DEVKITPRO` to the installation root; `DEVKITARM`
defaults to `$DEVKITPRO/devkitARM` and may also be set explicitly. If a tool
is missing, the script stops before compilation and names it. See the
[official devkitPro setup guide](https://devkitpro.org/wiki/Getting_Started)
for macOS and other platforms. Native Windows shells have not been tested;
Windows users can try WSL.

### Common problems

- **ROM not found:** pass the path in quotes or put `baserom.z64` (or
  `baserom.z64.zip`) in the project folder. A ZIP must contain one `.z64`;
  common macOS `__MACOSX` sidecars are ignored.
- **Wrong format or SHA-256:** use the supported US NEPE big-endian dump shown
  in `readme.md`. The script stops before compilation on a mismatch.
- **Missing devkitPro or makerom:** install the tools above; for a nonstandard
  devkitPro location set `DEVKITPRO` and add `makerom` to `PATH`, then retry.
- **Permission denied:** use `bash build.sh "/path/to/baserom.z64"` or run
  `chmod +x build.sh` once after extracting.
- **Build fails after a prior success:** output files in `build-3ds/` may be
  stale. Address the error and rerun; success is reported only after both
  requested packages have been built.

The following individual stages are optional for developers who need manual
control; the one-command build above already runs them.

## 1. Build the host recompilers

```sh
make setup                      # or: ./tools/3ds/setup.sh (--jobs N optional)
```

This configures and builds the vendored N64Recomp tree with a normal host
compiler and produces:

- `lib/N64ModernRuntime/N64Recomp/build/N64Recomp` — ROM → recompiled C;
- `lib/N64ModernRuntime/N64Recomp/build/RSPRecomp` — audio microcode → C++.

Re-runnable and ROM-free. The script only warns if devkitPro is missing; the
ARM build is the next stage.

## 2. Generate game code from your ROM

Bring your own legally obtained US ROM: `NEPE`, 32 MiB, big-endian `.z64`,
CRC1 `0x72F70398`, SHA-256
`8d6f85683b630e25385619af37197d48279366f6609bb6edc1201ff24c08b757`.
The ROM, generated C/C++, CIA and 3DSX are not in this source package.
Binaries you build contain compiled code derived from a ROM;
redistribute them only if you have the necessary rights. Source provenance,
including ROM-analyzed metadata and audio interpreter code, also needs review
before public release (see `NOTICE`).

```sh
make recompile ROM=/path/to/your/baserom.z64
# equivalent: ./tools/3ds/recompile.sh --rom /path/to/your/baserom.z64
```

The script, in order:

1. validates the ROM (magic `0x80371240`, size 33,554,432 bytes, CRC1 and
   full SHA-256); ZIP input is safely staged under a temporary filename;
2. runs `N64Recomp` with `recomp/recomp.toml`
   → `platform/3ds/generated/RecompiledFuncs/*.c` (+ `funcs.h`, `lookup.cpp`);
3. `recomp/tools/fix_fallthroughs.py` — repairs split-function continuations;
4. `recomp/tools/post_recomp_patches.py` — inserts the `osPiStartDma_recomp`
   and `racer_get_count` redirects;
5. runs `RSPRecomp` with `recomp/rsp/aspMain.toml`
   → `generated/rsp/aspMain.cpp` (stock ABI 1 audio microcode);
6. `recomp/tools/gen_lookup_table.py`
   → `generated/section_table.cpp`.

Generated sources land in `platform/3ds/generated/` (gitignored). The build
normally removes its temporary ROM copy on exit; your original is not changed.
Do not put the input inside `build/recomp-work/` or `platform/3ds/generated/`:
those staging folders may be replaced. Use `make distclean` to remove generated
sources and scratch work.

## 3. Cross-compile and package

The root `Makefile` wraps every command in this section (it picks Ninja when
available, otherwise the Unix Makefiles generator, and checks that
`DEVKITPRO` is set):

```sh
make                                  # configure + build + .cia and .3dsx
make cia                              # Racer3DS.cia only
make 3dsx                             # Racer3DS.3dsx only
make BUILD_DIR=out cia                # use a different build directory
make clean                            # delete the build tree
make distclean                        # also delete platform/3ds/generated/
make recompile ROM=/path/baserom.z64 # stage 2 only; run make afterward
```

The underlying CMake commands, which the Makefile runs for you:

```sh
cmake -S platform/3ds -B build-3ds -G Ninja \
      -DCMAKE_TOOLCHAIN_FILE=$PWD/lib/rt64-3ds/cmake/devkitARM-3ds.cmake
cmake --build build-3ds -j
cmake --build build-3ds --target Racer3DS_cia
```

Outputs in `build-3ds/`:

| File | What it is |
|---|---|
| `Racer3DS` | the linked ARM ELF (hard-float, entry `0x100000`) |
| `Racer3DS.cia.smdh` | HOME Menu icon/metadata, made by `bannertool` or `smdhtool` |
| `Racer3DS.cia` | installable CIA (NCCH content + SMDH meta), made by `makerom` |
| `Racer3DS.3dsx` (+ `.smdh`) | hbmenu build, only when `3dsxtool` is on `PATH` |
| `Racer3DS.rsf` | the RSF generated from `lib/rt64-3ds/cia/template.rsf` |

The CIA title is **Star Wars Racer 3DS**, product code `RACER-3DS`, UniqueId
`0xF9048`. Its exheader requests 64 MB SystemMode (Old 3DS) and 124 MB
SystemModeExt with the 804 MHz/L2-cache profile when run on a New 3DS.

### CMake options

| Option | Default | Effect |
|---|---|---|
| `RACER_NULL_RENDERER=ON` | OFF | Parse display lists but draw nothing (headless logic/audio bring-up) |
| `RACER_GPR32=ON` | OFF | Compile with `RECOMP_GPR32` (one ARM instruction per N64 register op). Only legal when the generated code contains no 64-bit register instruction; the configure-time source audit fails and names the offending line if it is ineligible |

### Verifying the artefact

```sh
arm-none-eabi-readelf -h build-3ds/Racer3DS     # ARM, Version5 EABI, hard-float ABI
```

A successful makerom run ends with `Racer3DS.cia` containing an `NCCH`
partition and the embedded `SMDH` metadata. Rebuilding from another directory
or toolchain can change the binary hashes: the compiler embeds some absolute
source paths. This source package does not include prebuilt files.

## 4. Install

1. Copy `build-3ds/Racer3DS.cia` to the SD card and install with FBI or
   GodMode9.
2. Put the ROM at `sdmc:/3ds/racer/baserom.z64`. The runtime XXH3-hashes it
   (`0x9B89D0F9EBC12D32`) and refuses a mismatch; a missing ROM shows the
   expected path instead of starting the game. The on-SD name is set by
   `GameEntry::rom_filename_override` in `platform/3ds/main_3ds.cpp`; without
   an override the runtime looks for `<game_id>.z64`.
3. Launch **Star Wars Racer 3DS** from the HOME Menu. Saves and
   `settings.ini` are written next to the ROM.

---

## Appendix A: building without dkp-pacman

The supported path is the pacman `3ds-dev` group above. The build has also
been verified against a hand-assembled prefix where the distro
(`gcc-arm-none-eabi` 14.x) compiler is combined with devkitPro's own newlib
fork. If you go that route, every one of the following is required; a plain
distro newlib is not enough because libctru depends on devkitPro's reentrant
and pthread extensions.

1. **devkitPro newlib, hard-float.** Build the
   [devkitPro/newlib](https://github.com/devkitPro/newlib) `devkitPro` branch
   for `arm-none-eabi` with
   `CFLAGS_FOR_TARGET="-march=armv6k -mtune=mpcore -mfloat-abi=hard -mfpu=vfp -mtp=soft"`
   and `--disable-newlib-supplied-syscalls --enable-newlib-mb
   --disable-newlib-wide-orient --enable-newlib-register-fini
   --disable-multilib`. Soft-float libraries will not link against the VFP
   objects. The install provides `libc.a`, `libsysbase.a` (the libgloss glue
   with `__getreent`, the `_*_r` syscall stubs, `pthread_create`, `sleep`,
   `usleep`) and `sysbase.specs`.
2. **Link with `sysbase.specs`.** It appends
   `--start-group -lc -lsysbase --end-group` after the driver's own sequence,
   which is the only ordering in which the gloss glue resolves. Pass
   `-specs=<prefix>/arm-none-eabi/lib/sysbase.specs` from compiler wrapper
   scripts alongside the usual `-specs=3dsx.specs`.
3. **Threads and C11 headers.** Distro libstdc++ is configured
   single-threaded for bare metal: switch its multilib `bits/gthr-default.h`
   to `#include "gthr-posix.h"`, expose the timed pthread prototypes with
   `-D_POSIX_TIMEOUTS=200112L`, and restore the two libstdc++ feature macros
   the distro configure left unset: `-D_GLIBCXX_HAS_GTHREADS=1
   -D_GLIBCXX_HAVE_ALIGNED_ALLOC=1`.
4. **libctru, citro3d and the packaging tools**, built/installed into the same
   prefix: libctru (its assembly needs `-x assembler-with-cpp`, and the
   `bin2o` header rule must emit `$(*)_bin.h`), citro3d, plus `picasso`,
   `bannertool` and a `makerom` binary (for example the Project_CTR Ubuntu
   release).
5. Point `DEVKITPRO` at the prefix and use the same CMake commands as the
   standard flow.

## Appendix B: cleaning

```sh
rm -rf build-3ds                                              # cross build only
rm -rf platform/3ds/generated build/recomp-work               # ROM-derived outputs
rm -rf lib/N64ModernRuntime/N64Recomp/build                   # host recompilers
```

---

## Appendix C: what this build-only distribution leaves out

This repository is trimmed to the files the three-stage build actually
touches, together with its tests and component notices. License texts are kept
with their components; some header-only components carry terms in the header.
The full upstream trees remain available from their original repositories.
`NOTICE` records additional provenance questions that require review.

Removed because no target in `Makefile` / `setup.sh` builds them:

- N64Recomp's `RecompModTool`, `RecompModMerger`, `OfflineModRecomp` and
  `LiveRecomp`/`LiveRecompTest` executables and their `lib/sljit` dependency
  (the corresponding `add_executable` blocks are removed from
  `N64Recomp/CMakeLists.txt`, with an explanatory comment);
- test suites, documentation, examples and CI metadata from the vendored
  dependencies (rabbitizer, fmt, tomlplusplus, ELFIO, miniz, o1heap, xxHash),
  plus rabbitizer's Python/Rust bindings;
- most rt64-3ds developer tools and tests; the ROM-free geometry, VI, forced
  matrix, NoN clipping, fade, audio policy, controls and screen-routing tests
  needed by `make test` are included;
- all build trees, object files, prebuilt CIA/3DSX packages and the ROM-derived
  `platform/3ds/generated/` (regenerated by `make recompile`).

Nothing used by `make setup`, `make recompile`, `make`, `make cia` or
`make 3dsx` is removed: after generating sources from your own ROM, a clean
source tree builds both `Racer3DS.cia` and `Racer3DS.3dsx` without fetching
source dependencies from the network.
