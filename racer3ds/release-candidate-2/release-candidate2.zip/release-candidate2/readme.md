# Racer 3DS

This is an unofficial Nintendo 3DS port of [sp00nznet/racer](https://github.com/sp00nznet/racer), based on the source archive in [radicalten/Actions-Minutes4](https://github.com/radicalten/Actions-Minutes4). It contains patched source, a Makefile, build instructions, tests and component license notices. It is not affiliated with the game's rightsholders.

This source package contains **no ROM, generated game C/C++ or prebuilt CIA/3DSX**. Its source does include ROM-analyzed symbol metadata and audio interpreter code with microcode-related provenance; see [ROM and redistribution](#rom-and-redistribution) and `NOTICE` before publishing.

## Build in one command

After installing the one-time prerequisites in [BUILDING.md](BUILDING.md)—a host C/C++ compiler, Python 3, CMake, Make, devkitPro `3ds-dev`, and Project_CTR `makerom`—open a terminal in this folder and run:

```sh
./build.sh "/path/to/your/baserom.z64"
```

You can instead pass a ZIP containing one `.z64` file, or place `baserom.z64` / `baserom.z64.zip` in this folder and run `./build.sh` with no arguments. If your unzip program did not preserve executable permissions, use `bash build.sh ...`. The script validates the ROM, builds the host tools, and creates **both** `build-3ds/Racer3DS.3dsx` and `build-3ds/Racer3DS.cia`. It does not install tools or download a ROM. The first build may take several minutes.

Linux was tested. macOS and Windows via WSL may work with the same prerequisites but have not been tested. For details and troubleshooting, see `BUILDING.md`.

## What changed

- **Close geometry:** Racer identifies its graphics microcode as `F3DEX.NoN`. The Racer-only renderer option now keeps geometry between the viewer and the ordinary near plane instead of discarding it. Behind-eye geometry and the GPU guard band are still clipped. Triangles crossing the near plane are split, and only the near part has its depth clamped just inside the GPU boundary. This restores close-up pods in a captured intro and the missing first-person engines in Azahar. It is an approximation of NoN's depth behavior, not a claim of perfect N64 RSP emulation.
- **Transition fade:** the observed black fade was a textured rectangle ending one pixel short of the 320×480 frame. Only the identified full-frame black fade using a solid white texel row is extended across the 400-pixel top screen. Unrelated 4:3 artwork is not enlarged by this fix.
- **Race world:** F3DEX2's `gSPForceMatrix` combined modelview-projection command is handled, fixing the earlier black race world. Ordinary matrix loads take over again afterward; unsafe interpolation of a forced matrix is declined.
- **Screen shape:** Racer's active width is calculated from its VI horizontal window and X scale, not the framebuffer's row stride. Its doubled interlaced stride uses a 320×480 display-list frame; progressive screens use 320×240. Invalid/blank VI windows retain the last valid geometry. The original picture keeps its proportions in the centered 320×240 area of the 400×240 top screen. Near-edge full-view scissors can expose already-submitted 3D geometry in the 40-pixel side margins without stretching the image. Side gaps are still possible when the game itself does not submit geometry, and some cutscenes are letterboxed. All game output is on top; FPS, status, settings, and debug information are on the bottom.
- **Controls and audio:** Racer has the button map below. The audio reserve has been reduced and a stale-NDSP-queue recovery added as an **experimental** latency mitigation; see the audio section for its limitations and rollback.

`make test` runs ROM-free tests for VI sizing, un-stretched geometry, scissors, forced matrices, NoN clipping, the targeted fade, audio queue policy, controls, top-screen routing, and safe ROM/ZIP handling.

## ROM and redistribution

**No ROM, ROM archive, DSP firmware, ROM-generated C/C++, CIA or 3DSX is included.** Building and running the program require your own matching, legally obtained US big-endian ROM:

| Requirement | Value |
|---|---|
| SD card path | `sdmc:/3ds/racer/baserom.z64` |
| Format / size | US `NEPE`, big-endian `.z64`, 32 MiB |
| Header CRC1 | `0x72F70398` |
| Build-time SHA-256 | `8d6f85683b630e25385619af37197d48279366f6609bb6edc1201ff24c08b757` |
| Runtime XXH3-64 | `0x9B89D0F9EBC12D32` |

Regenerate `platform/3ds/generated/` locally from your own ROM. Resulting CIA and 3DSX files contain compiled game code and audio microcode derived from that ROM; do not redistribute them without the necessary rights. The raw ROM remains necessary at runtime.

The source is not a certified clean-room implementation. `recomp/symbols.toml` contains metadata obtained through ROM analysis, and the vendored `aspmain_hle.cpp` and `naudio_hle.cpp` describe command semantics transcribed from recompiled microcode for other games. Racer uses the former. Review these components and all licenses and rights before publishing; see `NOTICE` and `licenses/`.

## Installing

1. Put your matching ROM at `sdmc:/3ds/racer/baserom.z64`. The game checks its hash.
2. Build the program as described below. For Homebrew Launcher, copy `build-3ds/Racer3DS.3dsx` to a folder under `sdmc:/3ds/` and launch it. Alternatively, copy `build-3ds/Racer3DS.cia` to the SD card, install it with FBI or GodMode9, and launch **Star Wars Racer 3DS** from HOME Menu.
3. Saves and `settings.ini` are created beside the ROM. SELECT opens the port's settings. If an old `settings.ini` contains `dbg_frame_w` or `dbg_frame_h`, remove those entries or set both to `0` and restart for automatic sizing.

## Controls

| 3DS control | N64 input / use |
|---|---|
| Circle Pad | Analog stick |
| A / B | A / B |
| D-pad up / down / left / right | C-up / C-down / C-left / C-right |
| X | C-up |
| Y or ZL | Z (slide) |
| L | N64 L (map/progress display) |
| R or ZR | R (repair) |
| C-Stick (New 3DS) | C directions |
| START / SELECT | N64 Start / port settings |

The D-pad is the only change from the port's original button scheme: no physical control sends N64 D-pad bits. The D-pad is used by the settings menu while that menu is open. On Old 3DS, Y supplies Z/slide and L supplies N64 L.

## Audio latency and diagnostics

Racer keeps asynchronous audio tasks, but its reported reserve was reduced from four video frames to two (about 33 ms less at 60 Hz). If the NDSP queue **alone** exceeds 300 ms when a new buffer arrives, the stale queue is cleared before newer audio is submitted. Clearing may cause an audible skip or click; the threshold is not a guarantee of end-to-end latency, since a new buffer and upstream processing add time. Recovery is logged as `audio backlog recovery` in `sdmc:/3ds/racer/log.txt`.

**Audio was not verified:** Azahar in this test environment had no DSP firmware, so the approximately one-second reported delay may not be fixed, especially if it originates upstream of NDSP. No physical 3DS or listening test was available. Homebrew NDSP may require DSP firmware dumped from your own console; none is supplied.

If the reduced reserve crackles or the recovery skips too much, put the following in `sdmc:/3ds/racer/settings.ini` and restart to restore the prior queue policy:

```ini
dbg_audio_margin_frames=4
dbg_audio_max_queued_ms=0
```

Remove those two lines (or set them to `-1`) and restart to return to this build's defaults. The second value is milliseconds; `0` disables recovery. `dbg_rows=1` shows audio queue/underrun counters on the bottom screen; with `log_level=2`, `log.txt` also records the sample rate, queued sample frames, underruns and dropped frames. For example, queued frames divided by sample rate estimates the NDSP portion of the delay; it does not measure the whole audio pipeline.

## Tests and advanced builds

Run `make test` for the ROM-free regression suite. `JOBS=4 ./build.sh "/path/to/baserom.z64"` changes the default parallelism of two jobs. `./build.sh --help` shows usage; `BUILDING.md` covers individual stages, dependency installation and troubleshooting. `make clean` removes build outputs, while `make distclean` also removes generated sources.

Source dependencies are vendored. The tested build used devkitARM GCC 16.1.0, libctru/citro3d, `3dsxtool`, `smdhtool`, and makerom 0.19.0. Rebuilds can differ because source paths and toolchain versions affect the output.

## Verification and limits

- ROM-free `make test` passed. The one-command builder produced both formats from a clean Linux extraction using a ZIP and paths with spaces, and again with its default raw-ROM input. The resulting 3DSX reached the title menu in Azahar 2126.2.
- In earlier checks of the same game/runtime source, a captured intro replay showed previously missing close pod geometry; an A/B replay showed the missing first-person engines restored. The captured fade rectangle changed from the central 320 pixels to the full 400-pixel width without widening unrelated artwork in the synthetic tests.
- The previous 3DSX was run in Azahar 2126.2: title, garage, race intro, first-person engines, low camera and nearby track were inspected. Both X and D-pad up changed the camera as C-up; the D-pad rear-view mapping was also checked in an earlier build. A captured transition showed the fade reaching both side margins. The previous CIA installed in Azahar and its installed content reached the 3D attract sequence.
- These are targeted emulator checks, not a complete race/playthrough. Azahar reported intermittent main-thread stalls, and wider edges can expose missing geometry or clear-color gaps. Close clipping and performance across every scene, physical-console operation, and audio remain unverified. The smaller audio reserve may cause underruns on slower hardware.
- Panda3DS was attempted during an earlier revision but stopped at an unimplemented system call before producing a frame. No Panda3DS or physical-hardware verification is claimed.

## Source layout

- `platform/3ds/` — Racer entry, controls, host functions and 3DS CMake target.
- `lib/rt64-3ds/` — renderer, 3DS platform runtime and ROM-free tests.
- `lib/N64ModernRuntime/` — patched runtime and vendored host recompilers.
- `build.sh`, `recomp/`, `tools/3ds/` — one-command builder, recompilation configuration and scripts.
- `BUILDING.md`, `NOTICE`, `licenses/` — build instructions and provenance/license details. The component license files in `lib/` also apply.
