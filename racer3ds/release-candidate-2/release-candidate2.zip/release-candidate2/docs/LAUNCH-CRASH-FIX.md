# The launch crash: what it was, and what fixed it

Written up separately from `RT64-3DS-PORT.md` because the diagnosis is the part that is
easy to lose, and because both findings are landmines for the next port.

## The symptom

The `.3dsx` (and the `.cia`) died within a second of booting, and under emulation the fault
landed in libctru's `hidScanInput` — which is not where the trouble starts. The crash dump
that came off a console cannot be matched to this source tree (its code pages do not line up
with any build of it, so treat that dump as a different build's), but the failure shape is
the same one reproduced here exactly:

```
[FATAL] Unimplemented 32-bit read, addr: 00000010
   ... in hidScanInput (libctru-2.7.0/libctru/source/services/hid.c:179)
```

`hid.c:179` is `Id = hidSharedMem[4]` — a read of offset `0x10` from a **null**
`hidSharedMem`. `hidSharedMem` lives in the app's own `.bss`; something had cleared it.
Tracing it took two hooks in an emulator (see "How this was found" at the bottom).

## Finding 1 — a wild RDRAM access, not a HID bug

`librecomp/addresses.hpp` gives the 3DS the game's RDRAM as one committed block, and it
says so:

```cpp
#if defined(__3DS__)
    // The 3DS commits all of this, so it is only the game's 8 MB, the patch RAM
    // above it (RAMBASE 0x80801000 in the patches' linker script) and the
    // recomp heap.
    constexpr size_t mem_size = 16 MB;
    constexpr size_t allocation_size = mem_size;   // <-- no guard region
#else
    constexpr size_t mem_size = 512 MB;             // kseg0, readable/writable
    constexpr size_t allocation_size = 4096 MB;     // the rest faults, on purpose
#endif
```

On a desktop the runtime reserves the whole 4 GB guest address space, commits only the
RDRAM window and lets the rest be a guard region, so an access that is *not* RDRAM is
either scratch memory or a caught fault. `recomp.h`'s accessor does no more than subtract
the window base:

```c
#define RECOMP_RDRAM_OFFSET(addr) ((uint32_t)(addr) - 0x80000000u)   /* 32-bit model */
```

Racer pokes hardware registers directly, from its own audio driver at `0x8008BF3C`:

| guest address | what it is | offset into a 16 MB `rdram` |
|---|---|---|
| `0xA4400024` | `VI_...` | `0x24400024` — 580 MB past the block |
| `0xA4600014` … `0xA4600030` | `AI_DACRATE`, `AI_BITRATE`, `AI_BADDR`, `AI_COUNT`, `AI_CONTROL` | same order of magnitude |

Those stores are the kseg1 alias of the RCP registers. `0x24400024` is not "out of bounds"
in the C sense on the 3DS — there is no MMU protection to hit, so each one wrote the
game's register values into whatever the allocator had placed 580 MB further along: the
port's own heap, its `.bss`, service state. `ndsp`/`hid` handles, the settings vector, a
`std::string`'s buffer — anything. The HID global happened to be one of the victims, and
the crash appeared in the next thread that touched input. The dump therefore names a
libctru function, three frames and several seconds away from the store that did it.

### The fix: bounds guard the window

`N64Recomp/include/recomp.h` now checks the offset it is about to use, and
`librecomp/src/recomp.cpp` folds the out-of-range ones into a scratch tail that
`addresses.hpp` appends to the allocation:

```c
#define RECOMP_RDRAM_SIZE  (RECOMP_MEM_SIZE_MB * 1024 * 1024)     // the window
#define RECOMP_RDRAM_SCRATCH_SIZE 0x100000                          // 1 MB, after it

#define RECOMP_RDRAM_OFFSET(addr) \
    (__builtin_expect((uint32_t)(off) < RECOMP_RDRAM_SIZE, 1) \
        ? (uint32_t)(off) : recomp_rdram_guard((uint32_t)(addr), (uint32_t)(off)))
```

* The good path costs one compare against a constant; the check is on the same value the
  accessor already computes.
* `recomp_rdram_guard()` returns `mem_size + (off & (SCRATCH - 1))`, so a wild access
  reads and writes scratch that nothing else uses — the desktop's behaviour, kept at
  3DS scale — and cannot reach the host heap.
* The first 32 *distinct* addresses are logged with the caller's host address, which
  `addr2line` turns into the name of the recompiled function that made the access; a
  running total is echoed every 16384 accesses. That turns "the port is silent on X" into
  a list in `log.txt`.
* Define `RECOMP_RDRAM_NO_GUARD` to drop it (a title audited to touch only RDRAM can have
  the compare back). `platform/3ds/CMakeLists.txt` forwards `RECOMP_MEM_SIZE_MB` to
  `RecompiledFuncs` so the guard's window is always the runtime's window; getting that
  pair out of step is the one way this can go wrong.

Every RDRAM touch in the runtime goes through these macros — the recompiled game's loads
and stores, the RSP's `RSP_MEM_*`, the SI/PI save transfers — so one check covers them all.

## Finding 2 — an exception that could only end badly

The corrupted global was not the only problem in that crash. `librecomp/src/pi.cpp` had:

```cpp
void read_save_file() {
    std::filesystem::path save_file_path = ultramodern::get_save_file_path();
    std::filesystem::create_directories(save_file_path.parent_path());   // throws
```

On the game thread that call failed (`ENOTDIR` under an emulator whose FS service does
not implement `FSUSER_RenameDirectory`; on hardware a full or read-only card would do it
too). `create_directories` without an `error_code` **throws**. Nothing on that thread
catches, so:

```
__cxa_throw → std::terminate → abort → exit → __ctru_exit → __appExit
   → hidExit() → svcUnmapMemoryBlock(0x10000000); hidSharedMem = NULL
```

`__appExit` frees the services — closes handles, unmaps the HID shared memory — **while the
game, renderer, audio and ROM-stream threads are still running**. Whichever of them next
calls into a freed service faults, and that is the crash that gets reported. This is the
reason the port's launch crash looked like a HID bug: it was two failures stacked, the
second one produced by the exit path of the first.

Two changes, both general:

1. **No throwing filesystem call on a device path.** `pi.cpp`'s `create_directories`, and
   the two `std::filesystem::remove` calls plus two more `create_directories` in
   `recomp.cpp`, take the `std::error_code` overload and log. A save directory that
   cannot be made is now a line in `log.txt` and possibly a lost save, not a dead game:
   `[save] could not create the directory for …: Not a directory (saving may be lost)`
2. **A termination reporter** (`lib/rt64-3ds/src/platform/recomp3ds_run.cpp`), installed
   in `run()` before any host thread exists. It prints the exception (`filesystem_error`
   gets both paths quoted), flushes, and calls `svcExitProcess()` — *not* `exit()`, so
   `__appExit` never runs under the other threads. Any future uncaught error names itself
   in the log instead of showing up as someone else's crash.

## What it does now

Under Panda3DS (null renderer, so no picture — this is about the CPU/GPU-side boot):

* before: `[FATAL] Unimplemented 32-bit read, addr: 00000010` about one second after
  `Initializing recomp heap at offset 0x00A00000 with size 0x00600000`;
* after: the full boot, then frames. The log continues past `init_saving` into the game,
  and the renderer reports real display lists: `rt64-3ds: progress: frame 421 phase 0
  draw 145 of 146`, 400+ frames in 180 s at emulated speed, with the game blanking and
  restoring its own video across loading screens (`video blanked at frame 418`,
  `video shown at frame 421`). No fatal, no panic, and the process was still alive when
  the test harness killed it.
* The only accesses the guard folds away are the register pokes in the table above. Nothing
  else leaves the window, which is the evidence that the guard — not a lucky allocator
  layout — is what stopped the corruption.

## Closed since: the audio claim in this file was wrong

This section predicted silence on a console. It was wrong, and the reason is worth keeping
so the same mistake is not made again: the port does not feed ndsp from the AI registers.
The game's `aspMain` runs as recompiled code (or, as configured here, as
`AudioHle::Aspmain` — the same microcode interpreted on the CPU), and *that* is what writes
the PCM into ndsp's buffers. `desc.audio_async` and a reserve cushion its task timing;
the current release uses two video frames of margin and an experimental stale-queue
recovery, neither yet listening-tested (see `readme.md`). `AI_DACRATE`, `AI_BITRATE`, `AI_BADDR`, `AI_COUNT` and `AI_CONTROL` are
therefore only read by the game, not consumed by the port; making those writes harmless was
about memory safety, and had nothing to do with whether sound plays. This inherited
note recorded an earlier hardware observation of audio and 18–21 fps; it was not
reproduced for the current release, which has not been tested on hardware.

What is left for the game's own audio, if it ever needs attention, is not silence but
fidelity: an AI handler would let the port honour the game's own DMA pacing and any
`AI_IMM`-style interrupt counting rather than the port's task-driven hand-over.

Two smaller things to keep in mind:

* `ndspInit` needs `sdmc:/3ds/dspfirm.cdc` on the card. The port already degrades to
  "audio off" with a log line when it is missing; keep that behaviour.
* The port's stall watchdog can say `STALL: the main thread has not run for 3.2 s` under
  an emulator. The current release showed intermittent stalls, whose cause is not yet
  established; check game progress and logs rather than assuming a host-only cause.

## How this was found (worth repeating for the next one)

Guest-side, in the port: log early, log everything, and put a `fprintf(stderr, ...)`
breadcrumb at each boot stage — `log.txt` on the card and `svcOutputDebugString` for the
emulator. The last line before the crash (`Initializing recomp heap`) is what pointed at
`init_saving`, one call later.

Host-side, in the emulator (test scaffolding only, never needed on a console):
* `MyEnvironment::MemoryRead32/Write32` in `include/cpu_dynarmic.hpp` printed the guest
  register file when a fallback access went to a bogus address — that is how the faulting
  instruction became `ldr r1,[r3,#16]` with `r3 = 0`, and `arm-none-eabi-addr2line`
  against `build-3ds/Racer3DS` named `hidScanInput`. The `.3dsx` loads Text at
  `0x00100000`, exactly the ELF's virtual addresses, so guest PCs resolve directly.
* `Helpers::warn` in `Kernel::unmapMemoryBlock` was extended to dump the guest PC, LR and
  the code-shaped words on the stack; addr2line-ing that list gave the whole chain:
  `hidExit` ← `__appExit` ← `__ctru_exit` ← `std::terminate` ← `__cxa_throw` ←
  `create_directories` ← `read_save_file`.
* Note that Panda3DS hooks only unmapped/MMIO pages, so a wild *store into RAM* is
  invisible to it; that is why watching the victim address produced nothing and the SVC
  dump is what cracked it.
