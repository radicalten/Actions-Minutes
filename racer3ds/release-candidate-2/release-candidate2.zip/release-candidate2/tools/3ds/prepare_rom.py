#!/usr/bin/env python3
"""Validate the supported ROM and, if needed, stage one ZIP member safely.

The ROM and generated game code are private user-supplied inputs. This tool
never downloads a ROM and never extracts a ZIP using member-supplied paths.
"""

import argparse
import hashlib
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

EXPECTED_SIZE = 33_554_432
EXPECTED_MAGIC = bytes.fromhex("80371240")
EXPECTED_CRC1 = 0x72F70398
# This is the exact US NEPE revision accepted by the runtime's XXH3 check.
EXPECTED_SHA256 = "8d6f85683b630e25385619af37197d48279366f6609bb6edc1201ff24c08b757"


def is_within(path, parent):
    """Resolve symlinks and reject inputs inside a directory we will replace."""
    try:
        return os.path.commonpath((str(path), str(parent.resolve()))) == str(parent.resolve())
    except ValueError:  # Different drives on Windows.
        return False


def validate_stream(stream, size, label, output=None):
    if size != EXPECTED_SIZE:
        raise ValueError(f"{label}: expected {EXPECTED_SIZE} bytes, got {size}")
    header = stream.read(64)
    if len(header) < 20:
        raise ValueError(f"{label}: file is too short for an N64 header")
    if header[:4] != EXPECTED_MAGIC:
        raise ValueError(f"{label}: expected a big-endian .z64 ROM (magic 80371240)")
    crc1 = int.from_bytes(header[16:20], "big")
    if crc1 != EXPECTED_CRC1:
        raise ValueError(f"{label}: header CRC1 is {crc1:08X}, expected {EXPECTED_CRC1:08X} (US NEPE)")
    digest = hashlib.sha256()
    digest.update(header)
    total = len(header)
    if output is not None:
        output.write(header)
    while True:
        block = stream.read(1024 * 1024)
        if not block:
            break
        total += len(block)
        if total > EXPECTED_SIZE:
            raise ValueError(f"{label}: data exceeds the expected ROM size")
        digest.update(block)
        if output is not None:
            output.write(block)
    if total != EXPECTED_SIZE:
        raise ValueError(f"{label}: incomplete data ({total} of {EXPECTED_SIZE} bytes)")
    if digest.hexdigest() != EXPECTED_SHA256:
        raise ValueError(f"{label}: SHA-256 does not match the supported US NEPE ROM; no build was started")


def prepare(source, temp_dir=None, reject_under=()):
    source = Path(source).expanduser().resolve(strict=True)
    if not source.is_file():
        raise ValueError(f"not a regular file: {source}")
    for directory in reject_under:
        if is_within(source, Path(directory)):
            raise ValueError(f"move the ROM or ZIP out of the generated/build staging folder: {directory}")

    if not zipfile.is_zipfile(source):
        with source.open("rb") as stream:
            validate_stream(stream, source.stat().st_size, str(source))
        return source

    if temp_dir is None:
        raise ValueError("ZIP input requires a private staging directory")
    destination = Path(temp_dir).resolve() / "baserom.z64"
    with zipfile.ZipFile(source) as archive:
        candidates = []
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            parts = PurePosixPath(name).parts
            if info.is_dir() or not name.lower().endswith(".z64"):
                continue
            # Common macOS sidecar files are not ROMs.
            if "__MACOSX" in parts or PurePosixPath(name).name.startswith("._"):
                continue
            if name.startswith("/") or ".." in parts:
                raise ValueError("ZIP contains an unsafe .z64 member path")
            if stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError("ZIP ROM member must be a regular file, not a symbolic link")
            candidates.append(info)
        if len(candidates) != 1:
            raise ValueError(f"ZIP must contain exactly one .z64 ROM (found {len(candidates)})")
        member = candidates[0]
        created = False
        try:
            # Fixed output name: archive paths are never used for extraction.
            # Never remove a pre-existing file if exclusive creation fails.
            with archive.open(member) as stream:
                with destination.open("xb") as output:
                    created = True
                    validate_stream(stream, member.file_size, member.filename, output)
        except Exception:
            if created:
                try:
                    destination.unlink()
                except FileNotFoundError:
                    pass
            raise
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser(description="Validate or privately stage the supported Racer ROM")
    parser.add_argument("source", help="user-supplied .z64 ROM or ZIP containing one .z64")
    parser.add_argument("--temp-dir", help="private empty directory for ZIP extraction")
    parser.add_argument("--reject-under", action="append", default=[], metavar="DIR",
                        help="reject an input inside a directory that will be replaced")
    args = parser.parse_args(argv)
    try:
        result = prepare(args.source, args.temp_dir, args.reject_under)
    except (OSError, ValueError, RuntimeError, EOFError, zipfile.BadZipFile) as exc:
        print(f"ROM error: {exc}", file=sys.stderr)
        return 2
    print("ROM verified: supported US NEPE, big-endian, exact SHA-256.", file=sys.stderr)
    # stdout is intentionally just the path, for the build scripts.
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
