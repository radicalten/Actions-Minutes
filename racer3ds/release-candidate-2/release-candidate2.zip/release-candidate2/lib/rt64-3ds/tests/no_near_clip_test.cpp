// ROM-free tests of F3DEX.NoN's eye-plane clipping and depth clamp.
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

#include "rt64_3ds_dl.h"

namespace {
constexpr uint32_t kList = 0x1000, kMatrix = 0x2000, kVerts = 0x3000;
int failures = 0;
void check(const char* name, bool ok) {
    std::printf("%s: %s\n", name, ok ? "ok" : "FAIL");
    failures += !ok;
}
void word(std::vector<uint8_t>& r, uint32_t a, uint32_t v) { std::memcpy(r.data() + a, &v, 4); }
void half(std::vector<uint8_t>& r, uint32_t a, uint16_t v) { std::memcpy(r.data() + (a ^ 2), &v, 2); }
void matrix(std::vector<uint8_t>& r, bool eye_from_z) {
    for (int row = 0; row < 4; row++) for (int col = 0; col < 4; col++) {
        const int k = row * 4 + col;
        int32_t x = (row == col ? 65536 : 0);
        if (eye_from_z && row == 3 && col == 3) x = 0;
        if (eye_from_z && row == 2 && col == 3) x = 65536;
        half(r, kMatrix + 2 * k, static_cast<uint16_t>(x >> 16));
        half(r, kMatrix + 32 + 2 * k, static_cast<uint16_t>(x));
    }
}
rt64_3ds::FrameRecord render(int z0, int z1, int z2, bool non, bool defer, bool eye_from_z = false) {
    std::vector<uint8_t> r(16u * 1024 * 1024, 0);
    matrix(r, eye_from_z);
    const int16_t xyz[3][3] = { { -1, -1, (int16_t)z0 }, { 1, -1, (int16_t)z1 }, { 0, 1, (int16_t)z2 } };
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) half(r, kVerts + i * 16 + j * 2, static_cast<uint16_t>(xyz[i][j]));
        word(r, kVerts + i * 16 + 12, 0xFFFFFFFFu);
    }
    uint32_t p = kList;
    auto cmd = [&](uint32_t a, uint32_t b) { word(r, p, a); word(r, p + 4, b); p += 8; };
    // Identity modelview; the projection is identity, or w = model z for the eye-plane test.
    if (eye_from_z) {
        cmd(0xDC38000E, kMatrix);  // force the combined matrix
        cmd(0xDB0C0000, 0x00010000);
    } else {
        cmd(0xDA380007, kMatrix);  // projection = identity
        cmd(0xDA380003, kMatrix);  // modelview = identity
    }
    cmd(0x01003006, kVerts);
    cmd(0x05000204, 0);
    cmd(0xE9000000, 0);
    cmd(0xDF000000, 0);
    rt64_3ds::Interpreter interp(r.data());
    interp.set_no_near_clip(non);
    if (defer) interp.set_defer_triangles(true, true);
    rt64_3ds::FrameRecord frame;
    const bool sync = interp.run(kList, frame);
    if (defer) interp.finish_triangles(frame);
    check("synthetic list reached full sync", sync);
    return frame;
}
bool good_depth(const rt64_3ds::FrameRecord& f) {
    for (size_t i = 0; i < f.verts.size(); i++) {
        const auto& v = f.verts[i];
        if (!(v.w > 0) || !(v.z >= 0) || !std::isfinite(v.x) || !std::isfinite(v.y) || !std::isfinite(v.z) || !std::isfinite(v.w)) return false;
    }
    return true;
}
float area(const rt64_3ds::FrameRecord& f) {
    float sum = 0;
    for (size_t i = 0; i + 2 < f.verts.size(); i += 3) {
        const auto& a = f.verts[i]; const auto& b = f.verts[i + 1]; const auto& c = f.verts[i + 2];
        const float ax = a.x/a.w, ay = a.y/a.w, bx = b.x/b.w, by = b.y/b.w, cx = c.x/c.w, cy = c.y/c.w;
        sum += std::fabs((bx - ax) * (cy - ay) - (by - ay) * (cx - ax)) * .5f;
    }
    return sum;
}
}
int main() {
    auto normal_near = render(-2, -2, -2, false, false);
    auto non_near = render(-2, -2, -2, true, false);
    check("ordinary near clipping rejects eye-side triangle", normal_near.verts.size() == 0);
    check("NoN retains eye-side triangle at near depth", non_near.verts.size() == 3 && good_depth(non_near) && non_near.verts[0].z / non_near.verts[0].w < 0.0002f);
    auto normal_cross = render(-2, -2, 0, false, false);
    auto non_cross = render(-2, -2, 0, true, false);
    auto deferred = render(-2, -2, 0, true, true);
    check("ordinary near clipping cuts a crossing triangle", normal_cross.verts.size() == 3 && good_depth(normal_cross));
    check("NoN splits a crossing triangle without losing area", non_cross.verts.size() == 9 && good_depth(non_cross) && std::fabs(area(non_cross) - 38400.0f) < 1.0f);
    bool same = deferred.verts.size() == non_cross.verts.size();
    for (size_t i = 0; same && i < deferred.verts.size(); i++)
        same = std::memcmp(&deferred.verts[i], &non_cross.verts[i], sizeof(rt64_3ds::Vtx3ds)) == 0;
    check("deferred NoN output matches immediate output", same);
    auto front = render(0, 0, 0, true, false);
    check("NoN leaves an ordinary in-front triangle unchanged", front.verts.size() == 3 && good_depth(front));
    auto behind = render(-1, -1, -1, true, false, true);
    check("NoN still rejects geometry behind the eye", behind.verts.size() == 0);
    auto eye_cross = render(1, 1, -1, true, false, true);
    check("NoN clips eye-crossing geometry to finite guarded vertices", eye_cross.verts.size() >= 3 && good_depth(eye_cross));
    return failures ? 1 : 0;
}
