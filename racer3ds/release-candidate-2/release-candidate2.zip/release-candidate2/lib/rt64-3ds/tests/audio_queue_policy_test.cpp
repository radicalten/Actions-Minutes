#include "audio_queue_policy.h"
#include <cstdio>

using recomp3ds::audio_backlog_exceeded;
int main() {
    bool ok = true;
    auto check = [&](const char* name, bool v) { std::printf("%s: %s\n", name, v ? "ok" : "FAIL"); ok &= v; };
    check("disabled queue guard leaves a long queue alone", !audio_backlog_exceeded(100000, 32000, 0));
    check("zero sample rate cannot trigger recovery", !audio_backlog_exceeded(100000, 0, 300));
    check("ordinary 100 ms queue is retained", !audio_backlog_exceeded(3200, 32000, 300));
    check("exactly 300 ms is retained", !audio_backlog_exceeded(9600, 32000, 300));
    check("queue exceeding 300 ms triggers recovery", audio_backlog_exceeded(9601, 32000, 300));
    check("threshold scales with actual sample rate", !audio_backlog_exceeded(14400, 48000, 300) &&
                                                      audio_backlog_exceeded(14401, 48000, 300));
    return ok ? 0 : 1;
}
