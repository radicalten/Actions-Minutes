#!/usr/bin/env python3
"""ROM-free regression tests for the one-command build's input handling."""

import hashlib
import importlib.util
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location("prepare_rom", ROOT / "tools/3ds/prepare_rom.py")
prepare_rom = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prepare_rom)


class RomPreparationTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.scratch = self.root / "scratch"
        self.scratch.mkdir()
        self.data = bytearray((i * 13 + 7) % 256 for i in range(256))
        self.data[:4] = bytes.fromhex("80371240")
        self.data[16:20] = (0x72F70398).to_bytes(4, "big")
        self.data = bytes(self.data)
        self.old_size = prepare_rom.EXPECTED_SIZE
        self.old_hash = prepare_rom.EXPECTED_SHA256
        prepare_rom.EXPECTED_SIZE = len(self.data)
        prepare_rom.EXPECTED_SHA256 = hashlib.sha256(self.data).hexdigest()

    def tearDown(self):
        prepare_rom.EXPECTED_SIZE = self.old_size
        prepare_rom.EXPECTED_SHA256 = self.old_hash
        self.temporary.cleanup()

    def raw(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def archive(self, name, entries):
        path = self.root / name
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for entry_name, data in entries:
                z.writestr(entry_name, data)
        return path

    def test_raw_is_validated_without_copy_or_modification(self):
        path = self.raw("my game.z64", self.data)
        self.assertEqual(prepare_rom.prepare(path, self.scratch), path.resolve())
        self.assertEqual(path.read_bytes(), self.data)
        self.assertEqual(list(self.scratch.iterdir()), [])

    def test_zip_ignores_macos_sidecar_and_extracts_to_fixed_name(self):
        path = self.archive("my game.zip", [("folder/game.z64", self.data),
                                            ("__MACOSX/._game.z64", b"metadata")])
        result = prepare_rom.prepare(path, self.scratch)
        self.assertEqual(result, self.scratch / "baserom.z64")
        self.assertEqual(result.read_bytes(), self.data)
        self.assertEqual(path.exists(), True)

    def test_wrong_size_magic_crc_and_digest_fail(self):
        cases = [self.data[:-1], b"BAD!" + self.data[4:],
                 self.data[:16] + b"NOPE" + self.data[20:], self.data[:-1] + b"X"]
        for index, data in enumerate(cases):
            with self.subTest(index=index):
                with self.assertRaises(ValueError):
                    prepare_rom.prepare(self.raw(f"bad{index}.z64", data), self.scratch)

    def test_wrong_zip_data_does_not_leave_a_partial_rom(self):
        bad = self.data[:-1] + b"X"
        with self.assertRaises(ValueError):
            prepare_rom.prepare(self.archive("wrong.zip", [("game.z64", bad)]), self.scratch)
        self.assertEqual(list(self.scratch.iterdir()), [])

    def test_zip_with_multiple_roms_is_rejected(self):
        path = self.archive("two.zip", [("a.z64", self.data), ("b.z64", self.data)])
        with self.assertRaisesRegex(ValueError, "exactly one"):
            prepare_rom.prepare(path, self.scratch)

    def test_zip_with_no_rom_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "exactly one"):
            prepare_rom.prepare(self.archive("empty.zip", [("readme.txt", b"no ROM")]), self.scratch)

    def test_traversal_zip_entry_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "unsafe"):
            prepare_rom.prepare(self.archive("escape.zip", [("../game.z64", self.data)]), self.scratch)
        self.assertEqual(list(self.scratch.iterdir()), [])

    def test_zip_symlink_is_rejected(self):
        path = self.root / "link.zip"
        info = zipfile.ZipInfo("game.z64")
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(path, "w") as z:
            z.writestr(info, self.data)
        with self.assertRaisesRegex(ValueError, "symbolic link"):
            prepare_rom.prepare(path, self.scratch)

    def test_existing_staged_file_is_never_overwritten_or_deleted(self):
        target = self.scratch / "baserom.z64"
        target.write_bytes(b"keep me")
        path = self.archive("good.zip", [("game.z64", self.data)])
        with self.assertRaises(FileExistsError):
            prepare_rom.prepare(path, self.scratch)
        self.assertEqual(target.read_bytes(), b"keep me")

    def test_rom_inside_replaced_directory_is_rejected_before_cleanup(self):
        path = self.raw("recomp-work/game.z64", self.data)
        with self.assertRaisesRegex(ValueError, "move the ROM"):
            prepare_rom.prepare(path, self.scratch, [self.root / "recomp-work"])
        self.assertEqual(path.read_bytes(), self.data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
