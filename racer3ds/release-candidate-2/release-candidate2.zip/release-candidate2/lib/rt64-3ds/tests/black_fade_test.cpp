// ROM-free F3DEX2/RDP rectangle tests: widen only the solid black fade.
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include "rt64_3ds_dl.h"

namespace {
constexpr uint32_t kList = 0x1000, kTexture = 0x5000;
int failures = 0;
void word(std::vector<uint8_t>& r, uint32_t a, uint32_t v) { std::memcpy(r.data() + a, &v, 4); }
void check(const char* name, bool ok) { std::printf("%s: %s\n", name, ok ? "ok" : "FAIL"); failures += !ok; }
bool near(float a, float b) { return std::fabs(a - b) < 0.01f; }
struct Bounds { bool sync; size_t draws; float x0, x1, y0, y1; };
Bounds draw(bool enabled, uint32_t color, bool white, bool combiner, int end_x, int end_y, int height = 480) {
    std::vector<uint8_t> mem(16u * 1024 * 1024, 0);
    std::memset(mem.data() + kTexture, 0xff, 32);
    if (!white) mem[kTexture + 7] = 0x7f;
    uint32_t p = kList;
    auto cmd = [&](uint32_t a, uint32_t b) { word(mem, p, a); word(mem, p + 4, b); p += 8; };
    cmd(0xED000000u, (320u * 4u << 12) | (uint32_t)height * 4u); // full scissor
    cmd(0xE200001Cu, 0x00504340u);
    cmd(0xFA000000u, color);                  // primitive color
    cmd(combiner ? 0xFC119623u : 0xFC119622u, 0xFF2FFFFFu);
    cmd(0xFD100000u, 0x80000000u | kTexture); // 16 white RGBA16 texels
    cmd(0xF5100000u, 0x07080200u);
    cmd(0xE6000000u, 0);
    cmd(0xF3000000u, 0x0700F200u);
    cmd(0xE7000000u, 0);
    cmd(0xF5100800u, 0x00080200u);
    cmd(0xF2000000u, 0x0003C000u);
    cmd(0xE4000000u | ((uint32_t)end_x * 4u << 12) | (uint32_t)end_y * 4u, 0);
    cmd(0xE1000000u, 0);
    cmd(0xF1000000u, 0x0033FFFEu);
    cmd(0xE9000000u, 0);
    cmd(0xDF000000u, 0);
    rt64_3ds::Interpreter interpreter(mem.data());
    interpreter.set_screen(rt64_3ds::ScreenGeometry::make_fit(320, height, 4.0f/3.0f));
    interpreter.set_scissor_edge_slack(8);
    interpreter.set_widen_black_fade(enabled);
    rt64_3ds::FrameRecord f;
    Bounds b{interpreter.run(kList, f), f.draws.size(), 1e9f, -1e9f, 1e9f, -1e9f};
    for (size_t i = 0; i < f.verts.size(); i++) {
        const auto& v = f.verts[i];
        b.x0 = std::fmin(b.x0, v.x); b.x1 = std::fmax(b.x1, v.x);
        b.y0 = std::fmin(b.y0, v.y); b.y1 = std::fmax(b.y1, v.y);
    }
    return b;
}
bool centered(const Bounds& b) { return b.sync && b.draws == 1 && near(b.x0, 0) && near(b.x1, 319); }
}
int main() {
    const Bounds normal = draw(false, 0x000000f8, true, true, 319, 479);
    const Bounds fade = draw(true, 0x000000f8, true, true, 319, 479);
    check("disabled fade keeps original 4:3 rectangle", centered(normal));
    check("identified black fade covers the entire wide screen", fade.sync && fade.draws == 1 &&
          near(fade.x0, -40) && near(fade.x1, 360) && near(fade.y0, 0) && near(fade.y1, 480));
    const Bounds progressive = draw(true, 0x000000f8, true, true, 319, 239, 240);
    check("progressive black fade also reaches the wide screen", progressive.sync && progressive.draws == 1 &&
          near(progressive.x0, -40) && near(progressive.x1, 360) && near(progressive.y1, 240));
    check("nonblack image is not widened", centered(draw(true, 0x100000f8, true, true, 319, 479)));
    check("nonwhite texture is not widened", centered(draw(true, 0x000000f8, false, true, 319, 479)));
    check("different combiner is not widened", centered(draw(true, 0x000000f8, true, false, 319, 479)));
    const Bounds short_rect = draw(true, 0x000000f8, true, true, 318, 479);
    check("interior rectangle is not widened", short_rect.sync && near(short_rect.x0, 0) && near(short_rect.x1, 318));
    const Bounds short_height = draw(true, 0x000000f8, true, true, 319, 478);
    check("partial-height rectangle is not widened", centered(short_height));
    return failures ? 1 : 0;
}
