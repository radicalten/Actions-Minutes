#!/usr/bin/env python3
"""Check Racer's actual static map, with no 3DS SDK or ROM required."""
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parents[3]
src = (root / "platform/3ds/main_3ds.cpp").read_text()
match = re.search(r"kRacerButtons\[\]\s*=\s*\{(.*?)\};", src, re.S)
assert match, "Racer button map missing"
entries = re.findall(r"\{\s*([^{}]+?),\s*recomp3ds::(N64_\w+)\s*\}", match.group(1))
button = {}
for keys, output in entries:
    for key in re.findall(r"KEY_\w+", keys):
        button.setdefault(key, set()).add(output)
expected = {
    "KEY_DUP": {"N64_CUP"}, "KEY_DDOWN": {"N64_CDOWN"},
    "KEY_DLEFT": {"N64_CLEFT"}, "KEY_DRIGHT": {"N64_CRIGHT"},
    "KEY_X": {"N64_CUP"}, "KEY_Y": {"N64_Z"},
    "KEY_A": {"N64_A"}, "KEY_B": {"N64_B"}, "KEY_L": {"N64_L"},
    "KEY_ZL": {"N64_Z"}, "KEY_R": {"N64_R"}, "KEY_ZR": {"N64_R"},
    "KEY_START": {"N64_START"},
}
ok = True
for key, value in expected.items():
    passed = button.get(key) == value
    print(f"{key} -> {','.join(sorted(value))}: {'ok' if passed else 'FAIL'}")
    ok &= passed
passed = not any(out in {"N64_DUP", "N64_DDOWN", "N64_DLEFT", "N64_DRIGHT"} for _, out in entries)
print("no N64 D-pad outputs: " + ("ok" if passed else "FAIL"))
ok &= passed
# Compare against the library's real default so only the physical D-pad differs.
default_src = (root / "lib/rt64-3ds/src/platform/input_hid.cpp").read_text()
default_body = re.search(r"kDefaultMap\[\]\s*=\s*\{(.*?)\};", default_src, re.S)
assert default_body, "library default map missing"
default = {}
for keys, output in re.findall(r"\{\s*([^{}]+?),\s*(N64_\w+)\s*\}", default_body.group(1)):
    for key in re.findall(r"KEY_\w+", keys):
        default.setdefault(key, set()).add(output)
dpad = {"KEY_DUP", "KEY_DDOWN", "KEY_DLEFT", "KEY_DRIGHT"}
passed = {k: v for k, v in button.items() if k not in dpad} == {k: v for k, v in default.items() if k not in dpad}
print("all non-D-pad buttons match the original scheme: " + ("ok" if passed else "FAIL"))
ok &= passed
passed = "desc.button_map = kRacerButtons;" in src and "desc.button_map_count = sizeof(kRacerButtons)" in src
print("Racer selects the custom map: " + ("ok" if passed else "FAIL"))
ok &= passed
sys.exit(0 if ok else 1)
