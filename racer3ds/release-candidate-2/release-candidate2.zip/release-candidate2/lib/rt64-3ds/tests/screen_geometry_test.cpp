// Host test for the placement of the game's frame on the 3DS's 400x240 screen
// (rt64_3ds_types.h). It includes the header the renderer itself builds with,
// so the numbers below are the ones the console uses, not a restatement.
//
//   g++ -std=c++20 -I../src/renderer -o /tmp/sgt screen_geometry_test.cpp && /tmp/sgt
//
// What it pins down:
//  * a square-pixel frame (320x240, 292x216) is placed as it always was: the
//    fit and the plain placement agree, so no game that was right before moves;
//  * a frame the N64 stretches on the way to the TV is fitted inside the
//    screen instead of spilling past its edges;
//  * nothing the game draws inside its own frame can land off the screen.
#include <cstdio>
#include <cmath>

#include "rt64_3ds_types.h"

using rt64_3ds::ScreenGeometry;

namespace {
int g_fail = 0;

void near_(const char* what, float got, float want) {
    const bool ok = std::fabs(got - want) < 0.001f;
    if (!ok) g_fail++;
    printf("%-58s %9.4f (want %9.4f) %s\n", what, got, want, ok ? "ok" : "FAIL");
}
}   // namespace

int main() {
    // 1. A 320x240 square-pixel frame displayed at 4:3: the fit is the old
    //    uniform placement, centred with 40 px of black either side.
    const ScreenGeometry old = ScreenGeometry::make(320, 240);
    const ScreenGeometry fit = ScreenGeometry::make_fit(320, 240, 4.0f / 3.0f);
    printf("== 320x240, square pixels: the fit must change nothing\n");
    near_("scale_x", fit.scale_x, old.scale);
    near_("scale_y", fit.scale, old.scale);
    near_("x0", fit.x0, old.x0);
    near_("wide_w", fit.wide_w, old.wide_w);
    near_("left edge of the frame lands at", fit.screen_x(0.0f), 40.0f);
    near_("right edge of the frame lands at", fit.screen_x(320.0f), 360.0f);
    near_("bottom edge of the frame lands at", fit.screen_y(240.0f), 240.0f);

    // 2. Banjo's 292x216 with no aspect given: exactly make(), as before.
    printf("== 292x216 with display_aspect 0: identical to the plain placement\n");
    const ScreenGeometry plain292 = ScreenGeometry::make(292, 216);
    const ScreenGeometry fit292 = ScreenGeometry::make_fit(292, 216, 0.0f);
    near_("scale_x", fit292.scale_x, plain292.scale);
    near_("scale_y", fit292.scale, plain292.scale);
    near_("x0", fit292.x0, plain292.x0);

    // 3. A 512x240 framebuffer showing 4:3 (each pixel 1.25 wide on the TV):
    //    the axes come apart so the picture is 320x240 of the screen, and the
    //    whole 512 columns of the game's frame are on it.
    printf("== 512x240 shown 4:3: the picture fits, the sides are not cut\n");
    const ScreenGeometry w512 = ScreenGeometry::make_fit(512, 240, 4.0f / 3.0f);
    near_("scale_x (0.625 = 320 px over 512)", w512.scale_x, 0.625f);
    near_("scale_y (rows are one to one)", w512.scale, 1.0f);
    near_("left edge of the frame lands at", w512.screen_x(0.0f), 40.0f);
    near_("right edge of the frame lands at", w512.screen_x(512.0f), 360.0f);
    near_("screen spans, in N64 units", w512.wide_w, 640.0f);
    // The same frame placed the old way, to show the fault this removes:
    const ScreenGeometry crop512 = ScreenGeometry::make(512, 240);
    near_("before: x=0 landed at (off the left of the screen)", crop512.screen_x(0.0f), -56.0f);
    near_("before: x=512 landed at (past the right edge)", crop512.screen_x(512.0f), 456.0f);

    // 4. A 640x480 frame (the sibling ports' title and menu mode): both axes
    //    halve, the frame still centred, nothing outside the screen.
    printf("== 640x480 shown 4:3: half size, still centred\n");
    const ScreenGeometry w640 = ScreenGeometry::make_fit(640, 480, 4.0f / 3.0f);
    near_("scale_x", w640.scale_x, 0.5f);
    near_("scale_y", w640.scale, 0.5f);
    near_("left edge of the frame lands at", w640.screen_x(0.0f), 40.0f);
    near_("right edge of the frame lands at", w640.screen_x(640.0f), 360.0f);
    near_("bottom edge of the frame lands at", w640.screen_y(480.0f), 240.0f);

    // 5. A picture wider than the screen's 5:3 is limited by the width
    //    instead of the height, and still never spills out of the screen.
    printf("== 2:1 picture: limited by the screen's width, not cut\n");
    const ScreenGeometry wide = ScreenGeometry::make_fit(640, 320, 2.0f);
    near_("scale_x", wide.scale_x, 400.0f / 640.0f);
    near_("left edge of the frame lands at", wide.screen_x(0.0f), 0.0f);
    near_("right edge of the frame lands at", wide.screen_x(640.0f), 400.0f);

    // 6. A genuinely 640-pixel *visible window* in a 240-row mode is fitted
    //    to 4:3. Do not confuse this case with Racer's 640-pixel VI row pitch:
    //    its H window and X scale can still scan out only 320 source pixels.
    //    vi_scanout_test.cpp checks that distinction and mode transitions.
    printf("== 640x240 active picture: 0.5 across, 1.0 down\n");
    const ScreenGeometry racer = ScreenGeometry::make_fit(640, 240, 4.0f / 3.0f);
    near_("scale_x", racer.scale_x, 0.5f);
    near_("scale", racer.scale, 1.0f);
    near_("left edge of the frame lands at", racer.screen_x(0.0f), 40.0f);
    near_("right edge of the frame lands at", racer.screen_x(640.0f), 360.0f);
    near_("bottom edge of the frame lands at", racer.screen_y(240.0f), 240.0f);
    const ScreenGeometry racer_old = ScreenGeometry::make(320, 240);   // before: fixed 320
    near_("before: x=0 landed at", racer_old.screen_x(0.0f), 40.0f);
    near_("before: x=640 landed at (280 columns past the right edge)",
          racer_old.screen_x(640.0f), 680.0f);

    printf("\n%s\n", g_fail == 0 ? "all checks passed" : "FAILURES ABOVE");
    return g_fail != 0;
}
