// ROM-free F3DEX2 gSPForceMatrix regression. The synthetic display list
// installs a combined MVP, draws a triangle, then loads a normal modelview
// and draws it again. Racer's race camera uses this command extensively.
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

#include "rt64_3ds_dl.h"

namespace {
constexpr uint32_t kList = 0x1000, kIdentity = 0x2000, kForced = 0x2100, kVertex = 0x3000;
int failures = 0;

// RDRAM is stored as little-endian 32-bit words, with N64 halfwords swapped.
void word(std::vector<uint8_t>& r, uint32_t a, uint32_t v) { std::memcpy(r.data() + a, &v, 4); }
void half(std::vector<uint8_t>& r, uint32_t a, uint16_t v) { std::memcpy(r.data() + (a ^ 2), &v, 2); }
void mtx(std::vector<uint8_t>& r, uint32_t a, bool translate) {
    for (int row = 0; row < 4; ++row) for (int col = 0; col < 4; ++col) {
        const int k = row * 4 + col;
        const int32_t fixed = (row == col ? 65536 : 0) + ((translate && row == 3 && col == 0) ? 32768 : 0);
        half(r, a + 2 * k, static_cast<uint16_t>(fixed >> 16));
        half(r, a + 32 + 2 * k, static_cast<uint16_t>(fixed));
    }
}
void vertices(std::vector<uint8_t>& r) {
    const int16_t p[3][3] = { { -1, -1, 0 }, { 0, -1, 0 }, { -1, 0, 0 } };
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) half(r, kVertex + i * 16 + j * 2, static_cast<uint16_t>(p[i][j]));
        word(r, kVertex + i * 16 + 12, 0xFFFFFFFFu);
    }
}
void make_list(std::vector<uint8_t>& r, bool forced) {
    uint32_t p = kList;
    auto cmd = [&](uint32_t a, uint32_t b) { word(r, p, a); word(r, p + 4, b); p += 8; };
    cmd(0xDA380007, kIdentity); // projection = identity (load)
    cmd(0xDA380003, kIdentity); // modelview = identity (load)
    if (forced) {
        cmd(0xDC38000E, kForced); // G_MV_MATRIX: precomputed combined MVP
        cmd(0xDB0C0000, 0x00010000); // G_MW_FORCEMTX, paired by gSPForceMatrix
    }
    cmd(0x01003006, kVertex);   // three vertices, slots 0..2
    cmd(0x05000204, 0);         // triangle 0,1,2
    cmd(0xDA380003, kIdentity); // ordinary matrix supersedes the forced MVP
    cmd(0x01003006, kVertex);
    cmd(0x05000204, 0);
    cmd(0xE9000000, 0);         // full sync
    cmd(0xDF000000, 0);         // end list
}
void check(const char* label, bool ok) {
    std::printf("%s: %s\n", label, ok ? "ok" : "FAIL");
    failures += !ok;
}
bool near(float a, float b) { return std::fabs(a - b) < 0.01f; }
void run_case(const char* label, bool deferred, bool interpolation, bool forced) {
    std::vector<uint8_t> r(16u * 1024 * 1024, 0);
    mtx(r, kIdentity, false);
    mtx(r, kForced, true);
    vertices(r);
    make_list(r, forced);
    rt64_3ds::Interpreter interpreter(r.data());
    if (deferred) interpreter.set_defer_triangles(true, true);
    if (interpolation) interpreter.set_interpolation(true);
    rt64_3ds::FrameRecord f;
    const bool sync = interpreter.run(kList, f);
    if (deferred) interpreter.finish_triangles(f);
    bool ok = sync && f.verts.size() == 6;
    if (ok) {
        // The first triangle's X is shifted by 80 screen pixels only when a
        // combined MVP was supplied; the next normal matrix restores it.
        const float first[3] = { forced ? 80.0f : 0.0f, forced ? 240.0f : 160.0f, forced ? 80.0f : 0.0f };
        const float second[3] = { 0.0f, 160.0f, 0.0f };
        for (int i = 0; i < 3; ++i) {
            ok = ok && near(f.verts[i].x / f.verts[i].w, first[i]);
            ok = ok && near(f.verts[i + 3].x / f.verts[i + 3].w, second[i]);
        }
    }
    check(label, ok);
    if (interpolation && forced) {
        rt64_3ds::FrameRecord between;
        check("forced MVP refuses an unsafe interpolated frame", !interpreter.build_inbetween(f, between));
        check("forced MVP refuses an unsafe replayed in-between", !interpreter.run_inbetween(kList, between));
    }
}

void scissor_case(const char* label, int slack, int left, int right, int expected_left, int expected_right) {
    std::vector<uint8_t> r(16u * 1024 * 1024, 0);
    mtx(r, kIdentity, false);
    vertices(r);
    uint32_t p = kList;
    auto cmd = [&](uint32_t a, uint32_t b) { word(r, p, a); word(r, p + 4, b); p += 8; };
    cmd(0xDA380007, kIdentity);
    cmd(0xDA380003, kIdentity);
    // N64 scissors use 10.2 fixed-point coordinates.
    cmd(0xED000000u | (static_cast<uint32_t>(left * 4) << 12),
        (static_cast<uint32_t>(right * 4) << 12) | (240u * 4u));
    cmd(0x01003006, kVertex);
    cmd(0x05000204, 0);
    cmd(0xE9000000, 0);
    cmd(0xDF000000, 0);
    rt64_3ds::Interpreter interpreter(r.data());
    interpreter.set_scissor_edge_slack(slack);
    rt64_3ds::FrameRecord f;
    const bool sync = interpreter.run(kList, f);
    check(label, sync && !f.draws.empty() && f.draws[0].scissor[0] == expected_left &&
          f.draws[0].scissor[2] == expected_right);
}
} // namespace

int main() {
    run_case("forced MVP replaces the product, then normal load restores it", false, false, true);
    run_case("forced MVP works with deferred vertices", true, false, true);
    run_case("forced MVP works with interpolation recording enabled", false, true, true);
    run_case("ordinary modelview/projection still work", false, false, false);
    scissor_case("Racer's near-edge scissor remains narrow without slack", 0, 8, 312, 8, 312);
    scissor_case("Racer's near-edge scissor opens for wider geometry", 8, 8, 312, 0, 320);
    scissor_case("an interior scissor is not opened", 8, 9, 311, 9, 311);
    return failures ? 1 : 0;
}
