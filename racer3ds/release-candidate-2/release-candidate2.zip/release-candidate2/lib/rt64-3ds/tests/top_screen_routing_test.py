#!/usr/bin/env python3
"""Source-level guard for Racer's 3DS display routing (no ROM needed).

This checks the direct C3D output assignments, not GPU behavior. Runtime
emulator/device tests should still inspect both screens.
"""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[3]
context = (root / "lib/rt64-3ds/src/renderer/rt64_3ds_context.cpp").read_text()
platform = (root / "lib/rt64-3ds/src/platform/recomp3ds_run.cpp").read_text()
game = (root / "platform/3ds/main_3ds.cpp").read_text()

outputs = re.findall(
    r"\bC3D_RenderTargetSetOutput\s*\(\s*[^,]+,\s*(GFX_[A-Z]+)\s*,\s*(GFX_[A-Z]+)",
    context,
)
checks = [
    ("game output assignments exist", bool(outputs)),
    ("all direct game output assignments target GFX_TOP", all(s == "GFX_TOP" for s, _ in outputs)),
    ("both top-screen eyes are covered", {eye for _, eye in outputs} >= {"GFX_LEFT", "GFX_RIGHT"}),
    ("platform status console is on GFX_BOTTOM", bool(re.search(r"\bconsoleInit\s*\(\s*GFX_BOTTOM\s*,", platform))),
    ("Racer does not opt in to a bottom-screen HUD", bool(re.search(r"desc\.render\.hud_on_bottom_supported\s*=\s*false\s*;", game))),
    ("Racer preserves the 4:3 image shape", bool(re.search(r"desc\.render\.display_aspect\s*=\s*4\.0f\s*/\s*3\.0f\s*;", game))),
    ("near-edge full-view scissors can reveal the sides", bool(re.search(r"desc\.render\.scissor_edge_slack\s*=\s*8\s*;", game))),
]
for name, ok in checks:
    print(f"{name}: {'ok' if ok else 'FAIL'}")
sys.exit(0 if all(ok for _, ok in checks) else 1)
