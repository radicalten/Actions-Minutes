// VI scanout geometry, shared by the 3DS renderer and ROM-free host tests.
#ifndef RT64_3DS_VI_H
#define RT64_3DS_VI_H

#include <cstdint>

namespace rt64_3ds {

// VI_WIDTH is the source-pixel stride between rows scanned in one field. In
// interlaced modes that can skip alternate logical RDP rows. It need not equal
// the number of pixels actually scanned out. H_START/H_END
// describe the active output interval; X_SCALE's low 12 bits are a 2.10
// fixed-point increment of source pixels per output pixel.
//
// Return the nearest integral number of source pixels in the active interval,
// or 0 when the VI is blank, unset or outside this renderer's supported
// geometry. Ignore X_SCALE's upper subpixel-offset field when measuring width.
// This measures the window; it does not emulate VI filtering or offsets.
inline int vi_scanout_width(uint32_t vi_width, uint32_t h_video, uint32_t x_scale) {
    const uint32_t stride = vi_width & 0xFFFu;
    const uint32_t start = (h_video >> 16) & 0x3FFu;
    const uint32_t end = h_video & 0x3FFu;
    const uint32_t step = x_scale & 0xFFFu;
    if (stride < 8u || end <= start || step == 0u) return 0;

    const uint32_t pixels = ((end - start) * step + 512u) / 1024u;
    return pixels >= 64u && pixels <= 800u ? static_cast<int>(pixels) : 0;
}

// Invalid/blank registers are common during osViBlack and mode transitions.
// Keep the last valid geometry (or the RenderDesc's initial geometry) until
// an active scanout arrives; a deliberate debug width always takes precedence.
inline int vi_geometry_width(uint32_t vi_width, uint32_t h_video, uint32_t x_scale,
                             int previous_width, int debug_width = 0) {
    if (debug_width > 0) return debug_width;
    const int active = vi_scanout_width(vi_width, h_video, x_scale);
    return active != 0 ? active : previous_width;
}

// Some interlaced modes interleave even/odd rows in the same RDP image. The
// VI traverses one field at a time, so its row stride is twice the image width
// even though each display list uses the full-height image. This is a targeted
// opt-in for games whose mode is known, not a general interlace/VI emulator.
// A zero interlaced_height preserves the ordinary fixed-height behaviour.
// Keep the last height during blank/uninitialized windows, and honor the
// debug override regardless of VI state.
inline int vi_geometry_height(uint32_t vi_width, uint32_t h_video, uint32_t x_scale,
                              uint32_t vi_status, int progressive_height,
                              int interlaced_height, int previous_height,
                              int debug_height = 0) {
    if (debug_height > 0) return debug_height;
    if (interlaced_height <= 0) return progressive_height;
    const int active = vi_scanout_width(vi_width, h_video, x_scale);
    if (active == 0) return previous_height > 0 ? previous_height : progressive_height;
    const uint32_t stride = vi_width & 0xFFFu;
    const bool serrated = (vi_status & 0x40u) != 0u;
    return serrated && stride == 2u * static_cast<uint32_t>(active)
        ? interlaced_height : progressive_height;
}

} // namespace rt64_3ds

#endif
