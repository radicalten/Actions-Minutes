// Small, platform-independent policy for an optional NDSP backlog guard.
#ifndef RECOMP3DS_AUDIO_QUEUE_POLICY_H
#define RECOMP3DS_AUDIO_QUEUE_POLICY_H

#include <cstddef>
#include <cstdint>

namespace recomp3ds {
// Disabled when max_ms is zero. A strict comparison leaves exactly the
// requested threshold alone; queued counts sample frames, not PCM bytes.
constexpr bool audio_backlog_exceeded(std::size_t queued_frames, uint32_t sample_rate, uint32_t max_ms) {
    return max_ms != 0 && sample_rate != 0 &&
           (uint64_t)queued_frames * 1000u > (uint64_t)sample_rate * max_ms;
}
}
#endif
