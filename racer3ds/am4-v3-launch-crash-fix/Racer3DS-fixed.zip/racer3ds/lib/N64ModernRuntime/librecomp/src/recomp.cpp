#include <cstdio>
#include <system_error>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <fstream>
#include <sstream>
#include <iostream>
#include <optional>
#include <mutex>
#include <array>
#include <cinttypes>
#include <cuchar>
#include <charconv>

#include "recomp.h"
#include "librecomp/overlays.hpp"
#include "librecomp/game.hpp"
#include "xxHash/xxh3.h"
#include "ultramodern/ultramodern.hpp"
#include "ultramodern/error_handling.hpp"
#include "librecomp/addresses.hpp"
#include "librecomp/mods.hpp"
#if !defined(RECOMP_NO_MODS) && !defined(RECOMP_STATIC_MODS)
#include "recompiler/live_recompiler.h"
#endif

#ifdef _WIN32
#    define WIN32_LEAN_AND_MEAN
#    include <Windows.h>
#elif defined(__3DS__)
#    include <cstdlib>
#else
#    include <sys/mman.h>
#endif

#if defined(_WIN32)
#define PATHFMT "%ls"
#else
#define PATHFMT "%s"
#endif

enum GameStatus {
    None,
    Running,
    Quit
};

// Mutexes
std::mutex game_roms_mutex;
std::mutex current_game_mutex;
#ifndef RECOMP_NO_MODS
std::mutex mod_context_mutex{};
#endif

// Global variables
std::filesystem::path config_path;
// Maps game_id to the game's entry.
std::unordered_map<std::u8string, recomp::GameEntry> game_roms {};
// The global mod context.
#ifndef RECOMP_NO_MODS
std::unique_ptr<recomp::mods::ModContext> mod_context = std::make_unique<recomp::mods::ModContext>();
#endif
// The project's version.
recomp::Version project_version;
// The current game's save type.
recomp::SaveType save_type = recomp::SaveType::None;

std::u8string recomp::GameEntry::stored_filename() const {
    return rom_filename_override.empty() ? (game_id + u8".z64") : rom_filename_override;
}

void recomp::register_config_path(std::filesystem::path path) {
    config_path = path;
}

std::filesystem::path recomp::get_config_path() {
    return config_path;
}

bool recomp::register_game(const recomp::GameEntry& entry) {
    if (entry.display_name.empty()) {
        ultramodern::error_handling::message_box("Game display name was not set.");
        ULTRAMODERN_QUICK_EXIT();
    }
    // TODO verify that there's no game with this ID already.
    {
        std::lock_guard<std::mutex> lock(game_roms_mutex);
        game_roms.insert({ entry.game_id, entry });
    }
#ifndef RECOMP_NO_MODS
    if (!entry.mod_game_id.empty()) {
        std::lock_guard<std::mutex> lock(mod_context_mutex);
        mod_context->register_game(entry.mod_game_id);
    }
#endif
    return true;
}

#ifndef RECOMP_NO_MODS
void recomp::mods::initialize_mods() {
#ifndef RECOMP_STATIC_MODS
    N64Recomp::live_recompiler_init();
#endif
    // Neither of these may throw: initialize_mods runs before the game's
    // threads exist, and a throw there ends in std::terminate just the same.
    std::error_code ec;
    std::filesystem::create_directories(config_path / mods_directory, ec);
#ifndef __3DS__
    // The 3DS keeps mod options in its own settings file and never writes
    // here: no empty folder for the player to wonder about.
    std::filesystem::create_directories(config_path / mod_config_directory, ec);
#endif
    mod_context->set_mods_config_path(config_path / "mods.json");
    mod_context->set_mod_config_directory(config_path / mod_config_directory);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::register_embedded_mod(const std::string &mod_id, std::span<const uint8_t> mod_bytes) {
    std::lock_guard<std::mutex> lock(mod_context_mutex);
    mod_context->register_embedded_mod(mod_id, mod_bytes);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::register_deprecated_mod(const std::string& mod_id, recomp::mods::DeprecationStatus deprecation_status, const Version& maximum_version) {
    std::lock_guard<std::mutex> lock(mod_context_mutex);
    mod_context->register_deprecated_mod(mod_id, deprecation_status, maximum_version);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::scan_mods() {
    std::vector<recomp::mods::ModOpenErrorDetails> mod_open_errors;
    {
        std::lock_guard mod_lock{ mod_context_mutex };
        mod_open_errors = mod_context->scan_mod_folder(config_path / mods_directory);
    }
    for (const auto& cur_error : mod_open_errors) {
        printf("Error opening mod " PATHFMT ": %s (%s)\n", cur_error.mod_path.c_str(), recomp::mods::error_to_string(cur_error.error).c_str(), cur_error.error_param.c_str());
    }

    mod_context->load_mods_config();
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::close_mods() {
    {
        std::lock_guard mod_lock{ mod_context_mutex };
        mod_context->close_mods();
    }
}
#endif

std::filesystem::path recomp::mods::get_mods_directory() {
    return config_path / mods_directory;
}

#ifndef RECOMP_NO_MODS
recomp::mods::ModContentTypeId recomp::mods::register_mod_content_type(const ModContentType& type) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->register_content_type(type);
}
#endif

#ifndef RECOMP_NO_MODS
bool recomp::mods::register_mod_container_type(const std::string& extension, const std::vector<ModContentTypeId>& content_types, bool requires_manifest) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->register_container_type(extension, content_types, requires_manifest);
}
#endif

#ifndef RECOMP_NO_MODS
std::string recomp::mods::get_mod_display_name(size_t mod_index) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->get_mod_display_name(mod_index);
}
#endif

#ifndef RECOMP_NO_MODS
std::filesystem::path recomp::mods::get_mod_path(size_t mod_index) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->get_mod_path(mod_index);
}
#endif

#ifndef RECOMP_NO_MODS
std::pair<std::string, std::string> recomp::mods::get_mod_import_info(size_t mod_index, size_t import_index) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->get_mod_import_info(mod_index, import_index);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::mods::DependencyStatus recomp::mods::is_dependency_met(size_t mod_index, const std::string& dependency_id) {
    std::lock_guard mod_lock{ mod_context_mutex };
    return mod_context->is_dependency_met(mod_index, dependency_id);
}
#endif

bool check_hash(const std::vector<uint8_t>& rom_data, uint64_t expected_hash) {
    uint64_t calculated_hash = XXH3_64bits(rom_data.data(), rom_data.size());
    return calculated_hash == expected_hash;
}

static std::vector<uint8_t> read_file(const std::filesystem::path& path) {
    std::vector<uint8_t> ret;

    std::ifstream file{ path, std::ios::binary};

    if (file.good()) {
        file.seekg(0, std::ios::end);
        ret.resize(file.tellg());
        file.seekg(0, std::ios::beg);

        file.read(reinterpret_cast<char*>(ret.data()), ret.size());
    }

    return ret;
}

bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    std::ofstream out_file{ path, std::ios::binary };

    if (!out_file.good()) {
        return false;
    }

    out_file.write(reinterpret_cast<const char*>(data.data()), data.size());

    return true;
}

// A file's hash, read in pieces: the ROM need not fit in memory whole (a ROM
// kept on storage never does), and the check leaves nothing allocated.
static bool check_file_hash(const std::filesystem::path& path, uint64_t expected_hash) {
    std::ifstream file{ path, std::ios::binary };
    if (!file.good()) {
        return false;
    }
    XXH3_state_t* state = XXH3_createState();
    XXH3_64bits_reset(state);
    std::vector<char> buf(1 << 16);
    size_t total = 0;
    while (file) {
        file.read(buf.data(), buf.size());
        const std::streamsize got = file.gcount();
        if (got > 0) {
            XXH3_64bits_update(state, buf.data(), (size_t)got);
            total += (size_t)got;
        }
    }
    const uint64_t hash = XXH3_64bits_digest(state);
    XXH3_freeState(state);
    return total != 0 && hash == expected_hash;
}

bool check_stored_rom(const recomp::GameEntry& game_entry) {
    if (!check_file_hash(config_path / game_entry.stored_filename(), game_entry.rom_hash)) {
        // Incorrect hash, remove the stored ROM file if it exists. The
        // non-throwing form: a remove that fails (a read-only card, a file
        // another thread holds open) is logged, not fatal.
        std::error_code remove_ec;
        std::filesystem::remove(config_path / game_entry.stored_filename(), remove_ec);
        if (remove_ec) {
            fprintf(stderr, "[rom] could not remove the stored ROM: %s\n", remove_ec.message().c_str());
        }
        return false;
    }

    return true;
}

static std::unordered_set<std::u8string> valid_game_roms;

bool recomp::is_rom_valid(const std::u8string& game_id) {
    return valid_game_roms.contains(game_id);
}

void recomp::check_all_stored_roms() {
    for (const auto& cur_rom_entry: game_roms) {
        if (check_stored_rom(cur_rom_entry.second)) {
            valid_game_roms.insert(cur_rom_entry.first);
        }
    }
}

bool recomp::load_stored_rom(const std::u8string& game_id) {
    auto find_it = game_roms.find(game_id);

    if (find_it == game_roms.end()) {
        return false;
    }

    if (recomp::get_rom_stream() != nullptr) {
        // Kept on storage: check_all_stored_roms hashed it at start, and
        // hashing it again would read the whole file once more.
        return valid_game_roms.contains(game_id) && recomp::open_rom_stream(config_path / find_it->second.stored_filename());
    }
    
    std::vector<uint8_t> stored_rom_data = read_file(config_path / find_it->second.stored_filename());

    if (!check_hash(stored_rom_data, find_it->second.rom_hash)) {
        // The ROM no longer has the right hash, delete it.
        std::error_code remove_ec;
        std::filesystem::remove(config_path / find_it->second.stored_filename(), remove_ec);
        if (remove_ec) {
            fprintf(stderr, "[rom] could not remove the stored ROM: %s\n", remove_ec.message().c_str());
        }
        return false;
    }

    recomp::set_rom_contents(std::move(stored_rom_data));
    return true;
}

const recomp::Version& recomp::get_project_version() {
    return project_version;
}

bool recomp::Version::from_string(const std::string& str, Version& out) {
    std::array<size_t, 2> period_indices;
    size_t cur_pos = 0;
    uint16_t major;
    uint16_t minor;
    uint16_t patch;
    std::string suffix;

    // Find the 2 required periods.
    cur_pos = str.find('.', cur_pos);
    period_indices[0] = cur_pos;
    cur_pos = str.find('.', cur_pos + 1);
    period_indices[1] = cur_pos;

    // Check that both were found.
    if (period_indices[0] == std::string::npos || period_indices[1] == std::string::npos) {
        return false;
    }

    // Parse the 3 numbers formed by splitting the string via the periods.
    std::array<std::from_chars_result, 3> parse_results; 
    std::array<size_t, 3> parse_starts { 0, period_indices[0] + 1, period_indices[1] + 1 };
    std::array<size_t, 3> parse_ends { period_indices[0], period_indices[1], str.size() };
    parse_results[0] = std::from_chars(str.data() + parse_starts[0], str.data() + parse_ends[0], major);
    parse_results[1] = std::from_chars(str.data() + parse_starts[1], str.data() + parse_ends[1], minor);
    parse_results[2] = std::from_chars(str.data() + parse_starts[2], str.data() + parse_ends[2], patch);

    // Check that the first two parsed correctly.
    auto did_parse = [&](size_t i) {
        return parse_results[i].ec == std::errc{} && parse_results[i].ptr == str.data() + parse_ends[i];
    };
    
    if (!did_parse(0) || !did_parse(1)) {
        return false;
    }

    // Check that the third had a successful parse, but not necessarily read all the characters.
    if (parse_results[2].ec != std::errc{}) {
        return false;
    }

    // Allow a plus or minus directly after the third number.
    if (parse_results[2].ptr != str.data() + parse_ends[2]) {
        if (*parse_results[2].ptr == '+' || *parse_results[2].ptr == '-') {
            suffix = str.substr(std::distance(str.data(), parse_results[2].ptr));
        }
        // Failed to parse, as nothing is allowed directly after the last number besides a plus or minus.
        else {
            return false;
        }
    }

    out.major = major;
    out.minor = minor;
    out.patch = patch;
    out.suffix = std::move(suffix);
    return true;
}

const std::array<uint8_t, 4> first_rom_bytes { 0x80, 0x37, 0x12, 0x40 };

enum class ByteswapType {
    NotByteswapped,
    Byteswapped4,
    Byteswapped2,
    Invalid
};

ByteswapType check_rom_start(const std::vector<uint8_t>& rom_data) {
    if (rom_data.size() < 4) {
        return ByteswapType::Invalid;
    }

    auto check_match = [&](uint8_t index0, uint8_t index1, uint8_t index2, uint8_t index3) {
        return
            rom_data[0] == first_rom_bytes[index0] &&
            rom_data[1] == first_rom_bytes[index1] &&
            rom_data[2] == first_rom_bytes[index2] &&
            rom_data[3] == first_rom_bytes[index3];
    };

    // Check if the ROM is already in the correct byte order.
    if (check_match(0,1,2,3)) {
        return ByteswapType::NotByteswapped;
    }

    // Check if the ROM has been byteswapped in groups of 4 bytes.
    if (check_match(3,2,1,0)) {
        return ByteswapType::Byteswapped4;
    }

    // Check if the ROM has been byteswapped in groups of 2 bytes.
    if (check_match(1,0,3,2)) {
        return ByteswapType::Byteswapped2;
    }

    // No match found.
    return ByteswapType::Invalid;
}

void byteswap_data(std::vector<uint8_t>& rom_data, size_t index_xor) {
    for (size_t rom_pos = 0; rom_pos < rom_data.size(); rom_pos += 4) {
        uint8_t temp0 = rom_data[rom_pos + 0];
        uint8_t temp1 = rom_data[rom_pos + 1];
        uint8_t temp2 = rom_data[rom_pos + 2];
        uint8_t temp3 = rom_data[rom_pos + 3];

        rom_data[rom_pos + (0 ^ index_xor)] = temp0;
        rom_data[rom_pos + (1 ^ index_xor)] = temp1;
        rom_data[rom_pos + (2 ^ index_xor)] = temp2;
        rom_data[rom_pos + (3 ^ index_xor)] = temp3;
    }
}

recomp::RomValidationError recomp::select_rom(const std::filesystem::path& rom_path, const std::u8string& game_id) {
    auto find_it = game_roms.find(game_id);

    if (find_it == game_roms.end()) {
        return recomp::RomValidationError::OtherError;
    }

    const recomp::GameEntry& game_entry = find_it->second;

    std::vector<uint8_t> rom_data = read_file(rom_path);

    if (rom_data.empty()) {
        return recomp::RomValidationError::FailedToOpen;
    }

    // Pad the rom to the nearest multiple of 4 bytes.
    rom_data.resize((rom_data.size() + 3) & ~3);

    ByteswapType byteswap_type = check_rom_start(rom_data);

    switch (byteswap_type) {
        case ByteswapType::Invalid:
            return recomp::RomValidationError::NotARom;
        case ByteswapType::Byteswapped2:
            byteswap_data(rom_data, 1);
            break;
        case ByteswapType::Byteswapped4:
            byteswap_data(rom_data, 3);
            break;
        case ByteswapType::NotByteswapped:
            break;
    }

    if (!check_hash(rom_data, game_entry.rom_hash)) {
        const std::string_view name{ reinterpret_cast<const char*>(rom_data.data()) + 0x20, game_entry.internal_name.size()};
        if (name == game_entry.internal_name) {
            return recomp::RomValidationError::IncorrectVersion;
        }
        else {
            if (game_entry.is_enabled && std::string_view{ reinterpret_cast<const char*>(rom_data.data()) + 0x20, 19 } == game_entry.internal_name) {
                return recomp::RomValidationError::NotYet;
            }
            else {
                return recomp::RomValidationError::IncorrectRom;
            }
        }
    }

    write_file(config_path / game_entry.stored_filename(), rom_data);
    
    return recomp::RomValidationError::Good;
}

extern "C" void osGetMemSize_recomp(uint8_t * rdram, recomp_context * ctx) {
    ctx->r2 = 8 * 1024 * 1024;
}

enum class StatusReg {
    FR = 0x04000000,
    CU1 = 0x20000000, // COP1 (FPU) usable bit - always enabled in recompiled code
};

extern "C" void cop0_status_write(recomp_context* ctx, gpr value) {
    uint32_t old_sr = ctx->status_reg;
    uint32_t new_sr = (uint32_t)value;
    uint32_t changed = old_sr ^ new_sr;

    // Check if the FR bit changed
    if (changed & (uint32_t)StatusReg::FR) {
        // Check if the FR bit was set
        if (new_sr & (uint32_t)StatusReg::FR) {
            // FR = 1, odd single floats point to their own registers
            ctx->f_odd = &ctx->f1.u32l;
            ctx->mips3_float_mode = true;
        }
        // Otherwise, it was cleared
        else {
            // FR = 0, odd single floats point to the upper half of the previous register
            ctx->f_odd = &ctx->f0.u32h;
            ctx->mips3_float_mode = false;
        }

        // Remove the FR bit from the changed bits as it's been handled
        changed &= ~(uint32_t)StatusReg::FR;
    }

    // CU1 (COP1/FPU usable) - always available in recompiled code, just track the bit
    if (changed & (uint32_t)StatusReg::CU1) {
        changed &= ~(uint32_t)StatusReg::CU1;
    }

    // If any other bits were changed, assert false as they're not handled currently
    if (changed) {
        printf("Unhandled status register bits changed: 0x%08X\n", changed);
        assert(false);
        exit(EXIT_FAILURE);
    }
    
    // Update the status register in the context
    ctx->status_reg = new_sr;
}

extern "C" gpr cop0_status_read(recomp_context* ctx) {
    return (gpr)(int32_t)ctx->status_reg;
}

extern "C" void switch_error(const char* func, uint32_t vram, uint32_t jtbl) {
    printf("Switch-case out of bounds in %s at 0x%08X for jump table at 0x%08X\n", func, vram, jtbl);
    assert(false);
    exit(EXIT_FAILURE);
}

extern "C" void do_break(uint32_t vram) {
    printf("Encountered break at original vram 0x%08X\n", vram);
    assert(false);
    exit(EXIT_FAILURE);
}

std::string current_game_mode_id;
std::optional<std::u8string> current_game = std::nullopt;
std::atomic<GameStatus> game_status = GameStatus::None;

void run_thread_function(uint8_t* rdram, uint64_t addr, uint64_t sp, uint64_t arg) {
    auto find_it = game_roms.find(current_game.value());
    const recomp::GameEntry& game_entry = find_it->second;
    
    recomp_context ctx{};
    ctx.r29 = sp;
    ctx.r4 = arg;
    ctx.mips3_float_mode = 0;
    ctx.f_odd = &ctx.f0.u32h;

    if (game_entry.thread_create_callback != nullptr) {
        game_entry.thread_create_callback(rdram, &ctx);
    }

    recomp_func_t* func = get_function(addr);
    func(rdram, &ctx);
}

void init(uint8_t* rdram, recomp_context* ctx, gpr entrypoint) {
    // Initialize the overlays
    recomp::overlays::init_overlays();

    // Load overlays in the first 1MB
    load_overlays(0x1000, (int32_t)entrypoint, 1024 * 1024);

    // Initial 1MB DMA (rom address 0x1000 = physical address 0x10001000)
    recomp::do_rom_read(rdram, entrypoint, 0x10001000, 0x100000);

    // Read in any extra data from patches
    recomp::overlays::read_patch_data(rdram, (gpr)recomp::patch_rdram_start);

    // Set up context floats
    ctx->f_odd = &ctx->f0.u32h;
    ctx->mips3_float_mode = false;

    // Initialize variables normally set by IPL3
    constexpr int32_t osTvType = 0x80000300;
    //constexpr int32_t osRomType = 0x80000304;
    constexpr int32_t osRomBase = 0x80000308;
    constexpr int32_t osResetType = 0x8000030c;
    //constexpr int32_t osCicId = 0x80000310;
    //constexpr int32_t osVersion = 0x80000314;
    constexpr int32_t osMemSize = 0x80000318;
    //constexpr int32_t osAppNMIBuffer = 0x8000031c;
    MEM_W(osTvType, 0) = 1; // NTSC
    MEM_W(osRomBase, 0) = 0xB0000000u; // standard rom base
    MEM_W(osResetType, 0) = 0; // cold reset
    MEM_W(osMemSize, 0) = 8 * 1024 * 1024; // 8MB
}

std::u8string recomp::current_game_id() {
    std::lock_guard<std::mutex> lock(current_game_mutex);
    return current_game.value();
};

std::string recomp::current_mod_game_id() {
    auto find_it = game_roms.find(current_game_id());
    const recomp::GameEntry& game_entry = find_it->second;

    return game_entry.mod_game_id;
}

void recomp::start_game(const std::u8string& game_id, const std::string& game_mode_id) {
    std::lock_guard<std::mutex> lock(current_game_mutex);
    current_game_mode_id = game_mode_id;
    current_game = game_id;
    game_status.store(GameStatus::Running);
    game_status.notify_all();
    mods::set_latest_game_mode_id(game_mode_id);
}

bool ultramodern::is_game_started() {
    return game_status.load() != GameStatus::None;
}

std::atomic_bool exited = false;
moodycamel::LightweightSemaphore graphics_shutdown_ready;

void ultramodern::quit() {
    exited.store(true);
    GameStatus desired = GameStatus::None;
    game_status.compare_exchange_strong(desired, GameStatus::Quit);
    game_status.notify_all();
    std::lock_guard<std::mutex> lock(current_game_mutex);
    current_game.reset();
}

#ifndef RECOMP_NO_MODS
void recomp::mods::enable_mod(const std::string& mod_id, bool enabled) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->enable_mod(mod_id, enabled, true);
}
#endif

#ifndef RECOMP_NO_MODS
bool recomp::mods::is_mod_enabled(const std::string& mod_id) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->is_mod_enabled(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
bool recomp::mods::is_mod_auto_enabled(const std::string& mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->is_mod_auto_enabled(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
bool recomp::mods::is_mod_deprecated(const std::string& mod_id, const recomp::Version& mod_version) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->is_mod_deprecated(mod_id, mod_version);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::mods::DeprecationStatus recomp::mods::get_mod_deprecation_status(const std::string& mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_deprecation_status(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::Version recomp::mods::get_mod_deprecation_version(const std::string& mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_deprecation_version(mod_id);
}
#endif

std::string recomp::mods::deprecation_status_to_message(DeprecationStatus deprecation_status) {
    switch (deprecation_status) {
    case DeprecationStatus::Integrated:
        return "This mod has already been integrated into the game";
    case DeprecationStatus::BrokenVersion:
        return "This version of the mod is known to cause issues. Please update it";
    case DeprecationStatus::BrokenPermanent:
        return "This mod is known to cause issues. Please uninstall it";
    default:
        return "Reason is unknown";
    }
}

#ifndef RECOMP_NO_MODS
const recomp::config::ConfigSchema &recomp::mods::get_mod_config_schema(const std::string &mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_config_schema(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::config::Config *recomp::mods::get_mod_config(const std::string &mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_config(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
const std::vector<char> &recomp::mods::get_mod_thumbnail(const std::string &mod_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_thumbnail(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::set_mod_config_value(size_t mod_index, const std::string &option_id, const recomp::config::ConfigValueVariant &value) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->set_mod_config_value(mod_index, option_id, value);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::set_mod_config_value(const std::string &mod_id, const std::string &option_id, const recomp::config::ConfigValueVariant &value) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->set_mod_config_value(mod_id, option_id, value);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::config::ConfigValueVariant recomp::mods::get_mod_config_value(size_t mod_index, const std::string &option_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_config_value(mod_index, option_id);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::config::ConfigValueVariant recomp::mods::get_mod_config_value(const std::string &mod_id, const std::string &option_id) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_mod_config_value(mod_id, option_id);
}
#endif

#ifndef RECOMP_NO_MODS
std::string recomp::mods::get_latest_game_mode_id() {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->get_latest_game_mode_id();
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::set_latest_game_mode_id(const std::string& game_mode_id) {
    std::lock_guard lock{ mod_context_mutex };
    mod_context->set_latest_game_mode_id(game_mode_id);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::set_session_excluded_mods(const std::unordered_set<std::string>& mod_ids) {
    std::lock_guard lock{ mod_context_mutex };
    mod_context->set_session_excluded_mods(mod_ids);
}
#endif

#ifndef RECOMP_NO_MODS
std::string recomp::mods::get_mod_id_from_filename(const std::filesystem::path& mod_filename) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_id_from_filename(mod_filename);
}
#endif

#ifndef RECOMP_NO_MODS
std::filesystem::path recomp::mods::get_mod_filename(const std::string& mod_id) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_filename(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
size_t recomp::mods::get_mod_order_index(const std::string& mod_id) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_order_index(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
size_t recomp::mods::get_mod_order_index(size_t mod_index) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_order_index(mod_index);
}
#endif

#ifndef RECOMP_NO_MODS
std::optional<recomp::mods::ModDetails> recomp::mods::get_details_for_mod(const std::string& mod_id) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_details_for_mod(mod_id);
}
#endif

#ifndef RECOMP_NO_MODS
std::vector<recomp::mods::ModDetails> recomp::mods::get_all_mod_details(const std::string& mod_game_id) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_all_mod_details(mod_game_id);
}
#endif

#ifndef RECOMP_NO_MODS
size_t recomp::mods::game_mode_count(const std::string& mod_game_id, bool include_disabled) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->game_mode_count(mod_game_id, include_disabled);
}
#endif

#ifndef RECOMP_NO_MODS
recomp::Version recomp::mods::get_mod_version(size_t mod_index) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_version(mod_index);
}
#endif

#ifndef RECOMP_NO_MODS
std::string recomp::mods::get_mod_id(size_t mod_index) {
    std::lock_guard lock { mod_context_mutex };
    return mod_context->get_mod_id(mod_index);
}
#endif

#ifndef RECOMP_NO_MODS
void recomp::mods::set_mod_index(const std::string &mod_game_id, const std::string &mod_id, size_t index) {
    std::lock_guard lock{ mod_context_mutex };
    return mod_context->set_mod_index(mod_game_id, mod_id, index);
}
#endif

bool wait_for_game_started(uint8_t* rdram, recomp_context* context) {
    game_status.wait(GameStatus::None);

    switch (game_status.load()) {
        // TODO refactor this to allow a project to specify what entrypoint function to run for a give game.
        case GameStatus::Running:
            {
                if (!recomp::load_stored_rom(current_game.value())) {
                    ultramodern::error_handling::message_box("Error opening stored ROM! Please restart this program.");
                }

                auto find_it = game_roms.find(current_game.value());
                const recomp::GameEntry& game_entry = find_it->second;

                init(rdram, context, game_entry.entrypoint_address);
                if (game_entry.on_init_callback) {
                    game_entry.on_init_callback(rdram, context);
                }

                uint32_t mod_ram_used = 0;
#ifndef RECOMP_NO_MODS
                if (!game_entry.mod_game_id.empty()) {
                    std::vector<recomp::mods::ModLoadErrorDetails> mod_load_errors;
                    {
                        std::lock_guard lock { mod_context_mutex };
                        mod_load_errors = mod_context->load_mods(game_entry, current_game_mode_id, rdram, recomp::mod_rdram_start, mod_ram_used);
                    }

                    if (!mod_load_errors.empty()) {
                        std::ostringstream mod_error_stream;
                        mod_error_stream << "Error loading mods:\n\n";
                        for (const auto& cur_error : mod_load_errors) {
                            auto mod_details = recomp::mods::get_details_for_mod(cur_error.mod_id);
                            if (mod_details) {
                                mod_error_stream << mod_details->display_name;
                            }
                            else {
                                mod_error_stream << cur_error.mod_id.c_str();
                            }
                            mod_error_stream << ": " << recomp::mods::error_to_string(cur_error.error);
                            if (!cur_error.error_param.empty()) {
                                mod_error_stream << " (" << cur_error.error_param.c_str() << ")";
                            }
                            mod_error_stream << "\n";                                
                        }
                        ultramodern::error_handling::message_box(mod_error_stream.str().c_str());
                        game_status.store(GameStatus::None);
                        return false;
                    }
                }

#endif
                // On the 3DS the mods' sections start where the heap would
                // (addresses.hpp), not in a region past 16 MB it cannot afford.
                recomp::init_heap(rdram, recomp::mod_rdram_start + mod_ram_used);

                save_type = game_entry.save_type;
                ultramodern::init_saving(rdram);

                try {
                    game_entry.entrypoint(rdram, context);
                } catch (ultramodern::thread_terminated& terminated) {

                }
            }
            return true;

        case GameStatus::Quit:
            return true;

        case GameStatus::None:
            return true;
    }
}

recomp::SaveType recomp::get_save_type() {
    return save_type;
}

bool recomp::eeprom_allowed() {
    return
        save_type == SaveType::Eep4k || 
        save_type == SaveType::Eep16k ||
        save_type == SaveType::AllowAll;
}

bool recomp::sram_allowed() {
    return
        save_type == SaveType::Sram || 
        save_type == SaveType::AllowAll;
}

bool recomp::flashram_allowed() {
    return
        save_type == SaveType::Flashram || 
        save_type == SaveType::AllowAll;
}

void print_cli_game_options() {
    for (const auto &it : game_roms) {
        bool rom_valid = recomp::is_rom_valid(it.second.game_id);
        fprintf(stderr, "\"%s\" (%s)%s\n", it.second.mod_game_id.c_str(), it.second.display_name.c_str(), rom_valid ? "" : " (No ROM)");
    }
}

void print_cli_game_mode_options(const std::vector<recomp::mods::ModDetails> &mods) {
    for (const auto &mod : mods) {
        if (mod.custom_gamemode) {
            bool mod_enabled = recomp::mods::is_mod_enabled(mod.mod_id) || recomp::mods::is_mod_auto_enabled(mod.mod_id);
            fprintf(stderr, "\"%s\" (%s)%s\n", mod.mod_id.c_str(), mod.display_name.c_str(), mod_enabled ? "" : " (Disabled)");
        }
    }
}

void parse_cli(int argc, char **argv) {
    std::string cli_game_id;
    std::string cli_game_mode_id;
    bool game_mode_missing_argument = false;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--game") == 0) {
            if (i + 1 < argc) {
                cli_game_id = std::string(argv[++i]);
            }
            else {
                fprintf(stderr, "No argument was specified for the game. Possible options are:\n");
                print_cli_game_options();
            }
        }
        else if (strcmp(argv[i], "--game-mode") == 0) {
            if (i + 1 < argc) {
                cli_game_mode_id = std::string(argv[++i]);
            }
            else {
                game_mode_missing_argument = true;
            }
        }
    }

    if (!cli_game_id.empty()) {
        // We use the mod game ID instead to do the lookup since it's much easier for the user to remember.
        std::u8string game_id;
        for (const auto &it : game_roms) {
            if (it.second.mod_game_id == cli_game_id) {
                if (recomp::is_rom_valid(it.second.game_id)) {
                    game_id = it.second.game_id;
                }
                else {
                    fprintf(stderr, "Game \"%s\" does not have a valid ROM. Please select a ROM on the launcher first.\n", cli_game_id.c_str());
                }

                break;
            }
        }

        if (!game_id.empty()) {
            bool game_mode_error = false;
            std::string game_mode_id;
            if (!cli_game_mode_id.empty() || game_mode_missing_argument) {
                std::vector<recomp::mods::ModDetails> mods = recomp::mods::get_all_mod_details(cli_game_id);
                if (!cli_game_mode_id.empty()) {
                    for (const auto &mod : mods) {
                        if ((mod.mod_id == cli_game_mode_id) && mod.custom_gamemode) {
                            if (recomp::mods::is_mod_enabled(mod.mod_id) || recomp::mods::is_mod_auto_enabled(mod.mod_id)) {
                                game_mode_id = mod.mod_id;
                            }
                            else {
                                fprintf(stderr, "Game mode \"%s\" is disabled. Please enable it on the mods menu first.\n", cli_game_mode_id.c_str());
                            }

                            break;
                        }
                    }

                    if (game_mode_id.empty()) {
                        fprintf(stderr, "Game mode \"%s\" is not available. Possible options are:\n", cli_game_mode_id.c_str());
                        print_cli_game_mode_options(mods);
                        game_mode_error = true;
                    }
                }
                else if (game_mode_missing_argument) {
                    fprintf(stderr, "No argument was specified for the game mode. Possible options are:\n");
                    print_cli_game_mode_options(mods);
                    game_mode_error = true;
                }
            }

            if (!game_mode_error) {
                recomp::start_game(game_id, game_mode_id);
            }
        }
        else {
            fprintf(stderr, "Game \"%s\" is not available. Possible options are:\n", cli_game_id.c_str());
            print_cli_game_options();
        }
    }
    else if (game_mode_missing_argument) {
        fprintf(stderr, "No argument was specified for the game mode. The game must be specified first to show the options.\n");
    }
}

// The 3DS RDRAM bounds guard, used by RECOMP_RDRAM_OFFSET (N64Recomp's
// recomp.h). An offset outside the game's RDRAM is an access to something that
// is not RAM: a kseg1 alias, a hardware register, or a pointer the game built
// wrong. Fold it into the scratch tail so it cannot corrupt the host heap, and
// say so: the first few are logged with the address of the recompiled function
// that made the access, which is the part that is impossible to find otherwise.
#if defined(RECOMP_RDRAM_GUARD)
#  define RECOMP_RDRAM_GUARD_REPORTS 32     // distinct addresses named
#  define RECOMP_RDRAM_GUARD_ECHO 0x4000    // and a running total this often
extern "C" uint32_t recomp_rdram_guard(uint32_t addr, uint32_t off) {
    static uint32_t reported = 0;
    static uint32_t total = 0;
    static uint32_t known[RECOMP_RDRAM_GUARD_REPORTS];
    const uint32_t folded = (uint32_t)recomp::mem_size + (off & (RECOMP_RDRAM_SCRATCH_SIZE - 1U));
    const uint32_t n = total++;
    if (n % RECOMP_RDRAM_GUARD_ECHO == RECOMP_RDRAM_GUARD_ECHO - 1) {
        fprintf(stderr, "rdram guard: %u access(es) outside RDRAM so far, %u kind(s) named\n",
                (unsigned)(n + 1), (unsigned)reported);
    }
    if (reported < RECOMP_RDRAM_GUARD_REPORTS) {
        uint32_t i = 0;
        while (i < reported && known[i] != addr) i++;
        if (i == reported) {
            known[reported++] = addr;
            // The caller's address is a host pc inside the recompiled game
            // code: addr2line against the ELF names the game's own function.
            fprintf(stderr, "rdram guard: access %u to 0x%08X (offset 0x%X, folded to 0x%X) from %08X\n",
                    (unsigned)reported, (unsigned)addr, (unsigned)off, (unsigned)folded,
                    (unsigned)(uint32_t)(uintptr_t)__builtin_return_address(0));
            fflush(stderr);
        }
    }
    return folded;
}
#endif


void recomp::start(const recomp::Configuration& cfg) {
    project_version = cfg.project_version;

    recomp::check_all_stored_roms();

    recomp::rsp::set_callbacks(cfg.rsp_callbacks);

    static const ultramodern::rsp::callbacks_t ultramodern_rsp_callbacks {
        .init = recomp::rsp::constants_init,
        .run_task = recomp::rsp::run_task,
    };

    ultramodern::set_callbacks(ultramodern_rsp_callbacks, cfg.renderer_callbacks, cfg.audio_callbacks, cfg.input_callbacks, cfg.gfx_callbacks, cfg.events_callbacks, cfg.error_handling_callbacks, cfg.threads_callbacks);

    ultramodern::gfx_callbacks_t gfx_callbacks = cfg.gfx_callbacks;

    ultramodern::gfx_callbacks_t::gfx_data_t gfx_data{};

    if (gfx_callbacks.create_gfx) {
        gfx_data = gfx_callbacks.create_gfx();
    }

    auto window_handle = cfg.window_handle;
    if (window_handle == ultramodern::renderer::WindowHandle{}) {
        if (gfx_callbacks.create_window) {
            window_handle = gfx_callbacks.create_window(gfx_data);
        }
        else {
            assert(false && "No create_window callback provided");
        }
    }

    ultramodern::set_message_queue_control(cfg.message_queue_control);

    recomp::mods::initialize_mods();
    recomp::mods::scan_mods();


    // Allocate rdram without comitting it. Use a platform-specific virtual allocation function
    // that initializes to zero. Protect the region above the memory size to catch accesses to invalid addresses.
    uint8_t* rdram;
    bool alloc_failed;
#ifdef _WIN32
    rdram = reinterpret_cast<uint8_t*>(VirtualAlloc(nullptr, allocation_size, MEM_COMMIT | MEM_RESERVE, PAGE_NOACCESS));
    DWORD old_protect = 0;
    alloc_failed = (rdram == nullptr);
    if (!alloc_failed) {
        // VirtualProtect returns 0 on failure.
        alloc_failed = (VirtualProtect(rdram, mem_size, PAGE_READWRITE, &old_protect) == 0);
        if (alloc_failed) {
            VirtualFree(rdram, 0, MEM_RELEASE);
        }
    }
#elif defined(__3DS__)
    // No virtual memory tricks on the 3DS: one zero-filled block the size of
    // the (reduced) RDRAM region. Wild accesses corrupt instead of faulting.
    // Page-aligned, because malloc only guarantees 8 bytes and the recomp heap
    // (o1heap) needs its arena, an offset into RDRAM, aligned to 16.
    static_assert(allocation_size >= mem_size, "the 3DS commits the whole RDRAM region");
    static_assert(allocation_size % 0x1000 == 0, "aligned_alloc needs a multiple of the alignment");
    rdram = reinterpret_cast<uint8_t*>(std::aligned_alloc(0x1000, allocation_size));
    alloc_failed = (rdram == nullptr);
    if (!alloc_failed) {
        std::memset(rdram, 0, allocation_size);
    }
#else
    rdram = (uint8_t*)mmap(NULL, allocation_size, PROT_NONE, MAP_ANON | MAP_PRIVATE, -1, 0);
    alloc_failed = rdram == reinterpret_cast<uint8_t*>(MAP_FAILED);
    if (!alloc_failed) {
        // mprotect returns -1 on failure.
        alloc_failed = (mprotect(rdram, mem_size, PROT_READ | PROT_WRITE) == -1);
        if (alloc_failed) {
            munmap(rdram, allocation_size);
        }
    }
#endif

    if (alloc_failed) {
        ultramodern::error_handling::message_box("Failed to allocate memory!");
        return;
    }

    recomp::register_heap_exports();
    recomp::mods::register_config_exports();
    recomp::mods::register_hook_exports();

    ultramodern::HostThread game_thread{ultramodern::HostThreadKind::GameStart, [window_handle, rdram]() {
        debug_printf("[Recomp] Starting\n");

        ultramodern::set_native_thread_name("Game Start Thread");

        ultramodern::preinit(rdram, window_handle);

        recomp_context context{};

        // Loop until the game starts.
        while (!wait_for_game_started(rdram, &context)) {}
    }};

    parse_cli(cfg.argc, cfg.argv);

    while (!exited) {
        ultramodern::sleep_milliseconds(1);
        if (gfx_callbacks.update_gfx != nullptr) {
            gfx_callbacks.update_gfx(gfx_data);
        }
    }

    graphics_shutdown_ready.signal();

    game_thread.join();
    ultramodern::join_event_threads();
    ultramodern::join_thread_cleaner_thread();
    ultramodern::join_saving_thread();
    
    // rdram is left for the OS to free at exit: the game's own threads (osCreateThread) aren't
    // joined and may still be running, and unmapping it under them crashes them on Linux and macOS.
}
