# Racer 3DS

A Nintendo 3DS port of *Star Wars Episode I: Racer* (N64): rt64-3ds rendering the game's
display lists on the PICA200, librecomp's recompiled game code, and the N64 runtime's
ultramodern layer on top of devkitARM.

This folder is the source tree **with the launch crash fixed**, the `Makefile`, and the
binaries built from it. No ROM is included, and none is needed to build the port itself —
see *Your ROM* below.

```
racer3ds/
├── readme.md              this file
├── Makefile               the entry point: setup / recompile / 3dsx / cia
├── BUILDING.md            the longer build notes (toolchain versions, gotchas)
├── README.md              the port's own overview
├── docs/RT64-3DS-PORT.md  the port's design, and the first-hardware checklist (§8)
├── docs/LAUNCH-CRASH-FIX.md  what the crash actually was, and every change in detail
├── bin/Racer3DS.3dsx      built here from this tree, 4 690 500 bytes (hbmenu)
├── bin/Racer3DS.cia       built here from this tree, 2 604 992 bytes (title id 0xF9048)
├── platform/3ds/          main_3ds.cpp, recomp_api_3ds.cpp, CMakeLists.txt, icon
├── lib/rt64-3ds/          the renderer, the 3DS platform layer, the CIA helper
├── lib/N64ModernRuntime/  librecomp + ultramodern + N64Recomp (the runtime)
├── recomp/                recomp.toml / symbols.toml / the RSP ucode's toml
└── tools/3ds/             setup.sh (host recompilers), recompile.sh (ROM -> C)
```

## The launch crash, in one paragraph

The port died about a second after boot with a crash dump naming libctru's `hidScanInput`
(a read of `0x00000010`). Two separate faults stacked on top of each other: Racer pokes
hardware registers directly (`0xA4400024`, `0xA4600010`–`0xA4600030` from its own audio
driver at `0x8008BF3C`), and on the 3DS the runtime's RDRAM accessor has no range check,
so those writes landed 580 MB past the 16 MB RDRAM block — inside the port's own heap and
`.bss`. And `read_save_file()` called `std::filesystem::create_directories` without an
`error_code`; when that throws on a device path there is no handler, so `std::terminate`
ran `exit()`, `__appExit` unmapped the HID shared memory **while the game, renderer, audio
and ROM threads were still running**, and the next input poll faulted on the freed state.
Which is why the dump named a libctru function instead of the code at fault.

Four changes fix it; [`docs/LAUNCH-CRASH-FIX.md`](docs/LAUNCH-CRASH-FIX.md) has the
diagnosis, the evidence and the reasoning for each:

| file | change |
|---|---|
| `lib/N64ModernRuntime/N64Recomp/include/recomp.h` | bounds guard on every RDRAM offset; out-of-range folded into scratch, offenders logged |
| `lib/N64ModernRuntime/librecomp/include/librecomp/addresses.hpp` | the 3DS allocation grows a 1 MB scratch tail after the RDRAM window |
| `lib/N64ModernRuntime/librecomp/src/recomp.cpp` | `recomp_rdram_guard()`; the allocation; `error_code` overloads for the ROM delete and the mods directories |
| `lib/N64ModernRuntime/librecomp/src/pi.cpp` | the save directory is created with `error_code` and reported, never thrown |
| `lib/rt64-3ds/src/platform/recomp3ds_run.cpp` | a `std::set_terminate` reporter that logs the exception and ends the process without tearing services down under other threads |
| `platform/3ds/CMakeLists.txt` | pass `RECOMP_MEM_SIZE_MB` to the generated code, so the guard's window always matches the runtime's |

Verified in emulation before these files were packaged: the same tree used to stop with
`[FATAL] Unimplemented 32-bit read, addr: 00000010` one second after
`Initializing recomp heap`; it now runs the whole boot and keeps producing frames —
`rt64-3ds: progress: frame 436 phase 0 draw 145 of 146`, 400+ frames in a 180 s window at
emulator speed, with the game blanking and restoring its own video across loading screens.
The only accesses the guard has to fold away are the register pokes listed above.

To be exact about what was checked where: that boot run was made from this tree's sources,
one build before packaging. The `bin/` files are the output of a clean
`make setup && make recompile ROM=… && make` of the tree in this folder (every step exit 0,
115 targets), so they are built from the sources as shipped rather than copied out of a
scratch build directory. Running `bin/Racer3DS.3dsx` yourself under the emulator below is
the check to repeat on your side, and it is the same command line.

## Building

You need devkitARM (any current release; r16.1.0 was used here) with the 3DS packages, plus
cmake ≥ 3.20, ninja, python3 and a C++17 host compiler. `makerom` (from
[Project_CTR](https://github.com/3DSGuy/Project_CTR)) must be on `PATH` to build the CIA;
everything else works without it.

```sh
source /etc/profile.d/devkit-env.sh        # sets DEVKITPRO / DEVKITARM
sudo dkp-pacman -S --noconfirm 3ds-dev 3ds-zlib

make setup                      # build the host N64Recomp / RSPRecomp tools
make recompile ROM=/path/to/baserom.z64
make                            # -> build-3ds/Racer3DS.3dsx and Racer3DS.cia
```

Useful variations: `make 3dsx`, `make cia`, `make BUILD_DIR=out` (the `.map` and the
symbol-carrying ELF land in the build dir — keep it if you want to resolve a crash dump),
`make clean`, `make distclean` (also drops all ROM-derived code).

### Your ROM

The game is not redistributed, and nothing ROM-derived is in this folder: the recompiled
code under `platform/3ds/generated/` is produced by `make recompile` and is gitignored.
Use the **US** release, which is what the port validates:

| | |
|---|---|
| header game ID | `NEPE` |
| size | 33 554 432 bytes (32 MiB), big-endian `.z64` |
| CRC1 | `0x72F70398` |
| XXH3-64 | `0x9B89D0F9EBC12D32` |

The ROM is validated at first boot and the hash is checked again afterwards; a mismatch
deletes the stored copy rather than guessing. The prebuilt `bin/` files contain no ROM data:
the game is read from the SD card at runtime, so the same binary works for whoever supplies
their own copy.

## Running it on a console

Both flavours expect the same files on the card:

```
sdmc:/3ds/racer/baserom.z64      the ROM (any name you set in the port; this is the default)
sdmc:/3ds/racer/settings.ini     written on first run, then read at boot
sdmc:/3ds/racer/saves/          EEP16K save files (swe1racer.bin), written beside the ROM
sdmc:/3ds/racer/log.txt          the boot and diagnostics log — read this first when it misbehaves
```

* **`.3dsx`** — drop `Racer3DS.3dsx` anywhere on the card and start it from hbmenu.
* **`.cia`** — install with FBI (product code `RACER-3DS`, unique id `0xF9048`). Its header
  asks for 64 MB of app memory (124 MB on a New 3DS), a 512 KB stack, L2 cache, both CPU
  cores and "use on SD"; the memory figures are what the runtime's RDRAM model and the
  renderer need, so do not shrink them.

`settings.ini` is written on first boot and holds the stereo convergence/HUD-depth knobs,
the stick dead zones, the frame cap, `rom_stream`, and the `dbg_*` switches (including
`dbg_audio_rsp`, which swaps the HLE audio interpreter for the recompiled ucode). Saves and
settings are written via a `.part` file and renamed, so a lost write cannot destroy the old
one.

For a first hardware run, work through §8 of `docs/RT64-3DS-PORT.md` (boot/statistics log,
the two-core layout, VI scanout, audio output, HID, save rotation) and keep `log.txt`.

## Status

Working and exercised in emulation: the ROM validation, the SD streaming of all 32 MiB
through a 16 × 128 KB cache, the recompiled code (906 functions in 28 C files, 1384 entries
in the section table), the runtime's boot state (PI handle, VI state, `osMemSize`), the
recomp heap, the renderer's display-list path (real frames with hundreds of draws), the
settings menu, save rotation, the two-core thread layout and the stall watchdog.

Known gap, and it is audio: the game configures its audio interface through MMIO
(`AI_DACRATE`, `AI_BITRATE`, `AI_BADDR`, `AI_COUNT`, `AI_CONTROL`). Those writes are now
harmless — that is the fix — but nothing consumes them, so the ndsp stream is not fed from
the AI path: expect video with no sound until an AI handler exists. `log.txt`'s
`rdram guard:` lines are the exact list of registers the game touches, and `0x8008BF3C` is
the guest function to route. `ndspInit` also needs `sdmc:/3ds/dspfirm.cdc` present; without
it the port logs `audio off` and carries on.

## Testing in an emulator

Tested with [Panda3DS](https://github.com/wheremyfoodat/Panda3DS) (`.3dsx` loads directly;
a `.cia` needs installing into its NAND). Headless, on the CPU:

```sh
export SDL_VIDEODRIVER=x11 SDL_AUDIODRIVER=dummy
export LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=4.5
xvfb-run -a ./Alber /path/to/Racer3DS.3dsx
```

with `[GPU] Renderer="null"` in the config to skip GPU emulation (there is then no
picture — read the log, not the screen), and `[SD] UseVirtualSD=true` so the guest's
`sdmc:/` is the emulator's `Emulator Files/Racer3DS/SDMC/` directory: put `baserom.z64`
under `…/SDMC/3ds/racer/` there.

Several failures seen under Panda3DS are the *emulator's*, not the port's — it hard-panics
on FS and SVC calls it has not implemented. Hit by this port: `SDMC renameFile` (the save
and settings rotation), `svcInvalidate/Store/FlushProcessDataCache` (`0x52`–`0x54`),
`FSUSER_RenameDirectory` (`0x080A0244`), `svcExitProcess` at a clean exit, and `ndspInit`
(needs the DSP firmware). If a run dies, `arm-none-eabi-addr2line -f -C -e <build>/Racer3DS
<pc>` against the ELF resolves the guest PC: a `.3dsx` loads its Text at `0x00100000`,
which is where the ELF puts it, so the numbers match without arithmetic.
