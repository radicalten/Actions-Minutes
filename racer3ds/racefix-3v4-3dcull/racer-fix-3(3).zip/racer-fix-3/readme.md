# Racer 3DS — race-rendering and wider-view fix

This is the Nintendo 3DS port of the [sp00nznet/racer](https://github.com/sp00nznet/racer) static recompilation of *Star Wars Episode I: Racer*, based on the source archive in [radicalten/Actions-Minutes4](https://github.com/radicalten/Actions-Minutes4). It includes the patched source, build tools, and newly compiled `bin/Racer3DS.3dsx` and `bin/Racer3DS.cia`. The project is unofficial and is not affiliated with the game's rightsholders.

## What changed

The renderer no longer treats `VI_WIDTH_REG` (the framebuffer's row pitch) as the displayed picture's width when following Racer's VI. It computes the active source width from the horizontal VI window and the low 12-bit, 2.10 fixed-point X scale:

```
visible source pixels = round((H_END - H_START) * X_SCALE / 1024)
```

For the affected mode observed in the emulator, the field stride is 640, the active window is 108–748, and the X scale is `0x200`: the source is **320**, not 640, pixels wide. The mode is serrated/interlaced and the doubled field stride skips alternate image rows. Its full display-list frame is **320×480**, not 320×240. Treating it as 240 lines cropped the lower part of menus such as the garage's main menu.

The renderer now switches automatically between the progressive 320×240 source and the 320×480 interlaced source, holding the last valid dimensions while the VI is blank or unset. This interlaced-height rule is explicitly enabled for Racer and is not a general-purpose VI emulator. Debug width and height overrides still take precedence.

The original 4:3 picture keeps its proportions in the center **320×240** of the **400×240 top screen**. The renderer opens Racer's near-edge full-view scissors so already-submitted 3D geometry can appear in the 40-pixel margins on each side. This reveals a genuinely wider view without stretching the original image; menus and the race HUD stay in the central frame. Scenes that do not provide extra geometry can have bars, gaps or other artifacts at the edges. Some cutscenes are letterboxed. All game output stays on the top screen; the bottom screen is the FPS/status/settings/debug console.

The race-world fix implements F3DEX2's `gSPForceMatrix` combined modelview-projection command in `rt64_3ds_dl.cpp`. Racer uses these precomputed matrices for its race camera; the earlier interpreter ignored them, leaving the race world beyond the far plane. The regular matrix stacks still take over after the next ordinary matrix load. Frame interpolation is disabled for a list containing a forced matrix rather than inventing an unsafe decomposition; Racer does not enable interpolation.

The reusable VI calculations are in `lib/rt64-3ds/src/renderer/rt64_3ds_vi.h`; the integration is in `rt64_3ds_context.cpp`. `make test` runs ROM-free tests for scanout sizing, un-stretched geometry, scissor expansion, forced matrices, and direct game-output routing.

## ROM and redistribution

**No ROM or `baserom.z64.zip` is included.** Both the prebuilt program and a fresh build require your own matching, legally obtained US big-endian ROM:

| Requirement | Value |
|---|---|
| SD card path | `sdmc:/3ds/racer/baserom.z64` |
| Format / size | US `NEPE`, big-endian `.z64`, 32 MiB |
| Header CRC1 | `0x72F70398` |
| Runtime XXH3-64 | `0x9B89D0F9EBC12D32` |

The generated C/C++ directory `platform/3ds/generated/` is not included; regenerate it from your own ROM when rebuilding. **The supplied CIA and 3DSX nevertheless contain compiled game code and audio microcode derived from the ROM.** The raw ROM and game assets still have to be supplied separately at runtime. Do not redistribute the binaries unless you have the necessary rights. See `NOTICE` and the component license files.

## Installing

1. Create `sdmc:/3ds/racer/` and place your matching ROM there as `baserom.z64`. The game checks its hash before starting.
2. For Homebrew Launcher, copy `bin/Racer3DS.3dsx` to a folder under `sdmc:/3ds/` and launch it. Alternatively, copy `bin/Racer3DS.cia` to the SD card, install it with FBI or GodMode9, and launch **Star Wars Racer 3DS** from HOME Menu.
3. Saves and `settings.ini` are created beside the ROM. SELECT opens the port's settings menu. If an old `settings.ini` contains `dbg_frame_w` or `dbg_frame_h`, remove those entries or set both to `0` and restart to use the corrected automatic sizing.

The program uses the system's NDSP audio service; 3DS homebrew may require DSP firmware dumped from your own console. No firmware is supplied here.

Default controls: 3DS A/B map to N64 A/B, Y or ZL to Z, R or ZR to R, X to C-Up, C-Stick to C buttons, and Start, D-pad and Circle Pad to their N64 counterparts. Settings are adjustable on the touch screen.

## Build from source

Install a host C/C++ compiler, CMake 3.20+, Ninja or Make, Python 3 and devkitPro's `3ds-dev` toolchain (devkitARM, libctru, citro3d, picasso, `3dsxtool` and `smdhtool`). Put Project_CTR `makerom` on `PATH` for the CIA; `bannertool` is optional because `smdhtool` provides the icon fallback. Set `DEVKITPRO` and `DEVKITARM` for your installation. See `BUILDING.md` for complete prerequisites and options.

```sh
# Optional: tests need a host C++20 compiler and Python 3, not a ROM.
make test

# Build the vendored host recompilers; generate game code from your ROM.
make setup JOBS=1
make recompile ROM=/path/to/your/baserom.z64

# Cross-compile and package both formats. Increase JOBS if memory permits.
make JOBS=1
# Outputs: build-3ds/Racer3DS.3dsx and build-3ds/Racer3DS.cia
```

`make cia` and `make 3dsx` build the individual packages; `make clean` removes build outputs and `make distclean` also removes the ROM-derived generated sources. The source dependencies are vendored; the build itself does not fetch them from the network. The included binaries were built with devkitARM GCC 16.1.0, libctru/citro3d, `3dsxtool`, `smdhtool`, and makerom 0.19.0.

## Verification and limits

- ROM-free `make test` passes for progressive/interlaced sizing, blanking and overrides, 4:3 mapping, near-edge scissors, forced matrices (including deferred vertices), and top-screen output routing. Both packages were built with devkitARM; `SHA256SUMS` verifies the included binaries. Rebuilt hashes can differ because source paths are embedded.
- The included 3DSX was run in Azahar 2126.2 with the default rendering settings and no width or height override. The title, complete garage menu, Inspect Vehicle, and Boonta Training Course race were checked. The race scenery and HUD rendered, and acceleration and steering were exercised. Garage and race scenes showed extra side geometry without horizontally stretching the central image. FPS/debug information remained on the bottom screen.
- This was a targeted emulator check, not a complete race/playthrough or a physical-console test. Azahar reported intermittent main-thread stalls, and some wider-view edges can expose missing geometry or clear-color gaps; behavior and performance on hardware remain unverified. The CIA installed through Azahar, and its installed content launched into the 3D attract sequence; installation on a physical console was not tested. Audio was disabled in the emulator because DSP firmware was absent, so sound was not reverified.
- Panda3DS was attempted during the preceding revision, but the version tested stopped at an unimplemented system call before producing a frame. No claim of Panda3DS or on-hardware verification is made.

## Source layout

- `platform/3ds/` — game entry, host functions and 3DS CMake target.
- `lib/rt64-3ds/` — renderer, 3DS runtime, VI fix and host tests.
- `lib/N64ModernRuntime/` — patched runtime and vendored host recompilers.
- `recomp/` and `tools/3ds/` — ROM-recompilation configuration and scripts.
- `bin/` — newly built packages; `BUILDING.md` and `NOTICE` provide build and license details.
