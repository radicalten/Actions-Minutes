# Racer 3DS

A Nintendo 3DS port of *Star Wars Episode I: Racer* (N64): rt64-3ds rendering the game's
display lists on the PICA200, librecomp's recompiled game code, and the N64 runtime's
ultramodern layer on top of devkitARM.

This folder is the source tree **with the launch crash fixed**, the `Makefile`, and the
binaries built from it. No ROM is included, and none is needed to build the port itself —
see *Your ROM* below.

```
racer3ds/
├── readme.md              this file
├── Makefile               the entry point: setup / recompile / 3dsx / cia
├── BUILDING.md            the longer build notes (toolchain versions, gotchas)
├── README.md              the port's own overview
├── docs/RT64-3DS-PORT.md  the port's design, and the first-hardware checklist (§8)
├── docs/LAUNCH-CRASH-FIX.md  what the crash actually was, and every change in detail
├── bin/Racer3DS.3dsx      built here from this tree, 4 696 412 bytes (hbmenu)
├── bin/Racer3DS.cia       built here from this tree, 2 608 576 bytes (title id 0xF9048)
├── platform/3ds/          main_3ds.cpp, recomp_api_3ds.cpp, CMakeLists.txt, icon
├── lib/rt64-3ds/          the renderer, the 3DS platform layer, the CIA helper,
│                          and tests/screen_geometry_test.cpp (host: the picture's placement)
├── lib/N64ModernRuntime/  librecomp + ultramodern + N64Recomp (the runtime)
├── recomp/                recomp.toml / symbols.toml / the RSP ucode's toml
└── tools/3ds/             setup.sh (host recompilers), recompile.sh (ROM -> C)
```

## The launch crash, in one paragraph

The port died about a second after boot with a crash dump naming libctru's `hidScanInput`
(a read of `0x00000010`). Two separate faults stacked on top of each other: Racer pokes
hardware registers directly (`0xA4400024`, `0xA4600010`–`0xA4600030` from its own audio
driver at `0x8008BF3C`), and on the 3DS the runtime's RDRAM accessor has no range check,
so those writes landed 580 MB past the 16 MB RDRAM block — inside the port's own heap and
`.bss`. And `read_save_file()` called `std::filesystem::create_directories` without an
`error_code`; when that throws on a device path there is no handler, so `std::terminate`
ran `exit()`, `__appExit` unmapped the HID shared memory **while the game, renderer, audio
and ROM threads were still running**, and the next input poll faulted on the freed state.
Which is why the dump named a libctru function instead of the code at fault.

Four changes fix it; [`docs/LAUNCH-CRASH-FIX.md`](docs/LAUNCH-CRASH-FIX.md) has the
diagnosis, the evidence and the reasoning for each:

| file | change |
|---|---|
| `lib/N64ModernRuntime/N64Recomp/include/recomp.h` | bounds guard on every RDRAM offset; out-of-range folded into scratch, offenders logged |
| `lib/N64ModernRuntime/librecomp/include/librecomp/addresses.hpp` | the 3DS allocation grows a 1 MB scratch tail after the RDRAM window |
| `lib/N64ModernRuntime/librecomp/src/recomp.cpp` | `recomp_rdram_guard()`; the allocation; `error_code` overloads for the ROM delete and the mods directories |
| `lib/N64ModernRuntime/librecomp/src/pi.cpp` | the save directory is created with `error_code` and reported, never thrown |
| `lib/rt64-3ds/src/platform/recomp3ds_run.cpp` | a `std::set_terminate` reporter that logs the exception and ends the process without tearing services down under other threads |
| `platform/3ds/CMakeLists.txt` | pass `RECOMP_MEM_SIZE_MB` to the generated code, so the guard's window always matches the runtime's |

Verified in emulation before these files were packaged: the same tree used to stop with
`[FATAL] Unimplemented 32-bit read, addr: 00000010` one second after
`Initializing recomp heap`; it now runs the whole boot and keeps producing frames —
`rt64-3ds: progress: frame 421 phase 0 draw 145 of 146`, 400+ frames in a 215 s window at
emulator speed, frames of up to 476 recorded draws, and the game blanking and restoring its own
video across loading screens.
The only accesses the guard has to fold away are the register pokes listed above.

To be exact about what was checked where: the emulator run launched **the same `.3dsx` that is
packaged in `bin/`** (copied out of the build directory into the emulator's guest path and run,
sha-256 compared first), so the bytes tested and the bytes shipped are the same. A 215 s run
reached the game's **421st frame** with nothing in the log matching `FATAL`, `panic` or
`terminate` — boot, the video being blanked and restored across the loading screens, and
frames of 36–146 display-list draws flowing, with the guard folding away only the
`0xA4600010`–`0xA4600030` audio-interface pokes above. What it says about the screen:

```
recomp3ds: settings: ... dbg_cull_dl -1 dbg_fill_clear -1 dbg_eye_depth16 -1 dbg_frame_w 0
          dbg_frame_h 0 render_vbo_verts 0 ...
rt64-3ds: citro3d renderer up (linear free 10150 KB)
rt64-3ds: vertex buffers: 2 x 65536 verts (1792 KB each), 10525 KB linear left
rt64-3ds: the game's VI: 320x240 framebuffer (status 0000311E, x_scale 200, y_scale 0, h 0..0,
          v 25..1FF) -> lists read at 320x240, x1.000/1.000, 40.0-unit margins
rt64-3ds: the game's VI changed: VI: 640x240 framebuffer (status 0000305E, x_scale 200,
          y_scale 0, h 6C..2EC, v 23..1FD) -> lists read at 640x240, x0.500/1.000,
          80.0-unit margins
rt64-3ds: game frame 640x240 on the 400x240: x0.500/1.000 (0.5000), 80.0-unit margins,
          depth grid 50x30 of 13x8 px
rt64-3ds: the game's VI changed: VI: 320x240 framebuffer (status 0000311E, ...) -> ...
rt64-3ds: progress: frame 421 phase 0 draw 145 of 146
```

Quoted from `sdmc:/3ds/racer/log.txt` as the run left it, so these are the lines to look for on a
console too. `400x240` is in the `game frame … on the 400x240` line, and the frame's own size is
what the rest follows from; the per-frame trace that also prints how many triangles the cull
dropped and how many clears were skipped is behind `dbg_frame_trace_from`/`dbg_frame_trace_count`
(2: `culling: 2743 of 3211 tris (85%), fill/depth clear skipped on … draws` — that line is from
the run where those keys were set), and every frame line ends with `verts lost N (vtx a/b vbo c)`
whatever the settings, which read `0` in every frame of this run.

So the target is 400×240, Racer's 320×240 picture sits in it centred and un-stretched — and
Racer really does change framebuffer size during a run, which is what the lines after the
first are for: the run that measured them is the run that proves the old fixed-320 placement
was cropping a mode rather than displaying it (see "What the screen shows" below). No frame
reported lost vertices, in this run or in the one built with the array back at its old 64
slots, which is why the vertex-capacity change is listed as a correctness fix rather than the
cause. The `bin/` files come from a clean `make setup && make recompile ROM=… && make` of the
tree in this folder (every step exit 0), and re-running that same `.3dsx` under the emulator
below is the check to repeat on your side; it is the same command line.

## Building

You need devkitARM (any current release; r16.1.0 was used here) with the 3DS packages, plus
cmake ≥ 3.20, ninja, python3 and a C++17 host compiler. `makerom` (from
[Project_CTR](https://github.com/3DSGuy/Project_CTR)) must be on `PATH` to build the CIA;
everything else works without it.

```sh
source /etc/profile.d/devkit-env.sh        # sets DEVKITPRO / DEVKITARM
sudo dkp-pacman -S --noconfirm 3ds-dev 3ds-zlib

make setup                      # build the host N64Recomp / RSPRecomp tools
make recompile ROM=/path/to/baserom.z64
make                            # -> build-3ds/Racer3DS.3dsx and Racer3DS.cia
```

Useful variations: `make 3dsx`, `make cia`, `make BUILD_DIR=out` (the `.map` and the
symbol-carrying ELF land in the build dir — keep it if you want to resolve a crash dump),
`make clean`, `make distclean` (also drops all ROM-derived code).

### Your ROM

The game is not redistributed, and nothing ROM-derived is in this folder: the recompiled
code under `platform/3ds/generated/` is produced by `make recompile` and is gitignored.
Use the **US** release, which is what the port validates:

| | |
|---|---|
| header game ID | `NEPE` |
| size | 33 554 432 bytes (32 MiB), big-endian `.z64` |
| CRC1 | `0x72F70398` |
| XXH3-64 | `0x9B89D0F9EBC12D32` |

The ROM is validated at first boot and the hash is checked again afterwards; a mismatch
deletes the stored copy rather than guessing. The prebuilt `bin/` files contain no ROM data:
the game is read from the SD card at runtime, so the same binary works for whoever supplies
their own copy.

## Running it on a console

Both flavours expect the same files on the card:

```
sdmc:/3ds/racer/baserom.z64      the ROM (any name you set in the port; this is the default)
sdmc:/3ds/racer/settings.ini     written on first run, then read at boot
sdmc:/3ds/racer/saves/          EEP16K save files (swe1racer.bin), written beside the ROM
sdmc:/3ds/racer/log.txt          the boot and diagnostics log — read this first when it misbehaves
```

* **`.3dsx`** — drop `Racer3DS.3dsx` anywhere on the card and start it from hbmenu.
* **`.cia`** — install with FBI (product code `RACER-3DS`, unique id `0xF9048`). Its header
  asks for 64 MB of app memory (124 MB on a New 3DS), a 512 KB stack, L2 cache, both CPU
  cores and "use on SD"; the memory figures are what the runtime's RDRAM model and the
  renderer need, so do not shrink them.

`settings.ini` is written on first boot and holds the stereo convergence/HUD-depth knobs,
the stick dead zones, the frame cap, `rom_stream`, and the `dbg_*` switches (including
`dbg_audio_rsp`, which swaps the HLE audio interpreter for the recompiled ucode). Saves and
settings are written via a `.part` file and renamed, so a lost write cannot destroy the old
one.

For a first hardware run, work through §8 of `docs/RT64-3DS-PORT.md` (boot/statistics log,
the two-core layout, VI scanout, audio output, HID, save rotation) and keep `log.txt`.

## Status

Confirmed on real hardware (Old 3DS, 2026-10-26): the port boots into the game, plays, and
the launch crash is gone. **Audio works** — sound comes from the game's recompiled
`aspMain` tasks interpreted on the CPU (`GameDesc::audio_hle`) into ndsp, not from the AI
registers, so the game's `AI_*` pokes being folded away by the guard never implied silence;
that was a wrong claim in this file until now. Frame rate on the tested unit: **18–21 fps**
against the N64's 24 fps target. `ndspInit` needs `sdmc:/3ds/dspfirm.cdc` present (the
standard homebrew requirement); without it the port logs `audio off` and carries on.

Working and exercised in emulation: the ROM validation, the SD streaming of all 32 MiB
through a 16 × 128 KB cache, the recompiled code (906 functions in 28 C files, 1384 entries
in the section table), the runtime's boot state (PI handle, VI state, `osMemSize`), the
recomp heap, the renderer's display-list path (real frames with hundreds of draws), the
settings menu, save rotation, the two-core thread layout and the stall watchdog.

Open: the picture's geometry past the menu screens — text sometimes off screen, the 3D
scene not shown as the N64 shows it. What was found and changed is below; the emulator here
reaches the boot and title screens but not a race, so the last step needs the console.

## What the screen shows

The renderer draws into a citro3d target created as `C3D_RenderTargetCreate(240, 400, ...)`.
citro3d takes width-then-height, and the 3DS's top framebuffer is physically 240 columns by
400 rows — a display transfer turns that into the 400-wide, 240-tall picture, which is
scanned out 1:1 (`GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_NO)`, no stretch anywhere in the
path). So the rendering target is **400×240** as the eye sees it, and inside it the N64's
**320×240** frame sits centred: `ScreenGeometry` scales by `240 / frame_height` and centres,
which for a 320×240 frame is scale 1.000 and 40 units (40 screen pixels) of black either
side — the game's picture on columns 40…360. `apply_geometry` logs the decision once per
frame size:

```
rt64-3ds: game frame 320x240 on the 400x240: x1.0000/1.000 (1.0000), 40.0-unit margins, depth grid 40x30 of 8x8 px
```

The rest of that line is worth reading too, because it says what the port can and cannot
learn from the runtime: `status 0000311E` is a 16-bit, non-interlaced framebuffer whose lines
the VI doubles, and `x_scale 200` is the N64's 2× horizontal stretch of a 320-pixel-wide
framebuffer — a 640×480 4:3 picture, so square pixels and the placement needs no correction.
`h_start` and `v_start` read as nothing useful: the runtime's VI state keeps the control,
width and scale registers and not the horizontal/vertical spans, which is why the placement
takes the *width* from the VI and the *shape* from the description instead of deriving both
from the VI. (A future host that fills all of `ViRegs` could drop `display_aspect` and read
the shape out of the spans as well.)

Two things changed this round, both aimed at the two symptoms reported from hardware — text
partly off screen, and the 3D scene in a race not looking like the N64's:

* **The frame size is read, not assumed — and Racer does change it.**
  `RenderDesc::vi_width/vi_height` used to be the last word, checked against nothing, and the
  game does not keep one framebuffer: partway through a run it moves to a 640-wide one and
  back again. The port follows the game's `VI_WIDTH_REG` before each list is read, and the log
  of a boot run (that very `.3dsx` in `bin/`) shows the whole exchange:

  ```
  rt64-3ds: the game's VI: 320x240 framebuffer (status 0000311E, ...) -> lists read at
            320x240, x1.000/1.000, 40.0-unit margins
  rt64-3ds: the game's VI changed: VI: 640x240 framebuffer (status 0000305E, h 6C..2EC,
            v 23..1FD) -> lists read at 640x240, x0.500/1.000, 80.0-unit margins
  rt64-3ds: game frame 640x240 on the 400x240: x0.500/1.000 (0.5000), 80.0-unit margins,
            depth grid 50x30 of 13x8 px
  ```

  Placed by the fixed 320, that 640-wide mode ran from screen x 40 to x 680: 280 of its 640
  columns fell off past the right edge, the view was cropped and oversized, and text the game
  anchored near an edge went with it — the pair of symptoms in the report, starting where the
  boot screens hand over. Placed by the VI, its 640 columns get 0.500 px each (320 px of
  picture, centred, 40 px of black either side) while its 240 rows keep 1.000: the 4:3 picture
  an N64 showed on a TV. Racer has no `gEX` tagging (the widescreen commands RT64's patched
  games use) and no `frame_sizes` table, so nothing else could have caught a mode change. A
  width the N64 cannot program (below 64 or above 800 — the VI not set up yet) is ignored in
  favour of the `RenderDesc`, so a game that agrees with its own description is untouched.
* **The interpreter's vertex array is the RSP's size.** `kMaxVerts` was 64 where the RSP's
  vertex buffer holds 80 (0x800 bytes of 16-byte vertices), and the shortfall was silent: a
  `gSPVertex` batch reaching past slot 63 was cut at 64, and a triangle naming a higher slot
  was dropped instead of drawn — the tail of every object that fills the buffer (20 quads is
  exactly 80 vertices). It is 80 now. Neither the 64 nor the 80 lost anything on the boot and
  title screens (measured: the new counters read zero across 421 frames), but a busy 3D scene
  is where a 64 would bite, and the loss cannot hide again: the frame line ends with
  `verts lost N (vtx clamped/index vbo full)` and the watchdog's `progress:` line adds
  `** VERTS LEFT OUT **` whenever it is nonzero. `render_vbo_verts` in `settings.ini` raises
  the frame's vertex buffer above its 65536 (the log says what it chose:
  `vertex buffers: 2 x 65536 verts (1792 KB each)`) — only worth it if `vbo` above reads
  nonzero, since those bytes come out of the linear heap the textures and read-backs use.

* **The two axes can be scaled apart.** `RenderDesc::display_aspect` places the frame as the
  TV showed it (4:3 for Racer, set in its description): a 320×240 frame is still 1:1 in a
  320×240 box, but a wider frame the N64 stretched on the way out is *fitted* — the 640-wide
  mode above at 0.500 horizontally against 1.000 vertically, a 512-wide one at 0.625 —
  instead of cropped. `ScreenGeometry`
  gained `scale_x` beside `scale`; everything that maps N64 coordinates to pixels goes
  through `screen_x`/`screen_y`, and the projection already took its x range from `x0` and
  `w`, so the split is consistent by construction. `lib/rt64-3ds/tests/screen_geometry_test.cpp`
  compiles that header on the host and pins both properties:

  ```sh
  cd lib/rt64-3ds/tests && g++ -std=c++20 -I../src/renderer -o /tmp/sgt screen_geometry_test.cpp && /tmp/sgt
  ```

  All 21 checks pass: the square-pixel frames (320×240, Banjo's 292×216) come out identical
  to the old placement, and the non-square ones stay inside the screen.

**For the models specifically, the switches are in `settings.ini`** so a picture can be A/B-ed
on the console without a rebuild. Each is `-1` (leave it as the game's description says) or
`0`/`1` to force it, and the renderer logs which one it applied:

| key | what it changes | why it is a suspect |
|---|---|---|
| `dbg_cull_dl` | honour or ignore `gSPCullDisplayList` | honouring it can end an object's list early; a test that disagrees with the game drops whole models. Now **off** for Racer (the desktop renderer ignores the command, and Racer was never measured with it); `=1` turns it back on to compare. `log.txt`'s per-frame line ends with `culldl ended/tests` |
| `dbg_eye_depth16` | 16-bit or 24-bit eye depth | 16-bit depth is a bandwidth saving that costs precision far from the camera — Racer's tracks are long-view, and `z`-precision loss shows as surfaces fighting or vanishing in the world and not in menus |
| `dbg_fill_clear` | take the frame's leading full-screen fill as the eyes' clear | if Racer's first rectangle is not its clear, turning it into one drops what the game meant to paint |
| `dbg_screen_cull_off`, `dbg_screen_cull_pct` | the port's own triangle cull | triangles past the screen's edges are dropped for speed; a wrong slack culls geometry that should be visible |
| `dbg_no_scissor` | no scissor at all | shows draws that a wrong clip hides (diagnostic, slow) |
| `dbg_frame_w`, `dbg_frame_h` | force the frame size | for a mode whose VI needs a height of its own (rows the N64 doubles) |

To send a frame along with `log.txt`: `dbg_capture=1` in `settings.ini` and a line
`0 CAPTURE seq 8` in `sdmc:/3ds/racer/AUTOTEST.TXT` write `gfx_frame*.ppm` next to the
executable — plain RGB pixmaps, viewable as they are or converted with
`convert gfx_frame1.ppm gfx_frame1.png`.



## Testing in an emulator

Tested with [Panda3DS](https://github.com/wheremyfoodat/Panda3DS) (`.3dsx` loads directly;
a `.cia` needs installing into its NAND). Headless, on the CPU:

```sh
export SDL_VIDEODRIVER=x11 SDL_AUDIODRIVER=dummy
export LIBGL_ALWAYS_SOFTWARE=1 MESA_GL_VERSION_OVERRIDE=4.5
xvfb-run -a ./Alber /path/to/Racer3DS.3dsx
```

with `[GPU] Renderer="null"` in the config to skip GPU emulation (there is then no
picture — read the log, not the screen), and `[SD] UseVirtualSD=true` so the guest's
`sdmc:/` is the emulator's `Emulator Files/Racer3DS/SDMC/` directory: put `baserom.z64`
under `…/SDMC/3ds/racer/` there.

Several failures seen under Panda3DS are the *emulator's*, not the port's — it hard-panics
on FS and SVC calls it has not implemented. Hit by this port: `SDMC renameFile` (the save
and settings rotation), `svcInvalidate/Store/FlushProcessDataCache` (`0x52`–`0x54`),
`FSUSER_RenameDirectory` (`0x080A0244`), `svcExitProcess` at a clean exit, and `ndspInit`
(needs the DSP firmware). If a run dies, `arm-none-eabi-addr2line -f -C -e <build>/Racer3DS
<pc>` against the ELF resolves the guest PC: a `.3dsx` loads its Text at `0x00100000`,
which is where the ELF puts it, so the numbers match without arithmetic.
