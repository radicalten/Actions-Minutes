// Small value types shared by the renderer, its interpreter and the host
// tools (no runtime headers).
#ifndef RT64_3DS_TYPES_H
#define RT64_3DS_TYPES_H

#include <cstdint>

namespace rt64_3ds {

// The game's display-list encoding: F3DEX2 (DK64) or F3DEX 1.x, the GBI1
// family (Banjo-Kazooie). The RDP commands are the same in both.
enum class Gbi : uint8_t { F3DEX2, F3DEX };

// The RDRAM model's size (librecomp/addresses.hpp, RECOMP_MEM_SIZE_MB: 16 MB
// by default on the 3DS; a game with mods baked in above the 16 MB mark sets
// more, Dinosaur Planet 64): every RDRAM address the renderer takes from a
// display list or a tile load is masked to it. The host tools keep 16.
#ifndef RECOMP_MEM_SIZE_MB
#define RECOMP_MEM_SIZE_MB 16
#endif
constexpr uint32_t kRdramBytes = (uint32_t)RECOMP_MEM_SIZE_MB << 20;
// The mask that turns an N64 address into an offset: the power of two at or
// above the model (24 MB masked by 24 MB - 1 would clear bit 23 and alias
// everything above 8 MB onto the first 8 MB). A model that is not a power
// of two (80 MB: Dinosaur Planet with its mod) is bounded by kRdramBytes
// where a size is checked, and an address between the model and the mask's
// reach reads past the buffer, which no valid address does.
constexpr uint32_t rdram_pot(uint32_t v) { uint32_t p = 1u << 20; while (p < v) p <<= 1; return p; }
constexpr uint32_t kRdramMask = rdram_pot(kRdramBytes) - 1;

// The top screen: 400 px wide, 240 tall, and the game's picture is placed
// inside it (never stretched to fill it).
constexpr float kScreenWidth = 400.0f, kScreenHeight = 240.0f;

// Where the game's frame sits on the 400x240 top screen, as RT64 lays it out
// for any window: scaled uniformly to the screen's height, centred, and the
// margins beside it in the game's own units. DK64's 320x240 gives scale 1 and
// 40-pixel margins; Banjo's 292x216 scale 10/9 and 34-unit margins.
//
// That placement assumes what both those games do: a framebuffer whose
// pixels are square on the TV. A frame that the N64 stretches as it shows it
// (its framebuffer 512 wide for a picture 640 wide, say) needs the two axes
// scaled differently, or the picture is cropped at the sides and anything the
// game anchors to its edges lands off the screen - so `scale_x` is separate
// from `scale`, and equal to it for every game that uses make(). Nothing
// outside this struct needs to know which one it is: the screen mapping of a
// point goes through screen_x / screen_y, and the projection's x range
// through x0 and w, both of which follow from these two numbers.
struct ScreenGeometry {
    int w = 320, h = 240;          // the N64 frame, N64 pixels
    float scale = 1.0f;            // screen pixels per N64 pixel, vertically
    float scale_x = 1.0f;          // ... and horizontally
    float x0 = 40.0f;              // N64 units from the screen's left edge to N64 x = 0
    float wide_w = 400.0f;         // N64 units across the whole screen: w + 2 * x0
    static ScreenGeometry make(int w, int h) {
        ScreenGeometry g;
        g.w = w > 0 ? w : 320;
        g.h = h > 0 ? h : 240;
        g.scale = kScreenHeight / (float)g.h;
        g.scale_x = g.scale;
        g.wide_w = kScreenWidth / g.scale;
        g.x0 = (g.wide_w - (float)g.w) * 0.5f;
        return g;
    }
    // The same frame placed as its size on the TV: the picture keeps
    // `disp_aspect` (its width over its height, 4:3 for the standard N64
    // modes) and is fitted into the screen, centred. For a 4:3 picture that
    // is 320x240 of the 400x240, so with a square-pixel 320x240 frame this
    // is exactly make()'s answer; a 512-wide frame displaying 4:3 gets
    // scale_x 0.625 against scale 1, which is what the TV does to it.
    // disp_aspect <= 0 (square pixels) is make() itself.
    static ScreenGeometry make_fit(int w, int h, float disp_aspect) {
        ScreenGeometry g = make(w, h);
        if (disp_aspect <= 0.0f) return g;
        float pw = kScreenHeight * disp_aspect, ph = kScreenHeight;
        if (pw > kScreenWidth) { pw = kScreenWidth; ph = kScreenWidth / disp_aspect; }
        g.scale = ph / (float)g.h;
        g.scale_x = pw / (float)g.w;
        g.wide_w = kScreenWidth / g.scale_x;
        g.x0 = (g.wide_w - (float)g.w) * 0.5f;
        return g;
    }
    float screen_x(float n64_x) const { return (n64_x + x0) * scale_x; }
    float screen_y(float n64_y) const { return n64_y * scale; }
};

}   // namespace rt64_3ds

#endif
