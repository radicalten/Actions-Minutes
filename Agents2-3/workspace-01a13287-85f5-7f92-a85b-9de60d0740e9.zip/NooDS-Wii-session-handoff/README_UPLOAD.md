# Upload-ready NooDS-Wii session handoff

Attach this folder or the sibling ZIP to the new chat alongside the GitHub repo URL. Read AGENTS.md first; it now includes step-by-step devkitPPC setup and test recipes.

`Actions-Minutes2/NooDS-Wii/` is a compact snapshot of the emulator project relative to the Git repository root. It contains full C++ sources and build/test scripts, the two small test ROMs, the browser-enabled jit.dol, interpreter and autoboot-enabled block-JIT regression DOLs, project notes, and ~1.3 MiB of selected validation records. It intentionally excludes Git internals, build objects/caches, ELF/map files, SD images, framebuffer/memory dumps, and redundant Dolphin logs. These can be rebuilt/regenerated. The repo URL, not this folder, remains the source of version history.

Important: the last user report says the KEYINPUT build did not improve observed FPS despite a controlled Dolphin test improvement. Do not represent that test as a hardware or game-wide speedup.
