/*
    Copyright (C) 2026 radicalten

    This file is part of NooDS-Wii.

    NooDS-Wii is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NooDS-Wii is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NooDS-Wii. If not, see <https://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gccore.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <malloc.h>
#include <time.h>
#include <stdarg.h>
#include <new>
#include <asndlib.h>
#include <dirent.h>
#include <sys/types.h>
#include <vector>
#include <string>
#include <algorithm>

#include "wii_video.h"
#include "wii_audio.h"
#include "core.h"
#include "settings.h"
#include "console_ui.h"

// Browser build: ignore test-harness autoboot files and ROM fallbacks on SD.
// Regular regression builds leave this off so G2/G3 continue to auto-run.
#ifndef NOODS_FORCE_BROWSER
#define NOODS_FORCE_BROWSER 0
#endif

extern "C" {
    #include <tuxedo/thread.h>
    #include <tuxedo/ppc/intrinsics.h>
    #include <tuxedo/ppc/clock.h>
}

#define EMULATION_STACK_SIZE (256 * 1024)
#define AUDIO_STACK_SIZE     (64  * 1024)

static u8* mem2_free_ptr  = nullptr;
static u8* mem2_max_limit = nullptr;

static KThread  emulatorThread;
static KThread  audioThread;
static u8*      emulatorThreadStack = nullptr;
static u8*      audioThreadStack    = nullptr;

static KThread* g_emulatorThreadHandle = nullptr;

void InitializeMem2Arena() {
    u8* lo = (u8*)SYS_GetArena2Lo();
    u8* hi = (u8*)SYS_GetArena2Hi();
    mem2_free_ptr  = (u8*)(((uptr)lo + 31) & ~31u);
    mem2_max_limit = (u8*)((uptr)hi  & ~31u);
}

void* Noods_MEM2_Alloc(size_t size) {
    if (size == 0) return nullptr;
    size = (size + 31) & ~31u;
    if (!mem2_free_ptr || (mem2_free_ptr + size > mem2_max_limit))
        return nullptr;
    void* p       = (void*)mem2_free_ptr;
    mem2_free_ptr += size;
    return p;
}

void Noods_MEM2_Free(void* /*ptr*/) {}

static inline bool IsMem2Ptr(void* p) {
    return (u8*)p >= (u8*)0x90000000 &&
           (u8*)p <  (u8*)0x93400000;
}

static void* GlobalAlloc(size_t size) {
    void* p = nullptr;
    if (g_emulatorThreadHandle &&
        KThreadGetSelf() == g_emulatorThreadHandle && size >= 4096) {
        PPCIrqState st = PPCIrqLockByMsr();
        p = Noods_MEM2_Alloc(size);
        PPCIrqUnlockByMsr(st);
    }
    if (!p) p = malloc(size);
    return p;
}

void* operator new(size_t size) {
    void* p = GlobalAlloc(size);
    if (!p) throw std::bad_alloc();
    return p;
}
void* operator new[](size_t size) {
    void* p = GlobalAlloc(size);
    if (!p) throw std::bad_alloc();
    return p;
}
void operator delete(void* p) noexcept {
    if (!p) return;
    if (!IsMem2Ptr(p)) free(p);
}
void operator delete[](void* p) noexcept {
    if (!p) return;
    if (!IsMem2Ptr(p)) free(p);
}
void operator delete(void* p, size_t) noexcept {
    if (!p) return;
    if (!IsMem2Ptr(p)) free(p);
}
void operator delete[](void* p, size_t) noexcept {
    if (!p) return;
    if (!IsMem2Ptr(p)) free(p);
}

static Core*     ndsCore   = nullptr;
static bool      romLoaded = false;

static uint32_t* frontBuffer = nullptr;
static uint32_t* backBuffer  = nullptr;

static volatile bool newFrameReady     = false;
static volatile bool runEmulatorThread = true;
static volatile bool runAudioThread    = true;

static uint32_t* topScreenBuffer    = nullptr;
static uint32_t* bottomScreenBuffer = nullptr;

float g_cursorX    = 320.0f;
float g_cursorY    = 240.0f;
bool  g_cursorShow = false;

struct BrowserItem {
    std::string name;
    bool isDirectory;
};

static std::string currentDir = NOODS_FORCE_BROWSER ? "sd:/" : "sd:/noods/";
static std::vector<BrowserItem> dirContents;
static int selectedItemIndex = 0;
static int displayOffset     = 0;
static bool showFileBrowser  = true;
static std::string romToLoadPath = "";
static volatile bool triggerRomLoad = false;

static int scrollHoldTimer = 0;
static const int SCROLL_DELAY_INITIAL  = 18;
static const int SCROLL_DELAY_REPEATED = 3;

// ---------------------------------------------------------------------------
// Settings menu state
// ---------------------------------------------------------------------------
static bool showSettingsMenu      = false;
static volatile bool frameskipUserSet = false;
static int  settingsMenuIndex     = 0;
static int  settingsDisplayOffset = 0;

struct SettingsEntry {
    const char* label;
    int*        value;
    int         maxValue;
    const char* const* names;
    int         nameCount;
};

static const char* const s_toggleNames[]    = { "Off", "On" };
static const char* const s_frameskipNames[] = { "None", "1", "2", "3", "4", "5" };

static const SettingsEntry s_settingsTable[] = {
    { "Direct Boot",     &Settings::directBoot,   2, s_toggleNames,    2 },
    { "Skip Frames",     &Settings::frameskip,    6, s_frameskipNames, 6 },
    { "FPS Limiter",     &Settings::fpsLimiter,   2, s_toggleNames,    2 },
    { "Audio Emulation", &Settings::emulateAudio, 2, s_toggleNames,    2 },
    { "16-bit Output",   &Settings::audio16Bit,   2, s_toggleNames,    2 },
    { "Mono Audio",      &Settings::monoAudio,    2, s_toggleNames,    2 },
};

static const int s_settingsCount =
    (int)(sizeof(s_settingsTable) / sizeof(s_settingsTable[0]));

static const int SETTINGS_VISIBLE = 5;

static std::string SettingsEntryValue(const SettingsEntry& e) {
    if (!e.value) return "";
    int v = *e.value;
    if (e.names && v >= 0 && v < e.nameCount)
        return e.names[v];
    return std::to_string(v);
}

static int NextSelectableSettings(int start, int dir) {
    int idx = start + dir;
    if (idx < 0)                idx = s_settingsCount - 1;
    if (idx >= s_settingsCount) idx = 0;
    return idx;
}

static void ClampSettingsScroll() {
    if (settingsMenuIndex < settingsDisplayOffset)
        settingsDisplayOffset = settingsMenuIndex;
    if (settingsMenuIndex >= settingsDisplayOffset + SETTINGS_VISIBLE)
        settingsDisplayOffset = settingsMenuIndex - SETTINGS_VISIBLE + 1;
}

static void OpenSettingsMenu() {
    showSettingsMenu      = true;
    settingsMenuIndex     = 0;
    settingsDisplayOffset = 0;
}

static void ActivateSettingsEntry(int idx) {
    const SettingsEntry& e = s_settingsTable[idx];
    if (!e.value) return;
    *e.value = (*e.value + 1) % e.maxValue;
    if (e.value == &Settings::frameskip) frameskipUserSet = true;
}

#define NDS_KEY_A      0
#define NDS_KEY_B      1
#define NDS_KEY_SELECT 2
#define NDS_KEY_START  3
#define NDS_KEY_RIGHT  4
#define NDS_KEY_LEFT   5
#define NDS_KEY_UP     6
#define NDS_KEY_DOWN   7
#define NDS_KEY_R      8
#define NDS_KEY_L      9
#define NDS_KEY_X      10
#define NDS_KEY_Y      11

static volatile uint16_t g_ndsButtons  = 0;
static volatile bool     g_ndsTouching = false;
static volatile int16_t  g_ndsTouchX   = 0;
static volatile int16_t  g_ndsTouchY   = 0;

struct PerformanceState {
    uint32_t renderFrameCount;
    float    fps;
    time_t   startTime;
};
static PerformanceState perf = {};

// Presentation-side timing for the test harness (not guest CPU emulation time).
static uint64_t videoRenderTicks = 0, videoFlushTicks = 0, videoVsyncTicks = 0;
static uint32_t videoLoopCount = 0;
static uint32_t framesProduced = 0, framesOverwritten = 0;

#define AUDIO_SPU_FRAMES  WIIAUD_NDS_FRAMES

alignas(32) static uint32_t s_spuStaging[AUDIO_SPU_FRAMES];
alignas(32) static int16_t s_audioDbl[2][WIIAUD_FRAMES_PER_BUF * 2];
alignas(32) static int16_t s_audioSilence[WIIAUD_FRAMES_PER_BUF * 2];

static volatile int  s_writeBuf = 0;
static volatile int  s_readBuf  = 1;
static volatile bool s_bufReady = false;

static void ResampleLinear(const uint32_t* src, int nSrc,
                            int16_t*        dst, int nDst,
                            bool            mono)
{
    const int32_t step = (int32_t)(((int64_t)nSrc << 16) / nDst);
    int32_t       pos  = 0;

    for (int i = 0; i < nDst; i++) {
        const int idx0 = pos >> 16;
        const int idx1 = (idx0 + 1 < nSrc) ? idx0 + 1 : nSrc - 1;
        const int32_t frac = pos & 0xFFFF;

        const int16_t l0 = (int16_t)( src[idx0]        & 0xFFFF);
        const int16_t r0 = (int16_t)((src[idx0] >> 16) & 0xFFFF);
        const int16_t l1 = (int16_t)( src[idx1]        & 0xFFFF);
        const int16_t r1 = (int16_t)((src[idx1] >> 16) & 0xFFFF);

        const int16_t outL = (int16_t)(l0 + (int32_t)(l1 - l0) * frac / 65536);
        const int16_t outR = (int16_t)(r0 + (int32_t)(r1 - r0) * frac / 65536);

        if (mono) {
            const int16_t m = (int16_t)(((int32_t)outL + (int32_t)outR) >> 1);
            dst[i * 2 + 0] = m;
            dst[i * 2 + 1] = m;
        } else {
            dst[i * 2 + 0] = outL;
            dst[i * 2 + 1] = outR;
        }
        pos += step;
    }
}

static void AudioCallback(s32 voice)
{
    if (s_bufReady) {
        const int justFilled = s_writeBuf;
        s_readBuf  = justFilled;
        s_writeBuf = justFilled ^ 1;
        s_bufReady = false;
        ASND_AddVoice(voice, s_audioDbl[justFilled], WIIAUD_BUF_BYTES_STEREO);
    } else {
        ASND_AddVoice(voice, s_audioSilence, WIIAUD_BUF_BYTES_STEREO);
    }
}

static sptr AudioThreadMain(void* /*arg*/)
{
    while (runAudioThread) {
        while (s_bufReady && runAudioThread)
            KThreadYield();
        if (!runAudioThread) break;

        int16_t*   dst  = s_audioDbl[s_writeBuf];
        bool       ok   = false;
        const bool mono = (Settings::monoAudio != 0);

        if (romLoaded && ndsCore) {
            bool got = ndsCore->spu.getSamples(s_spuStaging, AUDIO_SPU_FRAMES);
            if (got || true) {
                ResampleLinear(s_spuStaging, AUDIO_SPU_FRAMES,
                               dst, WIIAUD_FRAMES_PER_BUF, mono);
                ok = true;
            }
        }

        if (!ok)
            memset(dst, 0, WIIAUD_BUF_BYTES_STEREO);

        DCFlushRange(dst, WIIAUD_BUF_BYTES_STEREO);
        s_bufReady = true;
    }

    KThreadExit(0);
    return 0;
}

static void InitializeAudio()
{
    memset(s_audioDbl,     0, sizeof(s_audioDbl));
    memset(s_audioSilence, 0, sizeof(s_audioSilence));
    DCFlushRange(s_audioDbl,     sizeof(s_audioDbl));
    DCFlushRange(s_audioSilence, sizeof(s_audioSilence));

    s_writeBuf = 0;
    s_readBuf  = 1;
    s_bufReady = false;

    ASND_Init();
    ASND_Pause(0);

    ASND_SetVoice(0,
                  VOICE_STEREO_16BIT_BE,
                  WIIAUD_OUT_RATE,
                  0,
                  s_audioSilence,
                  WIIAUD_BUF_BYTES_STEREO,
                  MAX_VOLUME,
                  MAX_VOLUME,
                  AudioCallback);
}

static void ShutdownAudio()
{
    runAudioThread = false;
    s_bufReady     = false;
    ASND_StopVoice(0);
    ASND_End();
    KThreadJoin(&audioThread);
}

static void InitializeSettings() {
    Settings::directBoot   = 1;
    Settings::bios9Path    = "sd:/noods/bios/bios9.bin";
    Settings::bios7Path    = "sd:/noods/bios/bios7.bin";
    Settings::firmwarePath = "sd:/noods/bios/firmware.bin";
    Settings::gbaBiosPath  = "sd:/noods/bios/gba_bios.bin";
    Settings::sdImagePath  = "";
    Settings::basePath     = "sd:/";
    Settings::fpsLimiter   = 1;
    Settings::frameskip    = 2; // DS default; GBA defaults to no skipping when loaded.
    Settings::threaded2D   = 0;
    Settings::threaded3D   = 0;
    Settings::highRes3D    = 0;
    Settings::screenGhost  = 0;
    Settings::emulateAudio = 1;
    Settings::audio16Bit   = 1;
    Settings::monoAudio    = 0;
    Settings::savesFolder  = 1;
    Settings::statesFolder = 1;
    Settings::cheatsFolder = 1;
    Settings::screenFilter = 0;
    Settings::arm7Hle      = 0;
    Settings::dsiMode      = 0;
}

static bool CompareBrowserItems(const BrowserItem& a, const BrowserItem& b) {
    if (a.isDirectory && !b.isDirectory) return true;
    if (!a.isDirectory && b.isDirectory) return false;
    return strcasecmp(a.name.c_str(), b.name.c_str()) < 0;
}

static void UpdateFileBrowser(const std::string& path) {
    dirContents.clear();
    selectedItemIndex = 0;
    displayOffset     = 0;

    DIR* dir = opendir(path.c_str());
    if (!dir) return;

    if (path != "sd:/" && path != "sd:") {
        BrowserItem parent;
        parent.name        = "..";
        parent.isDirectory = true;
        dirContents.push_back(parent);
    }

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;

        BrowserItem item;
        item.name        = entry->d_name;
        item.isDirectory = (entry->d_type == DT_DIR);

        if (!item.isDirectory) {
            size_t extPos = item.name.find_last_of('.');
            if (extPos == std::string::npos) continue;
            std::string ext = item.name.substr(extPos);
            std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
            if (ext != ".nds" && ext != ".gba") continue;
        }

        dirContents.push_back(item);
    }
    closedir(dir);

    size_t sortStart = (path != "sd:/" && path != "sd:") ? 1 : 0;
    std::sort(dirContents.begin() + sortStart, dirContents.end(),
              CompareBrowserItems);
}

alignas(32) static uint32_t tempBuffer[NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT * 2];

#if NOODS_JIT
#include "arm_jit.h"
#endif

struct NoodsTestHarness {
    static uint32_t maxFrames;
    static std::vector<uint32_t> checkpoints;
    static uint32_t poolLimitWords;
#if NOODS_G2_SCRIPTED_INPUT
    // Explicit test-build-only input windows; never compiled into the browser DOL.
    static uint32_t inputAFrom, inputATo, inputA2From, inputA2To;
#endif
    static uint32_t currentFrame;
    static uint64_t startTick;
    static uint64_t accumFrameUs;

    static uint64_t fnv1a64(const void* data, size_t len, uint64_t h = 14695981039346656037ULL) {
        const uint8_t* p = (const uint8_t*)data;
        for (size_t i = 0; i < len; i++) {
            h ^= (uint64_t)p[i];
            h *= 1099511628211ULL;
        }
        return h;
    }

    static std::string trimLine(const std::string& s) {
        size_t a = 0;
        while (a < s.size() && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r' || s[a] == '\n')) a++;
        size_t b = s.size();
        while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r' || s[b - 1] == '\n')) b--;
        return s.substr(a, b - a);
    }

    static bool fileExists(const char* path) {
        if (FILE* f = fopen(path, "rb")) {
            fclose(f);
            return true;
        }
        return false;
    }

    static void tryAutoboot() {
        maxFrames = 0;
        checkpoints.clear();
        poolLimitWords = 0;
#if NOODS_G2_SCRIPTED_INPUT
        inputAFrom = inputATo = inputA2From = inputA2To = 0;
#endif
        currentFrame = 0;
        accumFrameUs = 0;

        std::string chosen;
        const char* abFiles[] = { "sd:/autoboot.txt", "sd:/noods/autoboot.txt" };
        for (const char* ab : abFiles) {
            if (FILE* f = fopen(ab, "rb")) {
                char lineBuf[256];
                bool firstLine = true;
                while (fgets(lineBuf, sizeof(lineBuf), f)) {
                    std::string line = trimLine(lineBuf);
                    if (line.empty() || line[0] == '#') continue;
                    if (firstLine && line.find('=') == std::string::npos) {
                        chosen = line;
                        firstLine = false;
                    } else if (line.rfind("MAX_FRAMES=", 0) == 0) {
                        maxFrames = (uint32_t)strtoul(line.c_str() + 11, nullptr, 10);
                    } else if (line.rfind("CHECKPOINTS=", 0) == 0) {
                        const char* p = line.c_str() + 12;
                        while (*p) {
                            char* endp = nullptr;
                            uint32_t v = (uint32_t)strtoul(p, &endp, 10);
                            if (endp == p) break;
                            if (v > 0) checkpoints.push_back(v);
                            p = (*endp == ',') ? (endp + 1) : endp;
                        }
                    } else if (line.rfind("POOL_LIMIT_WORDS=", 0) == 0) {
                        poolLimitWords = (uint32_t)strtoul(line.c_str() + 17, nullptr, 10);
#if NOODS_G2_SCRIPTED_INPUT
                    } else if (line.rfind("INPUT_A_FROM=", 0) == 0) {
                        inputAFrom = (uint32_t)strtoul(line.c_str() + 13, nullptr, 10);
                    } else if (line.rfind("INPUT_A_TO=", 0) == 0) {
                        inputATo = (uint32_t)strtoul(line.c_str() + 11, nullptr, 10);
                    } else if (line.rfind("INPUT_A2_FROM=", 0) == 0) {
                        inputA2From = (uint32_t)strtoul(line.c_str() + 14, nullptr, 10);
                    } else if (line.rfind("INPUT_A2_TO=", 0) == 0) {
                        inputA2To = (uint32_t)strtoul(line.c_str() + 12, nullptr, 10);
#endif
                    }
                }
                fclose(f);
                break;
            }
        }

        if (chosen.empty() || !fileExists(chosen.c_str())) {
            chosen.clear();
            const char* fallbacks[] = {
                "sd:/noods/suite.gba",
                "sd:/noods/gba/suite.gba",
                "sd:/gba/suite.gba",
                "sd:/suite.gba",
                "sd:/noods/suite-auto.gba",
                "sd:/nds/rockwrestler.nds",
                "sd:/noods/rockwrestler.nds",
                "sd:/rockwrestler.nds",
                "sd:/noods/nds/rockwrestler.nds"
            };
            for (const char* cand : fallbacks) {
                if (fileExists(cand)) {
                    chosen = cand;
                    break;
                }
            }
        }

        if (!chosen.empty()) {
            if (!checkpoints.empty() || maxFrames > 0) {
                if (FILE* f = fopen("sd:/g2_state.log", "wb")) fclose(f);
            }
#if NOODS_JIT
            if (poolLimitWords > 0) {
                ArmPpcJit::setPoolLimitWords(poolLimitWords);
            }
#endif
            PPCIrqState st = PPCIrqLockByMsr();
            romToLoadPath   = chosen;
            romLoaded       = false;
            triggerRomLoad  = true;
            showFileBrowser = false;
            PPCIrqUnlockByMsr(st);
            SYS_Report("[NOODS] AUTOBOOT path=%s maxFrames=%u poolLimitWords=%u\n",
                       chosen.c_str(), maxFrames, poolLimitWords);
        }
    }

    static bool isCheckpoint(uint32_t frame) {
        if (maxFrames > 0 && frame == maxFrames) return true;
        for (uint32_t c : checkpoints) {
            if (c == frame) return true;
        }
        return false;
    }

    static void dumpCpuLine(FILE* f, const char* label, Interpreter& cpu) {
        uint32_t spsrVal = cpu.spsr ? *cpu.spsr : 0;
        fprintf(f, "%s cpsr=%08X spsr=%08X pc=%08X pipe0=%08X pipe1=%08X halted=%u ime=%u ie=%08X irf=%08X postFlg=%u cycles=%u",
                label, cpu.cpsr, spsrVal, *cpu.registers[15], cpu.pipeline[0], cpu.pipeline[1],
                (unsigned)cpu.halted, (unsigned)cpu.ime, cpu.ie, cpu.irf, (unsigned)cpu.postFlg, cpu.cycles);
        for (int r = 0; r < 16; r++) {
            fprintf(f, " r%d=%08X", r, cpu.registers[r] ? *cpu.registers[r] : cpu.registersUsr[r]);
        }
        for (int r = 0; r < 16; r++) {
            fprintf(f, " usr%d=%08X", r, cpu.registersUsr[r]);
        }
        fprintf(f, " svc13=%08X svc14=%08X irq13=%08X irq14=%08X fiq13=%08X fiq14=%08X\n",
                cpu.registersSvc[0], cpu.registersSvc[1],
                cpu.registersIrq[0], cpu.registersIrq[1],
                cpu.registersFiq[5], cpu.registersFiq[6]);
    }

    static void onFrameEnd(Core* core, uint64_t frameTicks) {
        currentFrame++;
        if (currentFrame == 1) startTick = PPCGetTickCount();
        uint64_t frameUs = PPCTicksToUs(frameTicks);
        accumFrameUs += frameUs;

        if (!isCheckpoint(currentFrame))
            return;

        Memory& mem = core->memory;
        size_t ramLen = core->gbaMode ? 0x40000 : 0x400000;
        uint64_t hRam   = fnv1a64(mem.ram, ramLen);
        uint64_t hWram  = fnv1a64(mem.wram, sizeof(mem.wram));
        uint64_t hItcm  = fnv1a64(mem.instrTcm, sizeof(mem.instrTcm));
        uint64_t hDtcm  = fnv1a64(mem.dataTcm, sizeof(mem.dataTcm));
        uint64_t hWram7 = fnv1a64(mem.wram7, sizeof(mem.wram7));
        uint64_t hPal   = fnv1a64(mem.palette, sizeof(mem.palette));
        uint64_t hOam   = fnv1a64(mem.oam, sizeof(mem.oam));
        uint64_t hVram  = fnv1a64(mem.vramA, sizeof(mem.vramA));
        hVram = fnv1a64(mem.vramB, sizeof(mem.vramB), hVram);
        hVram = fnv1a64(mem.vramC, sizeof(mem.vramC), hVram);
        hVram = fnv1a64(mem.vramD, sizeof(mem.vramD), hVram);
        hVram = fnv1a64(mem.vramE, sizeof(mem.vramE), hVram);
        hVram = fnv1a64(mem.vramF, sizeof(mem.vramF), hVram);
        hVram = fnv1a64(mem.vramG, sizeof(mem.vramG), hVram);
        hVram = fnv1a64(mem.vramH, sizeof(mem.vramH), hVram);
        hVram = fnv1a64(mem.vramI, sizeof(mem.vramI), hVram);

        uint64_t hTotalMem = hRam ^ (hWram << 1) ^ (hItcm << 2) ^ (hDtcm << 3) ^
                             (hWram7 << 4) ^ (hPal << 5) ^ (hOam << 6) ^ (hVram << 7);

        size_t scrPixels = NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT;
        uint64_t hFbTop  = fnv1a64(tempBuffer, scrPixels * sizeof(uint32_t));
        uint64_t hFbBot  = fnv1a64(tempBuffer + scrPixels, scrPixels * sizeof(uint32_t));
        uint64_t hFbAll  = fnv1a64(tempBuffer, scrPixels * 2 * sizeof(uint32_t));

        if (FILE* f = fopen("sd:/g2_state.log", "ab")) {
            fprintf(f, "=== CHECKPOINT FRAME %u ===\n", currentFrame);
            fprintf(f, "CYCLES global=%u arm9=%u arm7=%u gbaMode=%d\n",
                    core->globalCycles, core->interpreter[0].cycles, core->interpreter[1].cycles, (int)core->gbaMode);
            dumpCpuLine(f, "ARM9", core->interpreter[0]);
            dumpCpuLine(f, "ARM7", core->interpreter[1]);
            fprintf(f, "MEM_HASH ram=%016llX wram=%016llX itcm=%016llX dtcm=%016llX wram7=%016llX pal=%016llX vram=%016llX oam=%016llX total=%016llX\n",
                    (unsigned long long)hRam, (unsigned long long)hWram,
                    (unsigned long long)hItcm, (unsigned long long)hDtcm,
                    (unsigned long long)hWram7, (unsigned long long)hPal,
                    (unsigned long long)hVram, (unsigned long long)hOam,
                    (unsigned long long)hTotalMem);
            fprintf(f, "FB_HASH top=%016llX bottom=%016llX combined=%016llX\n",
                    (unsigned long long)hFbTop, (unsigned long long)hFbBot, (unsigned long long)hFbAll);
            fprintf(f, "PERF frame=%u accum_us=%llu avg_frame_us=%llu\n",
                    currentFrame, (unsigned long long)accumFrameUs,
                    (unsigned long long)(accumFrameUs / currentFrame));
            // Rendered FPS and emulated FPS are different when frameskip is nonzero.
            // Sample the UI's rendered-frame counter separately from Core::fps.
            PPCIrqState frameLock = PPCIrqLockByMsr();
            uint32_t rendered = perf.renderFrameCount;
            PPCIrqUnlockByMsr(frameLock);
            fprintf(f, "DISPLAY frames=%u rendered=%u produced=%u overwritten=%u core_fps=%d skip=%d elapsed_us=%llu loops=%u render_us=%llu flush_us=%llu vsync_us=%llu\n",
                    currentFrame, rendered, framesProduced, framesOverwritten,
                    core->fps, Settings::frameskip,
                    (unsigned long long)PPCTicksToUs(PPCGetTickCount() - startTick),
                    videoLoopCount,
                    (unsigned long long)PPCTicksToUs(videoRenderTicks),
                    (unsigned long long)PPCTicksToUs(videoFlushTicks),
                    (unsigned long long)PPCTicksToUs(videoVsyncTicks));
#if NOODS_JIT
            ArmPpcJit::dumpStats(f);
#else
            fprintf(f, "JIT_STATS enabled=0\n");
#endif
#if NOODS_NDS_TASK_PROFILE
            if (!core->gbaMode) Interpreter::dumpNdsTaskProfile(f);
#endif
            fflush(f);
            fclose(f);
        }

        if (maxFrames > 0 && currentFrame == maxFrames) {
            mem.syncMgbaLogToSd(false);
            if (FILE* mf = fopen("sd:/mem_dump.bin", "wb")) {
                fwrite(mem.wram, 1, sizeof(mem.wram), mf);
                fwrite(mem.instrTcm, 1, sizeof(mem.instrTcm), mf);
                fwrite(mem.dataTcm, 1, sizeof(mem.dataTcm), mf);
                fwrite(mem.wram7, 1, sizeof(mem.wram7), mf);
                fwrite(mem.palette, 1, sizeof(mem.palette), mf);
                fwrite(mem.oam, 1, sizeof(mem.oam), mf);
                fwrite(mem.ram, 1, 0x40000, mf);
                fflush(mf);
                fclose(mf);
            }
            if (FILE* ff = fopen("sd:/fb_dump.bin", "wb")) {
                fwrite(tempBuffer, sizeof(uint32_t), scrPixels * 2, ff);
                fflush(ff);
                fclose(ff);
            }
            fatUnmount("sd");
            fatInitDefault();
        }

        SYS_Report("[NOODS] CHECKPOINT frame=%u cyc=%u mem=%016llX fb=%016llX us=%llu\n",
                   currentFrame, core->globalCycles,
                   (unsigned long long)hTotalMem, (unsigned long long)hFbAll,
                   (unsigned long long)accumFrameUs);

        if (maxFrames > 0 && currentFrame >= maxFrames) {
            SYS_Report("[NOODS] MAX_FRAMES_DONE frame=%u\n", currentFrame);
            runEmulatorThread = false;
        }
    }
};

uint32_t NoodsTestHarness::maxFrames = 0;
std::vector<uint32_t> NoodsTestHarness::checkpoints;
uint32_t NoodsTestHarness::poolLimitWords = 0;
#if NOODS_G2_SCRIPTED_INPUT
uint32_t NoodsTestHarness::inputAFrom = 0, NoodsTestHarness::inputATo = 0;
uint32_t NoodsTestHarness::inputA2From = 0, NoodsTestHarness::inputA2To = 0;
#endif
uint32_t NoodsTestHarness::currentFrame = 0;
uint64_t NoodsTestHarness::startTick = 0;
uint64_t NoodsTestHarness::accumFrameUs = 0;

static sptr EmulatorThreadMain(void* /*arg*/) {
    const size_t pixelCount = NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT * 2;

    while (runEmulatorThread) {
        if (triggerRomLoad) {
            std::string loadPath;
            {
                PPCIrqState st = PPCIrqLockByMsr();
                loadPath       = romToLoadPath;
                triggerRomLoad = false;
                romLoaded      = false;
                PPCIrqUnlockByMsr(st);
            }

            delete ndsCore;
            ndsCore = nullptr;

            std::string ndsRom, gbaRom;
            size_t extPos = loadPath.find_last_of('.');
            if (extPos != std::string::npos) {
                std::string ext = loadPath.substr(extPos);
                std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                if (ext == ".gba") gbaRom = loadPath;
                else               ndsRom = loadPath;
            }

            // Default to a displayed frame per emulated GBA frame; preserve
            // the player's explicit frameskip choice and the DS default.
            if (!frameskipUserSet) Settings::frameskip = gbaRom.empty() ? 2 : 0;

            try {
                ndsCore   = new Core(ndsRom, gbaRom);
                romLoaded = true;
            }
            catch (...) {
                ndsCore = nullptr;
            }
        }

        if (romLoaded && ndsCore) {
            {
                PPCIrqState st  = PPCIrqLockByMsr();
                uint16_t buttons  = g_ndsButtons;
                bool     touching = g_ndsTouching;
                int16_t  touchX   = g_ndsTouchX;
                int16_t  touchY   = g_ndsTouchY;
                PPCIrqUnlockByMsr(st);

#if NOODS_G2_SCRIPTED_INPUT
                uint32_t f = NoodsTestHarness::currentFrame;
                if ((NoodsTestHarness::inputAFrom && f >= NoodsTestHarness::inputAFrom && f < NoodsTestHarness::inputATo) ||
                    (NoodsTestHarness::inputA2From && f >= NoodsTestHarness::inputA2From && f < NoodsTestHarness::inputA2To))
                    buttons |= (1u << NDS_KEY_A);
#endif

                for (int bit = 0; bit < 12; bit++) {
                    if (buttons & (1 << bit)) ndsCore->input.pressKey(bit);
                    else                      ndsCore->input.releaseKey(bit);
                }
                if (touching) {
                    ndsCore->spi.setTouch((int)touchX, (int)touchY);
                    ndsCore->input.pressScreen();
                } else {
                    ndsCore->spi.clearTouch();
                    ndsCore->input.releaseScreen();
                }
            }

            uint64_t t0 = PPCGetTickCount();
            ndsCore->runCore();
            uint64_t t1 = PPCGetTickCount();

            if (ndsCore->gpu.getFrame(tempBuffer, ndsCore->gbaMode)) {
                PPCIrqState st = PPCIrqLockByMsr();
                framesProduced++;
                if (newFrameReady) framesOverwritten++;
                // GBA output is 240x160, not two 256x192 DS screens. Keep the
                // interrupt-disabled copy limited to the pixels actually displayed.
                size_t copyPixels = ndsCore->gbaMode ? (size_t)GBA_SCREEN_WIDTH * GBA_SCREEN_HEIGHT : pixelCount;
                memcpy(backBuffer, tempBuffer, copyPixels * sizeof(uint32_t));
                newFrameReady = true;
                PPCIrqUnlockByMsr(st);
            }

            NoodsTestHarness::onFrameEnd(ndsCore, t1 - t0);
        }
        else {
            KThreadSleepMs(16);
        }
    }

    KThreadExit(0);
    return 0;
}

static void InitializeNDS() {
    const size_t bufSize =
        NDS_SCREEN_WIDTH * (NDS_SCREEN_HEIGHT * 2) * sizeof(uint32_t);

    frontBuffer = (uint32_t*)Noods_MEM2_Alloc(bufSize);
    if (!frontBuffer) frontBuffer = (uint32_t*)malloc(bufSize);

    backBuffer  = (uint32_t*)Noods_MEM2_Alloc(bufSize);
    if (!backBuffer) backBuffer = (uint32_t*)malloc(bufSize);

    if (!frontBuffer || !backBuffer) {
        while (true) KThreadSleepMs(16);
    }
    memset(frontBuffer, 0, bufSize);
    memset(backBuffer,  0, bufSize);

    InitializeSettings();

    if (fatInitDefault()) {
        UpdateFileBrowser(currentDir);
#if NOODS_FORCE_BROWSER
        SYS_Report("[NOODS] FILE_BROWSER active dir=%s\n", currentDir.c_str());
#else
        NoodsTestHarness::tryAutoboot();
#endif
    }

    const size_t sz = NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT * sizeof(uint32_t);
    topScreenBuffer    = (uint32_t*)Noods_MEM2_Alloc(sz);
    if (!topScreenBuffer) topScreenBuffer = (uint32_t*)malloc(sz);

    bottomScreenBuffer = (uint32_t*)Noods_MEM2_Alloc(sz);
    if (!bottomScreenBuffer) bottomScreenBuffer = (uint32_t*)malloc(sz);

    if (topScreenBuffer && bottomScreenBuffer) {
        for (int i = 0; i < NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT; i++) {
            topScreenBuffer[i]    = 0xFF0000FF;
            bottomScreenBuffer[i] = 0x0000FFFF;
        }
    }

    emulatorThreadStack = (u8*)Noods_MEM2_Alloc(EMULATION_STACK_SIZE);
    if (!emulatorThreadStack) emulatorThreadStack = (u8*)malloc(EMULATION_STACK_SIZE);

    if (Settings::emulateAudio) {
        audioThreadStack = (u8*)Noods_MEM2_Alloc(AUDIO_STACK_SIZE);
        if (!audioThreadStack) audioThreadStack = (u8*)malloc(AUDIO_STACK_SIZE);
    }

    if (!emulatorThreadStack || (Settings::emulateAudio && !audioThreadStack)) {
        while (true) KThreadSleepMs(16);
    }

    KThreadPrepare(&emulatorThread, EmulatorThreadMain, nullptr,
                   emulatorThreadStack + EMULATION_STACK_SIZE, 0x50);
    g_emulatorThreadHandle = &emulatorThread;
    KThreadResume(&emulatorThread);

    if (Settings::emulateAudio) {
        KThreadPrepare(&audioThread, AudioThreadMain, nullptr,
                       audioThreadStack + AUDIO_STACK_SIZE, 0x51);
        KThreadResume(&audioThread);
        InitializeAudio();
    }

    perf.startTime = time(nullptr);
}

static uint16_t WiiButtonsToNDS(u32 held, u32 heldExt, bool hasNunchuk, bool hasClassic) {
    uint16_t nds = 0;

    if (held & WPAD_BUTTON_RIGHT)  nds |= (1 << NDS_KEY_RIGHT);
    if (held & WPAD_BUTTON_LEFT)   nds |= (1 << NDS_KEY_LEFT);
    if (held & WPAD_BUTTON_UP)     nds |= (1 << NDS_KEY_UP);
    if (held & WPAD_BUTTON_DOWN)   nds |= (1 << NDS_KEY_DOWN);
    if (held & WPAD_BUTTON_2)      nds |= (1 << NDS_KEY_A);
    if (held & WPAD_BUTTON_1)      nds |= (1 << NDS_KEY_B);
    if (held & WPAD_BUTTON_A)      nds |= (1 << NDS_KEY_X);
    if (held & WPAD_BUTTON_B)      nds |= (1 << NDS_KEY_Y);
    if (held & WPAD_BUTTON_PLUS)   nds |= (1 << NDS_KEY_START);
    if (held & WPAD_BUTTON_MINUS)  nds |= (1 << NDS_KEY_SELECT);

    if (hasNunchuk) {
        if (heldExt & WPAD_NUNCHUK_BUTTON_Z) nds |= (1 << NDS_KEY_L);
        if (heldExt & WPAD_NUNCHUK_BUTTON_C) nds |= (1 << NDS_KEY_R);
    }

    if (hasClassic) {
        if (held & WPAD_CLASSIC_BUTTON_RIGHT) nds |= (1 << NDS_KEY_RIGHT);
        if (held & WPAD_CLASSIC_BUTTON_LEFT)  nds |= (1 << NDS_KEY_LEFT);
        if (held & WPAD_CLASSIC_BUTTON_UP)    nds |= (1 << NDS_KEY_UP);
        if (held & WPAD_CLASSIC_BUTTON_DOWN)  nds |= (1 << NDS_KEY_DOWN);
        if (held & WPAD_CLASSIC_BUTTON_A)     nds |= (1 << NDS_KEY_A);
        if (held & WPAD_CLASSIC_BUTTON_B)     nds |= (1 << NDS_KEY_B);
        if (held & WPAD_CLASSIC_BUTTON_X)     nds |= (1 << NDS_KEY_X);
        if (held & WPAD_CLASSIC_BUTTON_Y)     nds |= (1 << NDS_KEY_Y);
        if (held & WPAD_CLASSIC_BUTTON_PLUS)  nds |= (1 << NDS_KEY_START);
        if (held & WPAD_CLASSIC_BUTTON_MINUS) nds |= (1 << NDS_KEY_SELECT);
        if (held & (WPAD_CLASSIC_BUTTON_FULL_L | WPAD_CLASSIC_BUTTON_ZL)) nds |= (1 << NDS_KEY_L);
        if (held & (WPAD_CLASSIC_BUTTON_FULL_R | WPAD_CLASSIC_BUTTON_ZR)) nds |= (1 << NDS_KEY_R);
    }

    return nds;
}

// ---------------------------------------------------------------------------
// Settings combo helper — shared between browser and in-game contexts.
// Returns true on the frame the combo is first completed (edge-triggered).
// Wii Remote / Classic: B + PLUS
// GameCube:             B + START
// ---------------------------------------------------------------------------
static bool CheckSettingsCombo(u32 pressed, u32 held,
                                u32 gcPressed, u32 gcHeld,
                                bool hasClassic)
{
    bool bHeld       = (held    & WPAD_BUTTON_B)
                     || (hasClassic && (held    & WPAD_CLASSIC_BUTTON_B));
    bool bDown       = (pressed & WPAD_BUTTON_B)
                     || (hasClassic && (pressed & WPAD_CLASSIC_BUTTON_B));
    bool plusHeld    = (held    & WPAD_BUTTON_PLUS)
                     || (hasClassic && (held    & WPAD_CLASSIC_BUTTON_PLUS));
    bool plusDown    = (pressed & WPAD_BUTTON_PLUS)
                     || (hasClassic && (pressed & WPAD_CLASSIC_BUTTON_PLUS));

    bool gcBHeld     = (gcHeld    & PAD_BUTTON_B);
    bool gcBDown     = (gcPressed & PAD_BUTTON_B);
    bool gcStartHeld = (gcHeld    & PAD_BUTTON_START);
    bool gcStartDown = (gcPressed & PAD_BUTTON_START);

    return (bDown && plusHeld) || (plusDown && bHeld) ||
           (gcBDown && gcStartHeld) || (gcStartDown && gcBHeld);
}

// ---------------------------------------------------------------------------
// HandleSettingsInput — drives the settings menu each frame it is open.
// ---------------------------------------------------------------------------
static int settingsScrollHoldTimer = 0;

static void HandleSettingsInput(u32 pressed, u32 held,
                                u32 gcPressed, u32 gcHeld,
                                WPADData* wdata, bool hasClassic)
{
    // Classic left-stick for scrolling.
    bool classicUp   = false;
    bool classicDown = false;
    if (hasClassic && wdata) {
        float ly = wdata->exp.classic.ljs.mag *
                   cosf(wdata->exp.classic.ljs.ang * 3.14159265f / 180.0f);
        if (wdata->exp.classic.ljs.mag > 0.5f) {
            if (ly >  0.5f) classicUp   = true;
            if (ly < -0.5f) classicDown = true;
        }
    }

    bool upPressed   = (pressed & WPAD_BUTTON_UP)
                     || (pressed & WPAD_CLASSIC_BUTTON_UP)
                     || (gcPressed & PAD_BUTTON_UP);
    bool downPressed = (pressed & WPAD_BUTTON_DOWN)
                     || (pressed & WPAD_CLASSIC_BUTTON_DOWN)
                     || (gcPressed & PAD_BUTTON_DOWN);
    bool upHeld      = (held & WPAD_BUTTON_UP)
                     || (held & WPAD_CLASSIC_BUTTON_UP)
                     || (gcHeld & PAD_BUTTON_UP)
                     || classicUp;
    bool downHeld    = (held & WPAD_BUTTON_DOWN)
                     || (held & WPAD_CLASSIC_BUTTON_DOWN)
                     || (gcHeld & PAD_BUTTON_DOWN)
                     || classicDown;

    bool doUp   = false;
    bool doDown = false;

    if (upPressed || downPressed) {
        settingsScrollHoldTimer = 0;
        if (upPressed)   doUp   = true;
        if (downPressed) doDown = true;
    } else if (upHeld || downHeld) {
        settingsScrollHoldTimer++;
        int elapsed = settingsScrollHoldTimer - SCROLL_DELAY_INITIAL;
        if (elapsed >= 0 && elapsed % SCROLL_DELAY_REPEATED == 0) {
            if (upHeld)   doUp   = true;
            if (downHeld) doDown = true;
        }
    } else {
        settingsScrollHoldTimer = 0;
    }

    if (doUp)
        settingsMenuIndex = NextSelectableSettings(settingsMenuIndex, -1);
    if (doDown)
        settingsMenuIndex = NextSelectableSettings(settingsMenuIndex, +1);

    ClampSettingsScroll();

    // Page up / down with Left / Right.
    bool pageUp   = (pressed & WPAD_BUTTON_LEFT)
                  || (pressed & WPAD_CLASSIC_BUTTON_LEFT)
                  || (gcPressed & PAD_BUTTON_LEFT);
    bool pageDown = (pressed & WPAD_BUTTON_RIGHT)
                  || (pressed & WPAD_CLASSIC_BUTTON_RIGHT)
                  || (gcPressed & PAD_BUTTON_RIGHT);

    if (pageUp) {
        for (int i = 0; i < SETTINGS_VISIBLE; i++)
            settingsMenuIndex = NextSelectableSettings(settingsMenuIndex, -1);
        ClampSettingsScroll();
    }
    if (pageDown) {
        for (int i = 0; i < SETTINGS_VISIBLE; i++)
            settingsMenuIndex = NextSelectableSettings(settingsMenuIndex, +1);
        ClampSettingsScroll();
    }

    // A or 2 to toggle the highlighted entry.
    bool activate = (pressed & WPAD_BUTTON_A)
                  || (pressed & WPAD_CLASSIC_BUTTON_A)
                  || (gcPressed & PAD_BUTTON_A)
                  || (pressed & WPAD_BUTTON_2);
    if (activate)
        ActivateSettingsEntry(settingsMenuIndex);

    // B / MINUS to save and close.
    bool close = (pressed & WPAD_BUTTON_B)
               || (pressed & WPAD_CLASSIC_BUTTON_B)
               || (gcPressed & PAD_BUTTON_B)
               || (pressed & WPAD_BUTTON_MINUS);
    if (close) {
        Settings::save();
        showSettingsMenu = false;
    }
}

// ---------------------------------------------------------------------------
// DrawSettingsOverlay
// Line 0   : title + hint
// Lines 1-5: up to SETTINGS_VISIBLE entries
// Line 6   : scroll indicator
// Line 7   : blank
// ---------------------------------------------------------------------------
static void DrawSettingsOverlay() {
    Wii_DebugOverlayPrint(0, "Settings   [A]=Toggle [B]=Save");

    int lineIdx = 1;
    for (int row = settingsDisplayOffset;
         row < s_settingsCount && lineIdx <= SETTINGS_VISIBLE;
         row++, lineIdx++)
    {
        const SettingsEntry& e = s_settingsTable[row];
        std::string val  = SettingsEntryValue(e);
        bool selected    = (row == settingsMenuIndex);
        Wii_DebugOverlayPrint(lineIdx, "%s%-18s %-10s",
            selected ? "->" : "  ",
            e.label,
            val.c_str());
    }

    while (lineIdx <= SETTINGS_VISIBLE)
        Wii_DebugOverlayPrint(lineIdx++, " ");

    Wii_DebugOverlayPrint(6,
        "%s row %d/%d %s",
        (settingsDisplayOffset > 0) ? "^^" : "  ",
        settingsMenuIndex + 1,
        s_settingsCount,
        (settingsDisplayOffset + SETTINGS_VISIBLE < s_settingsCount) ? "vv" : "  ");

    Wii_DebugOverlayPrint(7, " ");
}

static void ScanWiiInputs() {
    WPAD_ScanPads();
    PAD_ScanPads();

    u32 held      = WPAD_ButtonsHeld(0);
    u32 pressed   = WPAD_ButtonsDown(0);
    u32 gcHeld    = PAD_ButtonsHeld(0);
    u32 gcPressed = PAD_ButtonsDown(0);

    WPADData* wdata      = WPAD_Data(0);
    bool      hasNunchuk = wdata && (wdata->exp.type == WPAD_EXP_NUNCHUK);
    bool      hasClassic = wdata && (wdata->exp.type == WPAD_EXP_CLASSIC);
    u32       heldExt    = hasNunchuk ? held : 0;

    // HOME always quits.
    if ((pressed & WPAD_BUTTON_HOME) || (pressed & WPAD_CLASSIC_BUTTON_HOME)) {
        runEmulatorThread = false;
        PPCCompilerBarrier();
        KThreadJoin(&emulatorThread);
        ShutdownAudio();
        delete ndsCore;
        ndsCore = nullptr;
        exit(0);
    }

    // -----------------------------------------------------------------------
    // Settings menu — highest priority, blocks everything else.
    // -----------------------------------------------------------------------
    if (showSettingsMenu) {
        HandleSettingsInput(pressed, held, gcPressed, gcHeld, wdata, hasClassic);
        return;
    }

    // -----------------------------------------------------------------------
    // File browser
    // -----------------------------------------------------------------------
    if (showFileBrowser) {
        if (!dirContents.empty()) {
            static bool classicLStickUpLast   = false;
            static bool classicLStickDownLast = false;
            bool classicLStickUp   = false;
            bool classicLStickDown = false;

            if (hasClassic && wdata) {
                float ly = wdata->exp.classic.ljs.mag *
                           cosf(wdata->exp.classic.ljs.ang * 3.14159265f / 180.0f);
                if (wdata->exp.classic.ljs.mag > 0.5f) {
                    if (ly >  0.5f) classicLStickUp   = true;
                    if (ly < -0.5f) classicLStickDown = true;
                }
            }

            bool upHeld   = (held & WPAD_BUTTON_UP)
                          || (held & WPAD_CLASSIC_BUTTON_UP)
                          || (gcHeld & PAD_BUTTON_UP)
                          || classicLStickUp;
            bool downHeld = (held & WPAD_BUTTON_DOWN)
                          || (held & WPAD_CLASSIC_BUTTON_DOWN)
                          || (gcHeld & PAD_BUTTON_DOWN)
                          || classicLStickDown;
            bool upDown   = (pressed & WPAD_BUTTON_UP)
                          || (pressed & WPAD_CLASSIC_BUTTON_UP)
                          || (gcPressed & PAD_BUTTON_UP)
                          || (classicLStickUp && !classicLStickUpLast);
            bool downDown = (pressed & WPAD_BUTTON_DOWN)
                          || (pressed & WPAD_CLASSIC_BUTTON_DOWN)
                          || (gcPressed & PAD_BUTTON_DOWN)
                          || (classicLStickDown && !classicLStickDownLast);

            classicLStickUpLast   = classicLStickUp;
            classicLStickDownLast = classicLStickDown;

            bool performUp   = false;
            bool performDown = false;

            if (upDown || downDown) {
                scrollHoldTimer = 0;
                if (upDown)   performUp   = true;
                if (downDown) performDown = true;
            } else if (upHeld || downHeld) {
                scrollHoldTimer++;
                if (scrollHoldTimer >= SCROLL_DELAY_INITIAL) {
                    if ((scrollHoldTimer - SCROLL_DELAY_INITIAL) %
                        SCROLL_DELAY_REPEATED == 0) {
                        if (upHeld)   performUp   = true;
                        if (downHeld) performDown = true;
                    }
                }
            } else {
                scrollHoldTimer = 0;
            }

            if (performDown) {
                selectedItemIndex++;
                if (selectedItemIndex >= (int)dirContents.size()) {
                    selectedItemIndex = 0;
                    displayOffset     = 0;
                }
                if (selectedItemIndex >= displayOffset + 5)
                    displayOffset = selectedItemIndex - 4;
            }
            if (performUp) {
                selectedItemIndex--;
                if (selectedItemIndex < 0) {
                    selectedItemIndex = (int)dirContents.size() - 1;
                    displayOffset     = std::max(0, selectedItemIndex - 4);
                }
                if (selectedItemIndex < displayOffset)
                    displayOffset = selectedItemIndex;
            }

            if ((pressed & WPAD_BUTTON_LEFT)
             || (pressed & WPAD_CLASSIC_BUTTON_LEFT)
             || (gcPressed & PAD_BUTTON_LEFT)) {
                selectedItemIndex -= 5;
                if (selectedItemIndex < 0) selectedItemIndex = 0;
                displayOffset = std::max(0, selectedItemIndex - 2);
            }
            if ((pressed & WPAD_BUTTON_RIGHT)
             || (pressed & WPAD_CLASSIC_BUTTON_RIGHT)
             || (gcPressed & PAD_BUTTON_RIGHT)) {
                selectedItemIndex += 5;
                if (selectedItemIndex >= (int)dirContents.size())
                    selectedItemIndex = (int)dirContents.size() - 1;
                displayOffset = std::max(0,
                    std::min((int)dirContents.size() - 5,
                             selectedItemIndex - 2));
            }

            if ((pressed & WPAD_BUTTON_A)
             || (pressed & WPAD_CLASSIC_BUTTON_A)
             || (gcPressed & PAD_BUTTON_A)) {
                BrowserItem selected = dirContents[selectedItemIndex];
                if (selected.isDirectory) {
                    if (selected.name == "..") {
                        size_t slash = currentDir.find_last_of('/',
                            currentDir.length() - 2);
                        if (slash != std::string::npos)
                            currentDir = currentDir.substr(0, slash + 1);
                    } else {
                        currentDir += selected.name + "/";
                    }
                    UpdateFileBrowser(currentDir);
                } else {
                    std::string romPath = currentDir + selected.name;

                    PPCIrqState st = PPCIrqLockByMsr();
                    romToLoadPath  = romPath;
                    romLoaded      = false;
                    triggerRomLoad = true;
                    PPCIrqUnlockByMsr(st);

                    showFileBrowser = false;

                    dirContents.clear();
                    dirContents.shrink_to_fit();
                }
            }
        }

        // B: go up a directory, or close browser if a ROM is already loaded.
        if ((pressed & WPAD_BUTTON_B)
         || (pressed & WPAD_CLASSIC_BUTTON_B)
         || (gcPressed & PAD_BUTTON_B)) {
            if (currentDir != "sd:/" && currentDir != "sd://"
             && currentDir != "sd:") {
                size_t slash = currentDir.find_last_of('/',
                    currentDir.length() - 2);
                if (slash != std::string::npos) {
                    currentDir = currentDir.substr(0, slash + 1);
                    UpdateFileBrowser(currentDir);
                }
            } else if (romLoaded) {
                showFileBrowser = false;
            }
        }

        // B + PLUS / B + START: open settings from inside the browser.
        if (CheckSettingsCombo(pressed, held, gcPressed, gcHeld, hasClassic))
            OpenSettingsMenu();
    }
    // -----------------------------------------------------------------------
    // In-game (emulation running, browser closed)
    // -----------------------------------------------------------------------
    else {
        uint16_t ndsButtons = WiiButtonsToNDS(held, heldExt, hasNunchuk, hasClassic);

        if (gcHeld & PAD_BUTTON_A)     ndsButtons |= (1 << NDS_KEY_A);
        if (gcHeld & PAD_BUTTON_B)     ndsButtons |= (1 << NDS_KEY_B);
        if (gcHeld & PAD_BUTTON_X)     ndsButtons |= (1 << NDS_KEY_X);
        if (gcHeld & PAD_BUTTON_Y)     ndsButtons |= (1 << NDS_KEY_Y);
        if (gcHeld & PAD_BUTTON_LEFT)  ndsButtons |= (1 << NDS_KEY_LEFT);
        if (gcHeld & PAD_BUTTON_RIGHT) ndsButtons |= (1 << NDS_KEY_RIGHT);
        if (gcHeld & PAD_BUTTON_UP)    ndsButtons |= (1 << NDS_KEY_UP);
        if (gcHeld & PAD_BUTTON_DOWN)  ndsButtons |= (1 << NDS_KEY_DOWN);
        if (gcHeld & PAD_TRIGGER_R)    ndsButtons |= (1 << NDS_KEY_R);
        if (gcHeld & PAD_TRIGGER_L)    ndsButtons |= (1 << NDS_KEY_L);
        if (gcHeld & PAD_BUTTON_START) ndsButtons |= (1 << NDS_KEY_START);

        if (hasClassic && wdata) {
            float lx = wdata->exp.classic.ljs.mag *
                       sinf(wdata->exp.classic.ljs.ang * 3.14159265f / 180.0f);
            float ly = wdata->exp.classic.ljs.mag *
                       cosf(wdata->exp.classic.ljs.ang * 3.14159265f / 180.0f);
            if (wdata->exp.classic.ljs.mag > 0.5f) {
                if (lx >  0.5f) ndsButtons |= (1 << NDS_KEY_RIGHT);
                if (lx < -0.5f) ndsButtons |= (1 << NDS_KEY_LEFT);
                if (ly >  0.5f) ndsButtons |= (1 << NDS_KEY_UP);
                if (ly < -0.5f) ndsButtons |= (1 << NDS_KEY_DOWN);
            }
        }

        bool isTouching = false;
        g_cursorShow = false;

        if (wdata && wdata->ir.valid) {
            g_cursorX    = wdata->ir.x;
            g_cursorY    = wdata->ir.y;
            g_cursorShow = true;
            if (held & WPAD_BUTTON_A)
                isTouching = true;
        }

        s8 cstickX = PAD_SubStickX(0);
        s8 cstickY = PAD_SubStickY(0);
        if (abs(cstickX) > 15 || abs(cstickY) > 15) {
            g_cursorX   += (cstickX / 15.0f) * 2.5f;
            g_cursorY   -= (cstickY / 15.0f) * 2.5f;
            g_cursorShow = true;

            if (g_cursorX < 0.0f)   g_cursorX = 0.0f;
            if (g_cursorX > 640.0f) g_cursorX = 640.0f;
            if (g_cursorY < 0.0f)   g_cursorY = 0.0f;
            if (g_cursorY > 480.0f) g_cursorY = 480.0f;
        }

        if (hasClassic && wdata) {
            float rx = wdata->exp.classic.rjs.mag *
                       sinf(wdata->exp.classic.rjs.ang * 3.14159265f / 180.0f);
            float ry = wdata->exp.classic.rjs.mag *
                       cosf(wdata->exp.classic.rjs.ang * 3.14159265f / 180.0f);
            if (wdata->exp.classic.rjs.mag > 0.15f) {
                g_cursorX   += rx * 4.0f;
                g_cursorY   -= ry * 4.0f;
                g_cursorShow = true;

                if (g_cursorX < 0.0f)   g_cursorX = 0.0f;
                if (g_cursorX > 640.0f) g_cursorX = 640.0f;
                if (g_cursorY < 0.0f)   g_cursorY = 0.0f;
                if (g_cursorY > 480.0f) g_cursorY = 480.0f;
            }
        }

        if (gcHeld & PAD_TRIGGER_Z) {
            isTouching   = true;
            g_cursorShow = true;
        }

        if (hasClassic && (held & (WPAD_CLASSIC_BUTTON_ZL | WPAD_CLASSIC_BUTTON_ZR))) {
            isTouching   = true;
            g_cursorShow = true;
        }

        int16_t touchX = 0;
        int16_t touchY = 0;

        if (g_cursorShow) {
            const int gap    = 2;
            const int scrW   = NDS_SCREEN_WIDTH;
            const int scrH   = NDS_SCREEN_HEIGHT;
            const int totalW = scrW;
            const int totalH = scrH * 2 + gap;

            const float fbWidth   = 640.0f;
            const float efbHeight = 480.0f;

            const float originX = (fbWidth   - totalW) / 2.0f;
            const float originY = (efbHeight - totalH) / 2.0f;

            const float dsLeft   = originX;
            const float dsRight  = originX + scrW;
            const float dsTop    = originY + scrH + gap;
            const float dsBottom = originY + scrH + gap + scrH;

            if (g_cursorX >= dsLeft  && g_cursorX <= dsRight &&
                g_cursorY >= dsTop   && g_cursorY <= dsBottom) {
                touchX = (int16_t)(((g_cursorX - dsLeft) /
                                    (dsRight  - dsLeft)) * 256.0f);
                touchY = (int16_t)(((g_cursorY - dsTop)  /
                                    (dsBottom - dsTop))  * 192.0f);
            } else {
                isTouching = false;
            }
        }

        PPCIrqState st = PPCIrqLockByMsr();
        g_ndsButtons  = ndsButtons;
        g_ndsTouching = isTouching;
        g_ndsTouchX   = touchX;
        g_ndsTouchY   = touchY;
        PPCIrqUnlockByMsr(st);

        // B + PLUS / B + START: open settings while in-game.
        if (CheckSettingsCombo(pressed, held, gcPressed, gcHeld, hasClassic))
            OpenSettingsMenu();
    }
}

int main(int /*argc*/, char** /*argv*/) {
    Wii_VideoInit();
    InitializeMem2Arena();

    WPAD_Init();
    WPAD_SetDataFormat(WPAD_CHAN_0, WPAD_FMT_BTNS_ACC_IR);
    WPAD_SetVRes(WPAD_CHAN_0, 640, 480);

    InitializeNDS();

    while (true) {
        ScanWiiInputs();

        const uint32_t* renderTop    = nullptr;
        const uint32_t* renderBottom = nullptr;

        if (romLoaded && !showFileBrowser && !showSettingsMenu) {
            PPCIrqState st  = PPCIrqLockByMsr();
            bool haveFrame  = newFrameReady;
            if (haveFrame) {
                uint32_t* tmp = frontBuffer;
                frontBuffer   = backBuffer;
                backBuffer    = tmp;
                newFrameReady = false;
                perf.renderFrameCount++;
            }
            PPCIrqUnlockByMsr(st);

            renderTop = frontBuffer;
            if (ndsCore && ndsCore->gbaMode)
                renderBottom = bottomScreenBuffer;
            else
                renderBottom = frontBuffer + (NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT);
        }
        else {
            renderTop    = topScreenBuffer;
            renderBottom = bottomScreenBuffer;
        }

        static uint32_t lastSecFrames = 0;
        static time_t   lastSec       = 0;
        time_t now = time(nullptr);
        if (now != lastSec) {
            perf.fps      = (float)(perf.renderFrameCount - lastSecFrames);
            lastSecFrames = perf.renderFrameCount;
            lastSec       = now;
        }

        // -------------------------------------------------------------------
        // Overlay — settings menu takes all 8 lines when open.
        // -------------------------------------------------------------------
        if (showSettingsMenu) {
            DrawSettingsOverlay();
        }
        else if (showFileBrowser) {
            Wii_DebugOverlayPrint(0, "Dir: %s", currentDir.c_str());

            int lineIndex = 1;
            for (int i = displayOffset;
                 i < std::min((int)dirContents.size(), displayOffset + 5); i++) {
                const char* prefix = (i == selectedItemIndex) ? "-> " : "   ";
                const char* suffix = dirContents[i].isDirectory ? "/" : "";
                Wii_DebugOverlayPrint(lineIndex++, "%s%s%s",
                    prefix, dirContents[i].name.c_str(), suffix);
            }
            while (lineIndex < 6)
                Wii_DebugOverlayPrint(lineIndex++, " ");
            Wii_DebugOverlayPrint(6, "A=Load  B=Back  B++=Settings");
            Wii_DebugOverlayPrint(7, " ");
        }
        else {
            Wii_DebugOverlayPrint(0, " ");
            // Present FPS excludes frames skipped by the GPU; Core::fps counts
            // every emulated video frame. Show both to avoid conflating them.
            Wii_DebugOverlayPrint(1, "Display: %5.1f  Emu: %d FPS", perf.fps,
                                  ndsCore ? ndsCore->fps : 0);
            Wii_DebugOverlayPrint(2, "HOME=Quit  B++=Settings");
            Wii_DebugOverlayPrint(3, " ");
            Wii_DebugOverlayPrint(4, " ");
            Wii_DebugOverlayPrint(5, " ");
            Wii_DebugOverlayPrint(6, " ");
            Wii_DebugOverlayPrint(7, " ");
        }

        bool isGba = (ndsCore && romLoaded && !showFileBrowser
                      && !showSettingsMenu) ? ndsCore->gbaMode : false;
        uint64_t videoT0 = PPCGetTickCount();
        Wii_VideoRender(renderTop, renderBottom, isGba);
        uint64_t videoT1 = PPCGetTickCount();
        Wii_VideoFlushAsync();
        uint64_t videoT2 = PPCGetTickCount();
        VIDEO_WaitVSync();
        uint64_t videoT3 = PPCGetTickCount();
        videoRenderTicks += videoT1 - videoT0;
        videoFlushTicks += videoT2 - videoT1;
        videoVsyncTicks += videoT3 - videoT2;
        videoLoopCount++;
    }

    return 0;
}
