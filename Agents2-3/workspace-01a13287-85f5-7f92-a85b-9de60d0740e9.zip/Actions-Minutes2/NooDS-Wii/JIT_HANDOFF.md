# Wii JIT handoff — 2026-10-12

**Updated:** The hashes and validation label below describe the *earlier* BLX-only build. See [BUS_PROGRESS.md](BUS_PROGRESS.md) for the latest DOL hashes and regression evidence; [FPS_PROGRESS.md](FPS_PROGRESS.md) documents the intervening FPS diagnosis.

Repo: `radicalten/Actions-Minutes2`, cloned at `c79fd20` (no commit or push made). Sources: `NooDS-Wii/` under this project directory. Validation label: `blx_20261012_215642`.

## Changes

- `NooDS-Wii/arm_jit.cpp`: enable **ARM9 `BLX Rm`** as a native-block branch terminator. Read the branch target before setting LR so `BLX LR` uses the original target. Set LR to the guest return PC and preserve the existing interpreter-compatible mode switch and pipeline flush. Keep ARM7 `BLX Rm` on its interpreter path; BX behavior unchanged.
- `tools/run_suite_gba.sh`: invoke its child scripts with `bash` so G3 works from a clean checkout with the tracked `100644` script modes.
- `tools/test_branch_arm.py`: extract and compile the actual C++ branch helper on the host; test classifier CPU gating, link/target aliasing (`Rm == LR`), ARM/Thumb targets, and a failed condition. Run: `python3 tools/test_branch_arm.py`.

`arm_jit.h` and `jit_bridge.S` remain unchanged: the bridge ABI and encoder did not need changes for this branch fix. The guide's suggested T2 immediate-BLX change was not applied: `Interpreter::runOpcode()` routes `cond==0xF` through `handleReserved()` before JIT dispatch, and that handler already calls `blx()`. CLZ emission was also already present in this checkout. Ordinary STR/STRB native fast paths remain deferred pending memory/SMC-focused tests.

## Validation performed

| Gate | Result | Evidence |
|---|---|---|
| Cross-build JIT=0/BLOCKS=0, JIT=1/BLOCKS=0, JIT=1/BLOCKS=1 | **PASS** (exit 0 all three) | DOLs in project root. SHA-256: `99e6b49275d40f8a8af55298992e15a5a986d8e055ddd9d856f549db1a9b3873`, `6cb9d6db683e53c41a088b63bf25275e755c19506ba51898076a88dcdb7b7a4e`, `badc9518453c0b3abece66f6df184ff84137bcc6d53e8a455da982935c0b0a3c` respectively. Each build emitted one **pre-existing** assembler `.rodata` section-attribute warning from unmodified `interpreter_lookup.cpp` (not zero-warning). |
| PPC encoder oracle | **PASS** 52/52; required 44/44 | `evidence/g1_encoder_oracle.log` |
| Focused ARM9 BLX register branch helper | **PASS** | `python3 tools/test_branch_arm.py` |
| G2, `rockwrestler.nds` frames 15/30/45 and `suite.gba` frames 50/60/120; normal and 1024-word pool; two JIT modes vs interpreter | **PASS** 8/8 comparisons, 0 mismatches | `evidence/blx_20261012_215642_*_compare.json`; all 12 case `evidence/g2_blx_20261012_215642_*/result.txt` contain `STATUS=PASS` and `SENTINEL_HIT=1`. Dolphin runner's internal RC=143 is expected after sentinel. |
| G3 mGBA suite, three builds | **PASS** 13 suites, 1 skip, 6,998 suite tests per configuration; both comparisons 0 mismatches | `evidence/g3_blx_20261012_215642/` (three summaries, result files, comparisons). All three `gbaout_*.log` hashes: `97b08848fc0bd0e387705042adeabe8d712fbede4f1929eefc9a1e8c002c40ff`. Suite's own failed tests are baseline compatibility failures, not JIT mismatches. |
| `git diff --check` | **PASS** | Working tree |

These ROMs do not establish that a particular ARM9 BLX trampoline was hit; the focused C++ helper test covers the new path, but **end-to-end BLX trampoline on Wii hardware / Dolphin was NOT_RUN**. Cycle-accurate hardware, independent SMC/DMA-timed title, and controlled performance benchmark: **NOT_RUN**. Do not infer a speedup from these one-shot runs. Builds/DOLs and evidence are untracked; only the two source/script edits above are tracked-file modifications. Upload/commit at your discretion; nothing was pushed.
