# rockwrestler.nds — guarded DISPSTAT JIT read (2026-10-12)

**Historical DISPSTAT build:** browser-enabled `JIT=1 BLOCKS=1` DOL, SHA-256 `2cb18e0be32c6a4a48a40a7ae3dd6d50742cb39747836349c911734b44fe8556`. The current [`jit.dol`](jit.dol) also has a guarded KEYINPUT path; see [NDS_KEYINPUT_PROGRESS.md](NDS_KEYINPUT_PROGRESS.md). Rebuild the current DOL with `bash tools/build_browser_jit.sh`. No commit or push was made.

## Bottleneck and change

- Baseline `rockwrestler.nds` at 45 emulated frames: `PERF avg_frame_us=101885`, `DISPLAY rendered=15 skip=2`. The two-frame DS skip explains why displayed FPS is about one-third of emulated FPS; reducing it would not make the emulator execute the game faster.
- Optional diagnostics (off in `jit.dol`) found ~4.92 million ARM9 blocks starting with a halfword load, usually `E1D230B4` (`LDRH R3,[R2,#4]`); at the captured checkpoint `R2=04000000`, making this a DISPSTAT (`04000004`) poll. Of ~4.58 s in `runCore()` over 45 frames, ~3.91 s was CPU scheduling/execution, ~0.58 s scheduled SPU samples, ~0.085 s scanline256 work, and ~0.009 s scanline355 work (`evidence/g2_nds_taskprof_20261012/`). These are *Dolphin profiling results*, not real-Wii timings.
- Generic halfword native translation alone passed interpreter parity, but measured `102946 us/frame` and did **not** help (`evidence/g2_nds_half_20261012/`); it remains disabled by default. MMIO isn't in the mapped memory table, so the generic path still calls the interpreter.
- For ARM9 halfword loads, `arm_jit.cpp` now checks the **aligned** effective address for `04000004`, reads the **live** `Gpu::dispStat[0]` from the active `Core`, and stores it to the guest destination. Every other address retains the mapped-memory/interpreter fallback, including MMIO and unaligned reads; ARM7's path is unchanged. Guest instruction timing and the block scheduler boundary check are unchanged. `NOODS_JIT_DISPSTAT_FAST=0` disables this path; generic halfword loads separately remain opt-in through `NOODS_JIT_NATIVE_HALF_LOADS=1`. The worst-case code-pool reservation was raised to 4096 words per block to accommodate up to 24 guarded inline loads; the constrained-pool test now uses 8192 words.

## Repeated control vs production (Dolphin, same 45 frames)

| Build | `PERF avg_frame_us` | Approx. emulated frames/s from measured frame time | Displayed frames | Source |
|---|---:|---:|---:|---|
| Control, `NOODS_JIT_DISPSTAT_FAST=0` | 101885 | 9.82 | 15 | `evidence/g2_ndsrerun_control_20261012/` |
| Production, guarded path enabled | 88035 | 11.36 | 15 | `evidence/g2_ndsrerun_prod_20261012/` |

The ~13.6% reduction in frame time was reproduced in the control/production rerun. An extended 300-frame interpreter/JIT comparison also had **zero guest mismatches** at frames 45, 150, and 300: interpreter `103661 us/frame` versus optimized JIT `89567 us/frame` (see `evidence/dispstat_long_compare.json`). Both runs captured the **same static framebuffer hash at all three checkpoints**, so this establishes a longer stable polling workload, **not later animated gameplay**. The displayed count stays at 100/300 because DS frameskip is still 2; **hardware Display FPS and Emu FPS after this change are NOT_RUN**. The original user-reported Display 3 / Emu 10 FPS remains the only on-device-type measurement. The ~16 FPS in-game counter mentioned previously is a separate counter, observed on both Dolphin and a real Wii.

## Correctness and startup checks

- G1 PowerPC encoder oracle **52/52 PASS**, ARM9 BLX branch helper PASS (`evidence/g1_encoder_oracle.log`, `tools/test_branch_arm.py`).
- Rockwrestler normal and 8192-word code-pool-wrap runs: frames 15, 30, 45 match the interpreter in CPU state, memory hashes, framebuffer hashes, and final memory/framebuffer dumps; **zero mismatches**, sentinel hit, wrap run `poolWraps=1`: `evidence/dispstat_rw_{normal,wrap}_20261012_compare.json`.
- Single-instruction JIT (`BLOCKS=0`) rockwrestler frames 15/30/45: **zero mismatches**, `evidence/dispstat_rw_single_20261012_compare.json` (not an FPS improvement claim).
- GBA `suite.gba` normal and 8192-word wrap runs: frames 50, 60, 120 and final dumps match the interpreter; **zero mismatches**: `evidence/dispstat_gba_{normal,wrap}_20261012_compare.json`. ARM9 path is not used in GBA mode.
- G3 GBA suite harness: 13 suites, 1 intentional skip, 6,998 assertions exercised; the previous baseline and new JIT have **identical** suite results and byte-identical output SHA-256 `97b08848fc0bd0e387705042adeabe8d712fbede4f1929eefc9a1e8c002c40ff`, `evidence/g3_dispstat_20261012/compare_interp.json`. This is a *parity* result; the baseline log itself records 3,506 passed and 3,492 failed assertions, so it is not a claim that all 6,998 assertions passed.
- Browser smoke: an SD image with an autoboot file still logged `[NOODS] FILE_BROWSER active dir=sd:/` and **no** `AUTOBOOT path=`, `evidence/browser_jit_dispstat_20261012/`.

Remaining: try the new `jit.dol` on a real Wii (or the user's usual Dolphin setup) with `rockwrestler.nds`, report both overlay Display FPS and Emu FPS during comparable gameplay; check other DS games with unusual MMIO/memory mappings. DS G2 checks reach frame 300, but the framebuffer stayed static and these checks do not establish long-run gameplay compatibility.
