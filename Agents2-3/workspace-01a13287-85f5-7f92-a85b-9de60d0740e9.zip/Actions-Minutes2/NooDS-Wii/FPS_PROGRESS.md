# `suite.gba` displayed-FPS investigation — 2026-10-12

**Result:** default GBA frame skipping is now off; this removes an artificial ~3:1 reduction in *displayed* frames, but **60 displayed FPS was not reached or verified**. With block JIT, skip=0, and the shorter copy (before the final UI-only edits), Dolphin's 360-`runCore()` probe produced/displayed 195/194 frames over 6.40 seconds (about **30 displayed FPS**). The on-screen value on a real Wii with this build is **NOT_RUN**; please measure it there. The probe covers an evolving test-suite workload, not a controlled steady-state benchmark.

## What the 16-FPS counter measured

The Wii overlay previously displayed `perf.renderFrameCount` (new front-buffer swaps), **not** `Core::fps` (all emulated video frames). `InitializeSettings()` set `Settings::frameskip=2`, so `Gpu::gbaScanline308()` drew/enqueued one of every three emulated GBA frames. The test harness also named each `runCore()` return a “frame,” but a return can be triggered by an early `Core::updateRun()`, so its `PERF avg_frame_us` must **not** be used as video-frame time. Video-frame throughput is measured here using `DISPLAY produced`, `rendered`, and `elapsed_us` in `g2_state.log`.

## Changes in this round

- `NooDS-Wii/main.cpp`: keep the DS default of two skipped frames, but default GBA ROM loads to no skipping (`0`). Respect a frameskip value explicitly set in the frontend settings menu across later ROM loads.
- Show **Display** and **Emu** FPS separately in the Wii overlay.
- Copy only 240×160 GBA pixels to the presentation back buffer instead of copying the whole dual-DS-screen allocation while interrupts are disabled. NDS copying remains unchanged.
- Record production/render/overwrite counts and render/flush/vsync timing at G2 checkpoints, for future diagnosis.
- Earlier changes in this working tree remain: `arm_jit.cpp` ARM9 `BLX Rm` terminator fix, `run_suite_gba.sh` clean-checkout runner fix, `tools/test_branch_arm.py`.

## Evidence

- Baseline block JIT with skip=2 (`evidence/g2_fpsprobe_skip2_20261012/g2_state.log`): at harness return 360, rendered=65, elapsed=6.306 s (roughly 10 FPS averaged over this workload).
- Skip=0, before shorter copy (`evidence/g2_fpsprof_counters_20261012/g2_state.log`): produced=195, rendered=194, overwritten=1, elapsed=6.460 s. Presentation loop ran 405 times; `render_us=277833`, `vsync_us=6403861` are **cumulative since startup**, not per video frame. Loop itself was not the 30-FPS ceiling; new guest frames arrived at ~30 FPS.
- Skip=0, after shorter copy (`evidence/g2_fpsprof_gbacopy_20261012/g2_state.log`): produced=195, rendered=194, elapsed=6.397 s. One-shot comparison only; **no measured speedup claim** for the copy change.
- Interpreter, skip=0 (`evidence/g2_fpsprof_interp_20261012/g2_state.log`): produced=195, rendered=178, overwritten=17, elapsed=5.297 s. The interpreter remains faster at running the same suite than this JIT. Merely switching GBA to interpreter is not demonstrated to achieve 60 displayed FPS either.
- **Final config, G2 PASS:** `evidence/fps_final_20261012_221335_*_compare.json` (2 ROMs × 2 JIT variants × normal/1024-word pool = 8 comparisons, **0 mismatches**). All 12 case `result.txt` files say `STATUS=PASS`, `SENTINEL_HIT=1`. GBA default skip=0, NDS default skip=2. Final GBA checkpoint 120 block JIT: `rendered=73`, `produced=74`, `elapsed_us=2343082` (startup segment ~31 displayed FPS). Comparisons cover guest registers/cycles/memory/framebuffer, not FPS.
- **Final config, G3 PASS:** `evidence/g3_fps_final_20261012_221335/`; 3 configs each reach `ALL DONE` with 13 suites, 1 skip, 6,998 tests; both JIT summaries match interpreter, 0 mismatches. All three `gbaout.log` hashes = `97b08848fc0bd0e387705042adeabe8d712fbede4f1929eefc9a1e8c002c40ff`.
- Three incremental builds completed without **new** warnings; a clean full build in the previous round emitted one pre-existing assembler `.rodata` warning in untouched `interpreter_lookup.cpp`. G1 PPC encoder **52/52 PASS**, focused BLX helper **PASS**, `git diff --check` **PASS**.

Final DOL SHA-256: `jit0_blocks0` `a734c6564326ee583a100d2271c5629dc77724f4831616d1e46a647896d162d2`; `jit1_blocks0` `f0ddecad4c573721f86a1106e71f640c3fdfdd99af256735a1cbd921125ec4b4`; `jit1_blocks1` `2886ff955d55fb1325203a1d6b3114366da49b629213237ccbe2271a471bc8ad`.

**Next bottleneck:** GBA guest-CPU throughput / JIT fallback, especially ARM7 Thumb memory and stack instructions. In the final 120-return suite checkpoint, block JIT reports `disp7=2612288` and `fbInsn7=1307722` (fallback executions); a safe native Thumb memory path would need guarded bus writes/reads, correct SMC invalidation and exact cycle accounting before expanding classification. A 60-FPS claim requires a controlled on-Wii measurement with the actual on-screen counter. No commit or push was made.
