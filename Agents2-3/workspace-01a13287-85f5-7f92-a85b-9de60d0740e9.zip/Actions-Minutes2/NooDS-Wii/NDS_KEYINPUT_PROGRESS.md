# rockwrestler.nds — guarded KEYINPUT read (2026-10-12)

**Upload/test:** [`jit.dol`](jit.dol), browser-enabled JIT/block build, SHA-256 `70ea0748bbb03435bcba63280ac47f07e54588b31d5995d08cfe85cb9eccf3b2` (1,359,680 bytes). Boots to `sd:/` and supports `.nds` and `.gba` browsing; no autoboot. The preceding browser DOL was `2cb18e0b...`; the user measured that preceding DOL at **Display 4 / Emu 11 FPS on both Wii and Dolphin**. **No real-Wii measurements of this new DOL yet.** No commit or push was made.

## Reproducing the interactive workload

The original no-input G2 ROM stayed on the rockwrestler test menu for 300 frames. We added an **opt-in, autoboot G2-only** input script (`NOODS_G2_SCRIPTED_INPUT=1`), *not compiled into the browser DOL*. It presses A at completed frames 60–65 and 135–140. This navigates to ARMv4 → CONDITION CODES, runs the test (result `OK`), then waits for B. The script fields `INPUT_A_FROM`, `INPUT_A_TO`, `INPUT_A2_FROM`, `INPUT_A2_TO` can be supplied via the final four optional arguments to `tools/run_g2_case.sh` (after `POOL_LIMIT_WORDS`). Default builds have no injected input.

Disassembly around `020007C8` revealed `LDRH [R6,#0x30]` with `R6=04000100` followed by `ANDS #2` and a back-branch: a KEYINPUT (`04000130`) B-button wait. Unlike an idle DISPSTAT-only test, this scenario reaches a second interactive state and exposes another hot MMIO read. It is **still a small test ROM, not evidence of FPS in other games' gameplay**.

## Change and measured effect

`ArmPpcJit::emitNativeLoadArm` now adds a guarded ARM9 halfword read for the **aligned** address `04000130`: it reads the live `Core::input.keyInput` halfword, exactly matching the side-effect-free `Memory::ioRead9` KEYINPUT case. Every other address retains the original mapped-memory/interpreter path. The preceding guarded DISPSTAT path remains first, so its hot case takes no extra comparison. ARM7 and GBA paths are unchanged; the guest instruction cycle count, event boundary check, and input update cadence are unchanged. The path can be disabled for a control build with `NOODS_JIT_KEYINPUT_FAST=0`.

| Same scripted-input Dolphin test | 45 frames (menu) | 120 frames (submenu) | 180 frames (test/result) | 300 frames (B wait) |
|---|---:|---:|---:|---:|
| Previous JIT, KEYINPUT off | 88.895 | 89.507 | 98.347 | 109.116 |
| New JIT, KEYINPUT on | 88.895 | 89.507 | 89.651 | 89.662 |

Entries are cumulative `PERF avg_frame_us` converted to **ms/emulated frame**; from frame 180 to 300 alone, mean frame time changes from ~125.27 to ~89.68 ms (about 28.4% lower). This is Dolphin test-harness timing, **not** a predicted or measured real-Wii FPS increase. DS skip remains 2; both runs rendered 100 images in 300 emulated frames. Evidence: `evidence/g2_rw_press_a_twice_20261012/` (previous JIT) versus `evidence/g2_rw_keyfast_input_20261012/` (new JIT). The input-scripted builds are diagnostic, separate from `jit.dol`.

## Regression gates

- G1 PowerPC encoder oracle **52/52 PASS**; BLX branch helper PASS.
- Interactive rockwrestler: interpreter versus new JIT at frames **45, 120, 180, 300**, CPU state, memory hashes, framebuffer hashes and final dumps **all equal**; normal and 8,192-word code-pool-wrap (`poolWraps=3`) runs, **zero mismatches**: `evidence/rw_keyfast_input_compare.json`, `evidence/keyfast_rw_input_wrap_compare.json`.
- No-input rockwrestler frames **15, 30, 45**, normal and wrap: **zero mismatches**: `evidence/keyfast_rw_{normal,wrap}_20261012_compare.json`.
- GBA `suite.gba` frames **50, 60, 120**, normal and wrap: **zero mismatches**: `evidence/keyfast_gba_{normal,wrap}_20261012_compare.json`. Single-instruction JIT (`BLOCKS=0`) rockwrestler also matches: `evidence/keyfast_rw_single_compare.json`.
- GBA suite log remains byte-identical to the interpreter baseline, SHA-256 `97b08848fc0bd0e387705042adeabe8d712fbede4f1929eefc9a1e8c002c40ff`; `evidence/g3_keyfast_20261012/compare_interp.json` reports 13 suites, one intentional skip, 6,998 assertions, zero *differences*. The baseline contains 3,506 passing and 3,492 failing assertions; parity is **not** a claim that all assertions passed.
- Browser startup smoke with an SD autoboot file: entered `FILE_BROWSER active dir=sd:/` with no AUTOBOOT, `evidence/browser_jit_keyfast_20261012/`, PASS.

**Next:** test new `jit.dol` on both Wii and Dolphin at the same selected rockwrestler option and on another animated `.nds` game. Report both overlay Display and Emu FPS. A real-game trace/input script would let us optimize the gameplay bottleneck instead of projecting from this test ROM's button wait.
