# rockwrestler.nds — next-bottleneck investigation (2026-10-12)

The user reported **Display 4 FPS / Emu 11 FPS on both Wii and Dolphin** with the preceding browser JIT DOL from [NDS_DISPSTAT_PROGRESS.md](NDS_DISPSTAT_PROGRESS.md), SHA-256 `2cb18e0be32c6a4a48a40a7ae3dd6d50742cb39747836349c911734b44fe8556`. This *historical investigation* did not itself yield a speedup. Interactive input subsequently exposed a new KEYINPUT bottleneck; see [NDS_KEYINPUT_PROGRESS.md](NDS_KEYINPUT_PROGRESS.md) for the **current** [`jit.dol`](jit.dol). No commit or push was made.

## What was tested

| Probe (separate DOL; not shipped) | Dolphin time at 45 emulated frames | Guest parity | Decision |
|---|---:|---|---|
| Current guarded-DISPSTAT JIT, `-O2` | 88.035 ms/frame | Previous interpreter G2 zero mismatches | Keep |
| No-active-channel SPU shortcut | 88.034 ms/frame | 0 mismatches | Reverted: no measurable gain |
| ARM7 IPCSYNC `Memory::readFallback` shortcut | 88.106 ms/frame | 0 mismatches | Reverted: slower |
| ARM7 guarded IPCSYNC JIT load | 88.016 ms/frame | 0 mismatches | Reverted: difference too small to justify more JIT complexity |
| Existing joint fixed-point poll skip enabled | 153.073 ms/frame; 0 skips | 0 mismatches | Left disabled: substantial regression |
| Actual `-O3` cross-build (command-line override of Makefile `CXXFLAGS`) | 88.361 ms/frame | 0 mismatches | Not shipped: slower than `-O2` |

One initial purported `-O3` attempt inherited Makefile's later `-O2` and produced a binary **identical** to the production build; its numbers are not an `-O3` result. The actual `-O3` probe above overrides `CXXFLAGS` on the `make` command line.

## Why poll skipping cannot be widened naively

An optional dispatch histogram (`evidence/g2_poll_dbg_impure_20261012/g2_state.log`, first 15 frames) counted 192,318 ARM7 executions each of `E1C208B0` (`STRH` to IPCSYNC) and `979FF103` (conditional `LDR PC`); ARM9 repeatedly polls DISPSTAT. Disassembly of the supplied small ROM shows ARM7 repeatedly writes IPCSYNC in its control loop. As a result, the existing fixed-point detector registered no identical ARM7 loop snapshots and zero safe joint skips. ARM7's writes can affect cross-CPU synchronization/interrupts. Advancing both CPUs past those writes without an event- and side-effect-exact proof would break guest behavior. The probe instrumentation was removed from production source after diagnosis.

At frame 45, a profiling-only build (`evidence/g2_nds_round2_prof_20261012/`) still attributes most JIT dispatch time to ARM9 load-first blocks, with ARM7 blocks and PC-destination fallback also significant. Audio-task profiling/histogram (`evidence/g2_spuhist_20261012/`) showed 24,470 DS sample calls with no active channels or captures; bypassing the empty mix did not move the overall time. These Dolphin numbers should not be extrapolated to real-Wii FPS.

Next useful direction: obtain a reproducible **animated or gameplay** checkpoint/scene (the ROM's framebuffers were unchanged through frame 300 in the prior test), then profile its actual CPU/GPU workload. The current static-poll workload is already addressed by the guarded DISPSTAT read; further shortcuts have correctness risks or no measurable gain. Ask for the device and screen/scene where 4 Display / 11 Emu FPS was observed. Keep DS frameskip at 2 unless intentionally evaluating display smoothness rather than emulation throughput.
