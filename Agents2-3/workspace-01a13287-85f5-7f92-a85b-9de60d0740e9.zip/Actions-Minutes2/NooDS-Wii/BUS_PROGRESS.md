# Wii GBA / Broadway bus-and-JIT profiling — 2026-10-12

**Current status:** `suite.gba` still does **not** reach 60 displayed FPS in the Dolphin probe. The change below speeds up the interpreter's mapped memory path in one diagnostic run, but does not materially improve the block JIT's ~30 produced/displayed frames per second. **Real-Wii FPS: NOT_RUN**. No commit/push was made.

## Code changes in this round

- `NooDS-Wii/memory.h`: word-align the backing arrays starting with `bios9` (ARM7 GBA WRAM, main RAM, VRAM offsets changed from `2 mod 4` to `0 mod 4` in the compiled layout). For mapped aligned 16/32-bit reads/writes, use `__builtin_memcpy` plus endian swap in the **existing guarded `Memory::read/write` helpers**. The PPC compiler emits `lhbrx/lwbrx` and `sthbrx/stwbrx` where safe. Unaligned map backing pointers retain the old byte-wise path; unmapped/MMIO still use the existing fallback; writes still call `invalidateSharedAddr`. No direct guest-memory accesses were added to the JIT.
- `NooDS-Wii/arm_jit.cpp`: optional `NOODS_JIT_THUMB_HIST=1` 64-bucket histogram of ARM7 Thumb fallback opcodes (bits 15:10); **off by default**. Compiling it temporarily identified the hot fallback families. An experimental early-interpreter path for those families passed parity but made this workload slower (6.396 vs. 6.461 s), so it was **removed** from the final source.
- Earlier working-tree changes remain in `arm_jit.cpp` (ARM9 BLX Rm), `main.cpp` (GBA no-skip default, GBA presentation copy, dual FPS display and diagnostics), and `tools/run_suite_gba.sh`.

## Evidence and limits

| Check | Result |
|---|---|
| Alignment / PPC disassembly | **PASS**: `offsetof(Memory, ram/wram/wram7/vramC) % 4` changed from 2 to 0. Cross-built `Memory::read<uint32_t>` now contains guarded `lwbrx` and byte-wise fallback. |
| Three Wii builds | **PASS** (`JIT=0,BLOCKS=0`; `JIT=1,BLOCKS=0`; `JIT=1,BLOCKS=1`). One pre-existing `.rodata` assembler warning from untouched `interpreter_lookup.cpp` on full rebuilds. |
| G1 encoder / BLX helper | **PASS** 52/52; `python3 tools/test_branch_arm.py` PASS. |
| G2 | **PASS**: 8/8 JIT-vs-interpreter comparisons, zero guest state/memory/framebuffer mismatches; normal and 1024-word pool on NDS and GBA. See `evidence/bus_20261012_223020_*_compare.json` and 12 `evidence/g2_bus_20261012_223020_*/result.txt` files (`STATUS=PASS`, `SENTINEL_HIT=1`). |
| G3 | **PASS**: three builds, 13 suites, 1 skip, 6,998 tests in each; both JIT summaries match interpreter with zero mismatches. `evidence/g3_bus_20261012_223020/`; identical `gbaout.log` SHA-256 `97b08848fc0bd0e387705042adeabe8d712fbede4f1929eefc9a1e8c002c40ff`. |
| Performance probe, `suite.gba` (Dolphin only) | **Diagnostic, not a benchmark:** after 360 `runCore()` returns, 195 *actual produced frames*; interpreter elapsed 5.297 s before (`evidence/g2_fpsprof_interp_20261012/`) and 4.550 s after (`evidence/g2_memfast_interp_20261012/`). Block JIT elapsed 6.396 s before (`evidence/g2_thumbbase_20261012/`) and 6.375 s after (`evidence/g2_memfast_20261012/`). One-shot Dolphin timings must not be extrapolated to hardware or advertised as a measured speedup. |

The optional histogram capture at `evidence/g2_thumb_hist_20261012/g2_state.log` (at 360 harness returns) counted fallback Thumb opcode buckets `0x2F` (POP family) **899,706**, `0x2D` (PUSH family) **533,752**, `0x24` (STR SP-relative) **486,272**, `0x18` (STR immediate) **347,534**, and `0x12` (LDR PC-relative) **324,179**. This suggests that guarded, cycle-exact Thumb memory/stack *block* translation is the next meaningful JIT project. Keep SMC and event-boundary invariants; do not widen classifiers to raw memory access.

Current DOL SHA-256: `jit0_blocks0` `7218fa72c37e1a060fcc9898a8555d1756749da0a1e94fdc2bbde2cb21373974`; `jit1_blocks0` `a43d8d19d8cb623fcf30e49d0942edbabcbe193fb36416cb46dc200db67c279a`; `jit1_blocks1` `6a66659864b0fc52ff40ddc92e693946a942a833d08faa47cc74b631dc18abce`.

Remaining: controlled on-Wii real FPS, MMIO and SMC stress titles, and a native Thumb memory emitter with correct bus/invalidations are **NOT_RUN**. Earlier [FPS_PROGRESS.md](FPS_PROGRESS.md) DOL hashes are superseded by this build.
