#include <map>
#include <thread>
#include <utility>
#include <variant>
#include <set>
#include "blockingconcurrentqueue.h"

#include "ultramodern/ultra64.h"
#include "ultramodern/ultramodern.hpp"
#include "deterministic.hpp"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include "Windows.h"
#endif

#ifdef __3DS__
#include <3ds.h>
static u64 start_arm11_tick = svcGetSystemTick();
#endif

// Start time for the program
static std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();
// Offset of the duration since program start used to calculate the value for osGetTime. 
static int64_t ostime_offset = 0;
// Game speed multiplier (1 means no speedup)
constexpr uint32_t speed_multiplier = 1;
// N64 CPU counter ticks per millisecond
constexpr uint32_t counter_per_ms = 46'875 * speed_multiplier;

struct OSTimer {
    PTR(OSTimer) unused1;
    PTR(OSTimer) unused2;
    OSTime interval;
    OSTime timestamp;
    PTR(OSMesgQueue) mq;
    OSMesg msg;
};

// The timer as osSetTimer set it. The timer thread keeps its own copy and
// never reads the game's OSTimer: the game may rewrite that struct while the
// thread still holds the timer (stopping and restarting the same timer each
// frame, the stop processed later), and a set ordered by the struct's own
// timestamp then broke. An erase that missed left a fired one-shot timer at
// its front, fired again at once without end: the thread spun above the game
// threads and the game stopped (Banjo-Kazooie on the 3DS).
struct AddTimerAction {
    PTR(OSTimer) timer;
    OSTime timestamp;
    OSTime interval;
    PTR(OSMesgQueue) mq;
    OSMesg msg;
};

struct RemoveTimerAction {
    PTR(OSTimer) timer;
};

using Action = std::variant<AddTimerAction, RemoveTimerAction>;

struct {
    ultramodern::HostThread thread;
    moodycamel::BlockingConcurrentQueue<Action> action_queue{};
} timer_context;

uint64_t duration_to_ticks(std::chrono::high_resolution_clock::duration duration) {
    uint64_t delta_micros = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    // More accurate than using a floating point timer, will only overflow after running for 12.47 years
    // Units: (micros * (counts/millis)) / (micros/millis) = counts
    uint64_t total_count = (delta_micros * counter_per_ms) / 1000;

    return total_count;
}

std::chrono::microseconds ticks_to_duration(uint64_t ticks) {
    using namespace std::chrono_literals;
    return ticks * 1000us / counter_per_ms;
}

std::chrono::high_resolution_clock::time_point ticks_to_timepoint(uint64_t ticks) {
    return start_time + ticks_to_duration(ticks);
}

uint64_t time_now() {
    if (ultramodern::det::enabled()) {
        return ultramodern::det::now_for_read();
    }
#ifdef __3DS__
    const u64 dt = svcGetSystemTick() - start_arm11_tick;
    const u64 secs = dt / (u64)SYSCLOCK_ARM11;
    const u64 rem  = dt % (u64)SYSCLOCK_ARM11;
    constexpr uint64_t n64_per_sec = 1000ull * counter_per_ms;
    return secs * n64_per_sec + (rem * n64_per_sec) / (u64)SYSCLOCK_ARM11;
#else
    return duration_to_ticks(std::chrono::high_resolution_clock::now() - start_time);
#endif
}

extern "C" volatile uint32_t ultramodern_dbg_counts[8];   // mesgqueue.cpp

void timer_thread(RDRAM_ARG1) {
    ultramodern::set_native_thread_name("Timer Thread");
    ultramodern::set_native_thread_priority(ultramodern::ThreadPriority::VeryHigh);

    // The active timers by timer, and in firing order (timestamp, then
    // timer), both from the copies the actions carry.
    struct ActiveTimer {
        OSTime timestamp;
        OSTime interval;
        PTR(OSMesgQueue) mq;
        OSMesg msg;
    };
    std::map<PTR(OSTimer), ActiveTimer> active_timers;
    std::set<std::pair<OSTime, PTR(OSTimer)>> firing_order;

    auto remove_timer = [&](PTR(OSTimer) timer) {
        auto it = active_timers.find(timer);
        if (it != active_timers.end()) {
            firing_order.erase({ it->second.timestamp, timer });
            active_timers.erase(it);
        }
    };

    // Lambda to process a timer action to handle adding and removing timers
    auto process_timer_action = [&](const Action& action) {
        // Determine the action type and act on it
        if (const auto* add_action = std::get_if<AddTimerAction>(&action)) {
            // Setting a timer that is still active replaces it.
            remove_timer(add_action->timer);
            active_timers[add_action->timer] = ActiveTimer{ add_action->timestamp, add_action->interval, add_action->mq, add_action->msg };
            firing_order.insert({ add_action->timestamp, add_action->timer });
        } else if (const auto* remove_action = std::get_if<RemoveTimerAction>(&action)) {
            remove_timer(remove_action->timer);
        }
    };

    while (true) {
        ultramodern_dbg_counts[3] = ultramodern_dbg_counts[3] + 1;
        // Empty the action queue
        Action cur_action;
        while (timer_context.action_queue.try_dequeue(cur_action)) {
            process_timer_action(cur_action);
        }

        // If there's no timer to act on, wait for one to come in from the action queue
        while (firing_order.empty()) {
            timer_context.action_queue.wait_dequeue(cur_action);
            process_timer_action(cur_action);
        }

        // The timer that's closest to running out
        const OSTime timestamp = firing_order.begin()->first;
        const PTR(OSTimer) cur_timer_ = firing_order.begin()->second;

        // Determine how long to wait to reach the timer's timestamp
#ifdef __3DS__
        const int64_t rem_ticks = (int64_t)(timestamp - time_now());
        auto wait_duration = rem_ticks > 0 ? ticks_to_duration((uint64_t)rem_ticks) : std::chrono::microseconds{0};
#else
        auto wait_duration = ticks_to_timepoint(timestamp) - std::chrono::high_resolution_clock::now();
#endif

        // Wait for either the duration to complete or a new action to come through
        if (wait_duration.count() >= 0 && timer_context.action_queue.wait_dequeue_timed(cur_action, wait_duration)) {
            // Timer was interrupted by a new action: process it, then look again
            process_timer_action(cur_action);
        }
        else {
            // Waiting for the timer completed, so send the timer's message to its message queue
            ActiveTimer fired = active_timers[cur_timer_];
            firing_order.erase(firing_order.begin());
            active_timers.erase(cur_timer_);
            ultramodern::enqueue_external_message_src(fired.mq, fired.msg, false, ultramodern::EventMessageSource::Timer);
            // If the timer has a specified interval then reload it with that value
            if (fired.interval != 0) {
                fired.timestamp = fired.interval + time_now();
                active_timers[cur_timer_] = fired;
                firing_order.insert({ fired.timestamp, cur_timer_ });
            }
        }
    }
}

// Deterministic mode keeps active timers here (touched only by game threads) instead of using the
// timer thread, and fires them from virtual time.
struct DetTimerOrder {
    uint8_t* rdram;
    bool operator()(PTR(OSTimer) a_, PTR(OSTimer) b_) const {
        OSTimer* a = TO_PTR(OSTimer, a_);
        OSTimer* b = TO_PTR(OSTimer, b_);
        if (a->timestamp != b->timestamp) {
            return a->timestamp < b->timestamp;
        }
        return a_ < b_;
    }
};
static std::set<PTR(OSTimer), DetTimerOrder>* det_timers = nullptr;

static std::set<PTR(OSTimer), DetTimerOrder>& get_det_timers(RDRAM_ARG1) {
    if (det_timers == nullptr) {
        det_timers = new std::set<PTR(OSTimer), DetTimerOrder>(DetTimerOrder{ PASS_RDRAM1 });
    }
    return *det_timers;
}

uint64_t ultramodern::det::next_timer_timestamp(RDRAM_ARG1) {
    auto& timers = get_det_timers(PASS_RDRAM1);
    return timers.empty() ? UINT64_MAX : TO_PTR(OSTimer, *timers.begin())->timestamp;
}

void ultramodern::det::fire_timers(RDRAM_ARG uint64_t now) {
    auto& timers = get_det_timers(PASS_RDRAM1);
    while (!timers.empty() && TO_PTR(OSTimer, *timers.begin())->timestamp <= now) {
        PTR(OSTimer) t_ = *timers.begin();
        OSTimer* t = TO_PTR(OSTimer, t_);
        timers.erase(timers.begin());
        ultramodern::enqueue_external_message_src(t->mq, t->msg, false, ultramodern::EventMessageSource::Timer);
        if (t->interval != 0) {
            t->timestamp += t->interval;
            timers.insert(t_);
        }
    }
}

void ultramodern::init_timers(RDRAM_ARG1) {
    ultramodern::det::set_rdram(PASS_RDRAM1);
    timer_context.thread = ultramodern::HostThread{ultramodern::HostThreadKind::Timer, [=]() { timer_thread(PASS_RDRAM1); }};
    timer_context.thread.detach();
}

uint32_t ultramodern::get_speed_multiplier() {
    return speed_multiplier;
}

std::chrono::high_resolution_clock::time_point ultramodern::get_start() {
    return start_time;
}

std::chrono::high_resolution_clock::duration ultramodern::time_since_start() {
#ifdef __3DS__
    const u64 dt = svcGetSystemTick() - start_arm11_tick;
    const u64 secs = dt / (u64)SYSCLOCK_ARM11;
    const u64 rem  = dt % (u64)SYSCLOCK_ARM11;
    const auto ns = std::chrono::nanoseconds(secs * 1000000000ull + (rem * 1000000000ull) / (u64)SYSCLOCK_ARM11);
    return std::chrono::duration_cast<std::chrono::high_resolution_clock::duration>(ns);
#else
    return std::chrono::high_resolution_clock::now() - start_time;
#endif
}

extern "C" u32 osGetCount() {
    uint64_t total_count = time_now();

    // Allow for overflows, which is how osGetCount behaves
    return (uint32_t)total_count;
}

extern "C" void osSetCount(u32 count) {
    assert(false);
}

extern "C" OSTime osGetTime() {
    uint64_t total_count = time_now() - ostime_offset;

    return total_count;
}

extern "C" void osSetTime(OSTime t) {
    ostime_offset = time_now() - t;
}

extern "C" int osSetTimer(RDRAM_ARG PTR(OSTimer) t_, OSTime countdown, OSTime interval, PTR(OSMesgQueue) mq, OSMesg msg) {
    OSTimer* t = TO_PTR(OSTimer, t_);

    // In deterministic mode the set is ordered by timestamp, so take the timer out before changing it.
    if (ultramodern::det::enabled()) {
        get_det_timers(PASS_RDRAM1).erase(t_);
    }

    // Determine the time when this timer will trigger off
    if (countdown == 0) {
        // Set the timestamp based on the interval
        t->timestamp = interval + time_now();
    } else {
        t->timestamp = countdown + time_now();
    }
    t->interval = interval;
    t->mq = mq;
    t->msg = msg;

    if (ultramodern::det::enabled()) {
        get_det_timers(PASS_RDRAM1).insert(t_);
        return 0;
    }

    timer_context.action_queue.enqueue(AddTimerAction{ t_, t->timestamp, interval, mq, msg });

    return 0;
}

extern "C" int osStopTimer(RDRAM_ARG PTR(OSTimer) t_) {
    if (ultramodern::det::enabled()) {
        get_det_timers(PASS_RDRAM1).erase(t_);
        return 0;
    }
    timer_context.action_queue.enqueue(RemoveTimerAction{ t_ });

    // TODO don't blindly return 0 here; requires some response from the timer thread to know what the returned value was
    return 0;
}

#ifdef _WIN32

// The implementations of std::chrono::sleep_until and sleep_for were affected by changing the system clock backwards in older versions
// of Microsoft's STL. This was fixed as of Visual Studio 2022 17.9, but to be safe ultramodern uses Win32 Sleep directly.
void ultramodern::sleep_milliseconds(uint32_t millis) {
    Sleep(millis);
}

void ultramodern::sleep_until(const std::chrono::high_resolution_clock::time_point& time_point) {
    auto time_now = std::chrono::high_resolution_clock::now();
    if (time_point > time_now) {
        long long delta_ms = std::chrono::ceil<std::chrono::milliseconds>(time_point - time_now).count();
        // printf("Sleeping %lld %d ms\n", delta_ms, (uint32_t)delta_ms);
        Sleep(delta_ms);
    }
}

#else

void ultramodern::sleep_milliseconds(uint32_t millis) {
    std::this_thread::sleep_for(std::chrono::milliseconds{millis});
}

void ultramodern::sleep_until(const std::chrono::high_resolution_clock::time_point& time_point) {
    std::this_thread::sleep_until(time_point);
}

#endif
