// The 3DS entry point: console services, the runtime's callbacks, and the
// runtime itself. The game supplies a GameDesc; everything else is shared.
#include <3ds.h>
#include <malloc.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <string>
#include <sys/stat.h>

#include "librecomp/addresses.hpp"
namespace recomp { uint32_t heap_rdram_address() __attribute__((weak)); }
#include "librecomp/game.hpp"
#include "librecomp/rsp.hpp"
#include "ultramodern/ultramodern.hpp"
#include "ultramodern/error_handling.hpp"
#include "ultramodern/events.hpp"
#include "ultramodern/host_thread.hpp"
#include "o1heap/o1heap.h"
#include "librecomp/addresses.hpp"
#include "recomp3ds.h"
#include "recomp3ds_internal.h"
#include "naudio_hle.h"
#include "dsp_synth.h"
#include "aspmain_hle.h"
#include "audio_hle_diff.h"

// libctru's default main stack is 32 KB; the runtime's start path and the
// C++ library want more.
extern "C" { u32 __stacksize__ = 512 * 1024; }

namespace {

char g_base_path[128] = "sdmc:/3ds";

// RSP task timing (audio: the graphics tasks go to the renderer instead).
recomp::rsp::callbacks_t::get_rsp_microcode_t* g_game_get_ucode = nullptr;
RspUcodeFunc* g_ucode_inner = nullptr;
u64 g_ucode_ticks = 0;
u32 g_ucode_tasks = 0;

bool g_audio_hle = false;
recomp3ds::AudioHle g_audio_hle_family = recomp3ds::AudioHle::Naudio;

uint8_t* g_rdram = nullptr;
// dbg_slow_gfx_ms / dbg_slow_audio_ms (settings.ini): pad every display list
// and audio task by that much, to reproduce console timing in the emulator.
int g_slow_audio_ms = 0;

RspExitReason timed_ucode(uint8_t* rdram, uint32_t ucode_addr) {
    g_rdram = rdram;
    if (recomp3ds::audio_hle_capturing()) {
        // AUDIO_CAPTURE.TXT: the task as it arrives, whichever code runs it.
        OSTask task;
        memcpy(&task, &dmem[0xFC0], sizeof(OSTask));
        if (task.t.type == M_AUDTASK) recomp3ds::audio_hle_maybe_capture(rdram, task);
    }
    u64 t0 = svcGetSystemTick();
    RspExitReason r = g_ucode_inner(rdram, ucode_addr);
    if (g_slow_audio_ms > 0) svcSleepThread((s64)g_slow_audio_ms * 1000000);
    g_ucode_ticks += svcGetSystemTick() - t0;
    g_ucode_tasks++;
    return r;
}

// Audio off: the audio task completes at once, doing nothing.
RspExitReason audio_off_ucode(uint8_t*, uint32_t) {
    return RspExitReason::Broke;
}

RspUcodeFunc* timed_get_ucode(const OSTask* task) {
    // Audio off, or the voices on the DSP (dsp_synth.h): the task does nothing
    // and the AI stream carries silence, at the usual rate.
    if (task->t.type == M_AUDTASK && (!recomp3ds::audio_enabled() || recomp3ds::dsp_synth_enabled())) {
        return audio_off_ucode;
    }
    RspUcodeFunc* f = g_game_get_ucode(task);
    if (f == nullptr) {
        return nullptr;
    }
    // The first microcode the game hands over is its audio task's.
    static RspUcodeFunc* game_ucode = nullptr;
    if (game_ucode == nullptr) {
        game_ucode = f;
        char path[192];
        snprintf(path, sizeof(path), "%s/AUDIO_CAPTURE.TXT", g_base_path);
        if (FILE* c = fopen(path, "r")) {
            int first = 0;
            if (fscanf(c, "%d", &first) != 1) first = 0;   // the first task to capture
            fclose(c);
            recomp3ds::audio_hle_capture_dir(g_base_path, first);
        }
        if (g_audio_hle) {
            // The CPU interpreter replaces the game's (recompiled) microcode;
            // dbg_audio_rsp runs the recompiled microcode instead, for comparison.
            const bool aspmain = g_audio_hle_family == recomp3ds::AudioHle::Aspmain;
            if (recomp3ds::debug_settings().audio_rsp != 0) {
                g_audio_hle = false;
                fprintf(stderr, "recomp3ds: audio runs the recompiled RSP microcode (dbg_audio_rsp)\n");
            }
            if (g_audio_hle) {
                fprintf(stderr, "recomp3ds: audio task interpreted on the CPU (%s; dbg_audio_rsp selects the recompiled microcode)\n",
                        aspmain ? "aspMain" : "naudio");
            }
        }
    }
    if (g_audio_hle && f == game_ucode) {
        f = g_audio_hle_family == recomp3ds::AudioHle::Aspmain ? recomp3ds::aspmain_hle_run : recomp3ds::naudio_hle_run;
    }
    if (g_ucode_inner != nullptr && g_ucode_inner != f) {
        return f;   // a second microcode: leave it untimed rather than mix them
    }
    g_ucode_inner = f;
    return timed_ucode;
}

extern "C" void __appExit(void);   // libctru: closes the services __appInit opened
extern "C" void (*__system_retAddr)(void);   // libctru: set by aptExit to finish closing the application

const recomp3ds::GameDesc* g_desc = nullptr;
int g_sp_core = 2;
int g_gfx_core = 2;                     // core 1 or 0 on an Old 3DS, which has no core 2
int g_game_core = 0;                    // the N64 threads (the Cores row's "game on 1": core 1)
int g_helper_core = 0;                  // the DSP synthesizer's decoding thread
unsigned g_watch_cores = 1;             // the cores loadmon watches (bit n: core n)
bool g_core3 = false;                   // a New 3DS lets the application run threads on core 3
bool g_core1_granted = false;           // the system gives the application time on core 1
bool g_has_core2 = false;               // true when the renderer has dedicated core 2 (New 3DS)
u32 g_core1_normal_limit = 30;          // active Core 1 time limit during gameplay (30% N3DS, 80% O3DS)
volatile int g_main_stage = 0;          // recomp3ds::main_stage

// Thread placement: game code on core 0, renderer on core 2 (on an Old 3DS
// core 1 when the system grants time there, else 0), the audio task on
// g_sp_core (core 1 when the system grants time there), pacing threads
// above the game so their sleeps wake it, on its core. The Cores row's
// "game on 1" swaps: the game on core 1, everything else on core 0.
ultramodern::HostThreadSpec host_thread_spec(ultramodern::HostThreadKind kind) {
    using K = ultramodern::HostThreadKind;
    switch (kind) {
        case K::GameStart:
        case K::Game:    return { 128 * 1024, 0x30, g_game_core };
        case K::Gfx:     return { 256 * 1024, 0x2C, g_gfx_core };
        case K::SpTask:  return { 64 * 1024, 0x24, g_sp_core };
        case K::Vi:
        case K::Timer:   return { 32 * 1024, 0x28, g_game_core };
        default:         return { 32 * 1024, 0x30, g_game_core };
    }
}
volatile bool g_exit_requested = false;
void (*g_game_on_init)(uint8_t* rdram, recomp_context* ctx) = nullptr;

}   // namespace

int recomp3ds::helper_core() { return g_helper_core; }
int recomp3ds::main_stage() { return g_main_stage; }
const char* recomp3ds::main_stage_name(int stage) {
    static const char* const kNames[] = { "sleep", "pad", "flush", "motion", "home", "select", "report", "watchdog", "apt" };
    return stage >= 0 && stage < 9 ? kNames[stage] : "?";
}

namespace {

void* create_gfx() { return nullptr; }

ultramodern::renderer::WindowHandle create_window(void*) {
    return ultramodern::renderer::WindowHandle{};
}

// The end of quitting, from run() once the runtime has returned or from the
// exit watchdog: libctru's exit minus C++ destructors and the heap unmapping,
// which would pull memory from under the game threads the runtime leaves
// blocked (a data abort on the way out). __appExit's aptExit sends
// PrepareToClose and leaves the final APT_CloseApplication in
// __system_retAddr, which __libctru_exit calls just before svcExitProcess;
// skipping that left the HOME Menu with a half-closed application.
[[noreturn]] void finish_exit() {
    static volatile u32 once = 0;
    if (__atomic_exchange_n(&once, 1u, __ATOMIC_SEQ_CST) != 0) {
        for (;;) svcSleepThread(1000000000ll);    // the other path is already leaving
    }
    fflush(stderr);
    // A frame capture still being written stops between two FS requests
    // (its file stays incomplete): nothing of ours is in flight on the card
    // when FS is torn down below.
    rt64_3ds::capture_stop(1500);
    recomp3ds::settings_flush();           // a change inside the save's one-second debounce
    recomp3ds::log_flush();
    recomp3ds::stall_watch_stop();
    recomp3ds::loadmon_stop();
    recomp3ds::dsp_synth_shutdown();
    recomp3ds::audio_shutdown();
    gfxExit();
    osSetSpeedupEnable(false);             // hand the system back at the clock it had
    __appExit();
    if (__system_retAddr) __system_retAddr();
    svcExitProcess();
}

// On Old 3DS (where Core 1 runs the renderer + audio at 80%), holding
// L + D-Pad Down drops Core 1's quota to 30% immediately so Luma3DS's
// Rosalina menu (L+Down+Select) never hangs, restoring 80% once released.
bool update_rosalina_throttle(u32 all_keys) {
    static bool rosalina_throttled = false;
    static u64 rosalina_release_tick = 0;
    const bool rosalina_combo = (all_keys & (KEY_L | KEY_DDOWN)) == (KEY_L | KEY_DDOWN);
    if (!g_has_core2 && g_core1_granted && g_core1_normal_limit > 30) {
        if (rosalina_combo) {
            rosalina_release_tick = 0;
            if (!rosalina_throttled) {
                APT_SetAppCpuTimeLimit(30);
                rosalina_throttled = true;
            }
        } else if (rosalina_throttled) {
            const u64 now = svcGetSystemTick();
            if (rosalina_release_tick == 0) {
                rosalina_release_tick = now;
            } else if (now - rosalina_release_tick > SYSCLOCK_ARM11 / 4) {
                APT_SetAppCpuTimeLimit(g_core1_normal_limit);
                rosalina_throttled = false;
                rosalina_release_tick = 0;
            }
        }
    }
    return rosalina_combo;
}

// HOME: rt64-3ds quick-quit prompt on the touch screen instead of the system
// HOME Menu. A quits cleanly via wait_idle_for_exit() + finish_exit(); B (or
// HOME again) resumes. While the prompt is up the game is held, its input is
// blocked and its sound paused; the top screen keeps the last frame.
bool g_home_trapped = false;

u32 prompt_keys() {
    u32 hw = 0;
    recomp3ds::input_scan_main(&hw, nullptr, nullptr, nullptr);
    const u32 keys = hw | recomp3ds::autotest_tick();
    update_rosalina_throttle(keys);
    return keys;
}

void draw_home_prompt(bool show) {
    constexpr int kRow = 23;
    if (show) {
        recomp3ds::screen_printf("\x1b[%d;0H----------------------------------------", kRow);
        recomp3ds::screen_printf("\x1b[%d;0H  Quit %-33s", kRow + 1, g_desc != nullptr ? g_desc->render.game_name : "the game");
        recomp3ds::screen_printf("\x1b[%d;0H  A: quit   B: resume%19s", kRow + 2, "");
        recomp3ds::screen_printf("\x1b[%d;0H----------------------------------------", kRow + 3);
    }
    else {
        for (int r = kRow; r < kRow + 4; r++) recomp3ds::screen_printf("\x1b[%d;0H%40s", r, "");
    }
    // Flush the CPU data cache for the bottom console framebuffer immediately
    // while the renderer's frame loop is paused.
    recomp3ds::screen_flush();
    gfxFlushBuffers();
}

// Returns true when the player chose to quit.
bool home_prompt() {
    fprintf(stderr, "recomp3ds: HOME - quit prompt\n");
    rt64_3ds::set_paused(true);
    recomp3ds::stall_watch_pause(true);    // the main thread and the frames stop here by design
    recomp3ds::input_set_blocked(true);
    recomp3ds::audio_set_paused(true);
    draw_home_prompt(true);
    u32 prev = prompt_keys();              // held on entry: not a press
    bool quit = false;
    for (;;) {
        if (!aptMainLoop()) { quit = true; break; }
        const u32 keys = prompt_keys();
        const u32 down = keys & ~prev;
        prev = keys;
        if (aptCheckHomePressRejected() || recomp3ds::autotest_take_home()) break;
        if (down & KEY_A) { quit = true; break; }
        if (down & KEY_B) break;
        svcSleepThread(16 * 1000000ll);
    }
    if (!quit) {
        while ((prompt_keys() & KEY_B) != 0) {
            if (!aptMainLoop()) { quit = true; break; }
            svcSleepThread(16 * 1000000ll);
        }
    }
    draw_home_prompt(false);
    recomp3ds::stall_watch_pause(false);
    recomp3ds::settings_menu_redraw();
    recomp3ds::screen_flush();
    recomp3ds::input_set_blocked(false);
    if (!quit) {
        recomp3ds::audio_set_paused(false);
        rt64_3ds::set_paused(false);
    }
    fprintf(stderr, "recomp3ds: HOME prompt closed (%s)\n", quit ? "quit" : "resume");
    return quit;
}

// Called by the runtime's main loop (which sleeps 1 ms between calls) on
// core 0, the game's core: it sleeps most of a VI itself so the main thread
// wakes ~60 times a second instead of 1000.
void update_gfx_inner();
void update_gfx(void*) {
    update_gfx_inner();
    g_main_stage = 0;
    if (!g_exit_requested) svcSleepThread(15 * 1000000ll);
}

void update_gfx_inner() {
    recomp3ds::stall_watch_beat();      // the main thread ran (stall_watch.cpp)
    g_main_stage = 1;
    recomp3ds::settings_menu_update();  // scans the pad
    g_main_stage = 2;
    recomp3ds::screen_flush();
    g_main_stage = 3;
    recomp3ds::input_motion_update();
    g_main_stage = 4;
    // HOME opens the rt64-3ds quick-quit prompt (above) rather than the HOME Menu.
    if (!g_home_trapped) {
        aptSetHomeAllowed(false);
        g_home_trapped = true;
    }
    if (!g_exit_requested && (aptCheckHomePressRejected() || recomp3ds::autotest_take_home())) {
        if (home_prompt()) g_exit_requested = true;
    }
    g_main_stage = 5;
    {
        // SELECT (the game has no use for it): a tap opens or closes the
        // settings menu; held for a second it saves a screenshot (with
        // dbg_capture=1 in settings.ini, a frame capture for the host
        // tools instead), and says so on the touch screen.
        // Ignore SELECT while L + D-Pad Down are held so opening Luma3DS's
        // Rosalina menu (L+Down+Select) does not toggle settings underneath.
        static u64 select_since = 0;
        static bool fired = false;
        const u32 hw_keys = recomp3ds::input_raw_held();
        const u32 all_keys = hw_keys | recomp3ds::autotest_keys();
        const bool rosalina_combo = update_rosalina_throttle(all_keys);
        if (rosalina_combo) {
            select_since = 0;
            fired = true;
        } else if (all_keys & KEY_SELECT) {
            const u64 now = svcGetSystemTick();
            if (select_since == 0) { select_since = now; fired = false; }
            else if (!fired && now - select_since > SYSCLOCK_ARM11) {
                fired = true;
                if (recomp3ds::settings_debug_capture()) {
                    rt64_3ds::request_capture();
                    recomp3ds::screen_printf("\x1b[28;0H%-39s", "Saving a frame capture...");
                }
                else {
                    rt64_3ds::request_screenshot();
                    recomp3ds::screen_printf("\x1b[28;0H%-39s", "Saving a screenshot...");
                }
                gfxFlushBuffers();
            }
        }
        else {
            if (select_since != 0 && !fired) recomp3ds::settings_menu_toggle();
            select_since = 0;
            fired = false;
        }
        // The capture writer's news: saving, progress, saved, refused (one
        // is still being written), failed or stalled.
        static int shown_seq = 0, shown_shot = 0;
        int seq = 0;
        const char* capture_line = rt64_3ds::capture_message(&seq);
        if (seq != shown_seq) {
            shown_seq = seq;
            recomp3ds::screen_printf("\x1b[28;0H%-39.39s", capture_line);
            gfxFlushBuffers();
        }
        const int shot = rt64_3ds::screenshot_state();
        if (shot >= 2 && shown_shot != shot) {
            char line[48];
            if (shot == 2) snprintf(line, sizeof(line), "Screenshot %s", rt64_3ds::screenshot_name());
            else snprintf(line, sizeof(line), "Screenshot failed");
            recomp3ds::screen_printf("\x1b[28;0H%-39.39s", line);
            gfxFlushBuffers();
        }
        shown_shot = shot;
    }
    g_main_stage = 6;
    // Once a second: frame rate and CPU load to the log and the touch screen.
    static u64 last_report = 0;
    u64 now = svcGetSystemTick();
    if (last_report == 0) {
        last_report = now;
    }
    else if (now - last_report >= SYSCLOCK_ARM11) {
        const u64 interval = now - last_report;
        last_report = now;
        const int busy0 = recomp3ds::loadmon_sample(0), busy1 = recomp3ds::loadmon_sample(1);
        const int busy2 = recomp3ds::loadmon_sample(2), busy3 = recomp3ds::loadmon_sample(3);
        const rt64_3ds::FrameStats& st = rt64_3ds::stats();
        // Audio microcode cost over the last second: ms of CPU and task count.
        unsigned ucode_ms = (unsigned)(g_ucode_ticks * 1000 / SYSCLOCK_ARM11);
        unsigned ucode_tasks = g_ucode_tasks;
        g_ucode_ticks = 0;
        g_ucode_tasks = 0;
        // Audio stall watchdog: tasks ran, then none for 2 s.
        {
            static bool seen = false, reported = false;
            static int idle = 0;
            if (ucode_tasks > 0) { seen = true; idle = 0; }
            else if (seen && !reported && ++idle >= 2) {
                reported = true;
                fprintf(stderr, "recomp3ds: AUDIO STALL: no audio task for 2 s\n");
                if (g_desc != nullptr && g_desc->on_audio_stall != nullptr && g_rdram != nullptr) g_desc->on_audio_stall(g_rdram);
                fflush(stderr);
            }
        }
        const recomp3ds::AudioCounters ac = recomp3ds::audio_take_counters();
        char game_stats[96] = "";
        if (g_desc != nullptr && g_desc->append_stats != nullptr && g_rdram != nullptr) {
            g_desc->append_stats(g_rdram, game_stats, sizeof(game_stats));
        }
        char rom_stats[96] = "";
        if (recomp3ds::rom_stream_active()) {
            uint32_t misses = 0, bytes = 0, waits = 0, wait_ms = 0, wait_max = 0;
            recomp3ds::rom_stream_take_stats(&misses, &bytes, &waits, &wait_ms, &wait_max);
            snprintf(rom_stats, sizeof(rom_stats), " rom %lu reads (%lu KB) waited %lu ms in %lu (max %lu)", (unsigned long)misses, (unsigned long)(bytes / 1024),
                     (unsigned long)wait_ms, (unsigned long)waits, (unsigned long)wait_max);
        }
        // The audio interpreter's unknown commands (and the differential
        // mode's mismatches, which only the host tool runs now): shown when
        // non-zero.
        char hle_stats[96] = "";
        {
            const recomp3ds::AudioHleStats& hs = g_audio_hle_family == recomp3ds::AudioHle::Aspmain ? recomp3ds::aspmain_hle_stats()
                                                                                                    : recomp3ds::naudio_hle_stats();
            if (hs.unknown_opcodes != 0 || hs.diff_mismatches != 0)
                snprintf(hle_stats, sizeof(hle_stats), " audio-hle unknown %lu mismatches %lu/%lu", (unsigned long)hs.unknown_opcodes,
                         (unsigned long)hs.diff_mismatches, (unsigned long)hs.diff_tasks);
            if (hs.inexact != 0) {
                const size_t used = strlen(hle_stats);
                snprintf(hle_stats + used, sizeof(hle_stats) - used, " inexact %lu", (unsigned long)hs.inexact);
            }
        }
        // The audio interpreter's time by command (aspMain), ms in the
        // interval: which of its loops a faster interpreter must target.
        std::string hle_ms;
        char hle_row[48] = "";
        if (g_audio_hle && g_audio_hle_family == recomp3ds::AudioHle::Aspmain) {
            static const char* const kOps[16] = { "nop", "adpcm", "clear", "envmix", "loadbuf", "resamp", "savebuf", "segment",
                                                  "setbuff", "setvol", "dmemmv", "loadadp", "mixer", "interlv", "polef", "setloop" };
            static uint32_t prev_ticks[16] = {};
            const recomp3ds::AudioHleStats& hs = recomp3ds::aspmain_hle_stats();
            unsigned ms[16], order[16];
            for (int i = 0; i < 16; i++) {
                ms[i] = (unsigned)((uint64_t)(uint32_t)(hs.op_ticks[i] - prev_ticks[i]) * 1000 / SYSCLOCK_ARM11);
                prev_ticks[i] = hs.op_ticks[i];
                order[i] = (unsigned)i;
            }
            for (int i = 1; i < 16; i++)      // by time, largest first
                for (int j = i; j > 0 && ms[order[j]] > ms[order[j - 1]]; j--) { const unsigned t = order[j]; order[j] = order[j - 1]; order[j - 1] = t; }
            size_t r = 0;
            for (int i = 0; i < 16 && ms[order[i]] > 0; i++) {
                hle_ms += (hle_ms.empty() ? " hle ms " : " ") + std::string(kOps[order[i]]) + " " + std::to_string(ms[order[i]]);
                if (i < 5 && r + 10 < sizeof(hle_row)) r += (size_t)snprintf(hle_row + r, sizeof(hle_row) - r, "%s%.2s%u", r ? " " : "hle ", kOps[order[i]], ms[order[i]]);
            }
        }
        // Each game thread's share of the interval and its wake-ups a second
        // (ultramodern's accounting at the thread switches): how much of
        // core 0 is the game's logic, its audio synthesizer, its scheduler;
        // what loadmon's core 0 figure has beyond the total is the host's
        // own threads and the switches themselves.
        std::string thread_stats;
        char thread_row[48] = "";
        {
            ultramodern::ThreadLoad loads[16];
            static ultramodern::ThreadLoad prev[16];
            static size_t prev_n = 0;
            const size_t n = ultramodern::get_thread_loads(loads, 16);
            const u64 span = interval != 0 ? interval : 1;
            unsigned total_pct = 0, total_wakes = 0;
            size_t r = 0;
            for (size_t i = 0; i < n; i++) {
                uint32_t ticks = loads[i].ticks, wakeups = loads[i].wakeups;
                for (size_t p = 0; p < prev_n; p++) {
                    if (prev[p].thread == loads[i].thread) { ticks -= prev[p].ticks; wakeups -= prev[p].wakeups; break; }
                }
                const unsigned pct = (unsigned)((u64)ticks * 100 / span);
                const unsigned wakes = (unsigned)((u64)wakeups * SYSCLOCK_ARM11 / span);
                total_pct += pct;
                total_wakes += wakes;
                if (pct == 0 && wakes == 0) continue;    // idle: left out
                std::string name = std::to_string(loads[i].thread);
                if (g_rdram != nullptr && g_desc != nullptr && g_desc->get_game_thread_name != nullptr) {
                    name = g_desc->get_game_thread_name(reinterpret_cast<const OSThread*>(g_rdram + (loads[i].thread & 0x7FFFFFFFu)));
                    if (name.rfind("[Game] ", 0) == 0) name.erase(0, 7);
                }
                thread_stats += (thread_stats.empty() ? " threads " : ", ") + name + " " + std::to_string(pct) + "% (" + std::to_string(wakes) + "/s)";
                if (r + 12 < sizeof(thread_row)) r += (size_t)snprintf(thread_row + r, sizeof(thread_row) - r, "%s%.5s %u", r ? " " : "", name.c_str(), pct);
            }
            if (n > 0) thread_stats += " = " + std::to_string(total_pct) + "%, " + std::to_string(total_wakes) + " wakes/s";
            if (r + 10 < sizeof(thread_row)) snprintf(thread_row + r, sizeof(thread_row) - r, " sw%u", total_wakes);
            memcpy(prev, loads, n * sizeof(loads[0]));
            prev_n = n;
        }
        char dsp_stats[256] = "";
        if (recomp3ds::dsp_synth_enabled()) {
            const recomp3ds::DspSynthStats ds = recomp3ds::dsp_synth_take_stats();
            snprintf(dsp_stats, sizeof(dsp_stats), " dsp-synth %lu playing, %lu starts, %lu events, busy %lu us (decode %lu, events %lu), %lu starved, %lu ms late, %lu remaps, %lu callbacks, %lu ndsp-dropped, reverb %lu us %lu gaps, %lu lists skipped",
                     (unsigned long)ds.playing, (unsigned long)ds.starts, (unsigned long)ds.events, (unsigned long)ds.decode_us,
                     (unsigned long)ds.decode_only_us, (unsigned long)ds.apply_us, (unsigned long)ds.starved, (unsigned long)ds.late,
                     (unsigned long)ds.remaps, (unsigned long)ds.callbacks, (unsigned long)ds.ndsp_dropped,
                     (unsigned long)ds.reverb_us, (unsigned long)ds.reverb_gaps, (unsigned long)ds.lists_skipped);
        }
        char want_fps[240] = "";
        if (st.game_fps > 0) snprintf(want_fps, sizeof(want_fps), ", game asks %d", st.game_fps);
        if (st.dl_skipped_per_sec > 0) {
            // The frame cap passed over some: how many were drawn.
            const size_t used = strlen(want_fps);
            snprintf(want_fps + used, sizeof(want_fps) - used, ", %d drawn, %d passed over", st.dl_per_sec - st.dl_skipped_per_sec, st.dl_skipped_per_sec);
        }
        if (rt64_3ds::settings().frame_cap == 2 && g_desc != nullptr && g_desc->render.frame_interpolation) {
            // Frame interpolation: frames shown, the in-betweens among them,
            // and the lists the game asked 30 for that got none.
            const size_t used = strlen(want_fps);
            snprintf(want_fps + used, sizeof(want_fps) - used, ", %d shown (%d in-between, %d without%s%s)", st.presented_per_sec, st.inbetween_per_sec,
                     st.inbetween_dropped_per_sec, st.inbetween_reasons[0] ? ": " : "", st.inbetween_reasons);
        }
        // log_level 1 logs the figures every 10 s, 0 not at all (log.cpp).
        static unsigned stats_tick = 0;
        stats_tick++;
        const int log_lv = recomp3ds::log_level();
        const bool log_stats = log_lv >= 2 || (log_lv == 1 && stats_tick % 10 == 0);
        // Core 2 when watched (not with two cores), and a New 3DS's core 3
        // when the system lets the application use it.
        char core2[16] = "", core3[16] = "";
        if (busy2 >= 0) snprintf(core2, sizeof(core2), " core2 %d%%", busy2);
        if (busy3 >= 0) snprintf(core3, sizeof(core3), " core3 %d%%", busy3);
        // The recomp heap (recomp_alloc, o1heap inside RDRAM at the fixed
        // heap_rdram_start without mods): what the game's patches take, for
        // sizing RECOMP_MEM_SIZE_MB (Dinosaur Planet's ReAsset).
        char rheap[64] = "";
#ifdef RECOMP_NO_MODS
        const uint32_t rheap_addr = (uint32_t)recomp::heap_rdram_start;
#else
        // With mods the heap sits above them: where the runtime put it
        // (librecomp heap_rdram_address, a runtime with that patch).
        const uint32_t rheap_addr = recomp::heap_rdram_address != nullptr ? recomp::heap_rdram_address() : 0;
#endif
        if (g_rdram != nullptr && rheap_addr != 0) {
            const O1HeapDiagnostics d = o1heapGetDiagnostics((const O1HeapInstance*)(g_rdram + (rheap_addr - 0x80000000u)));
            snprintf(rheap, sizeof(rheap), " rheap %lu/%lu KB (peak %lu, oom %lu)", (unsigned long)(d.allocated / 1024), (unsigned long)(d.capacity / 1024),
                     (unsigned long)(d.peak_allocated / 1024), (unsigned long)d.oom_count);
        }

        if (log_stats) fprintf(stderr, "stats: %d dl/s%s (late %d, max gap %.0f ms) core0 %d%% core1 %d%%%s%s ucode %u ms/s in %u tasks audio %zu frames queued, in %lu/s at %lu Hz, underruns %lu dropped %lu low water %lu heap %lu KB%s%s%s%s%s%s%s\n",
                st.dl_per_sec, want_fps, st.late_frames, st.max_gap_ms, busy0, busy1, core2, core3, ucode_ms, ucode_tasks, recomp3ds::audio_frames_queued(),
                (unsigned long)ac.submitted, (unsigned long)ac.rate, (unsigned long)ac.underruns, (unsigned long)ac.dropped, (unsigned long)(ac.low_water == 0xFFFFFFFFu ? 0u : ac.low_water),
                (unsigned long)(mallinfo().arena / 1024), rheap, hle_stats, hle_ms.c_str(), "", rom_stats, game_stats, thread_stats.c_str());
        // On a line of its own: the log cuts lines at 512 characters.
        if (log_stats && dsp_stats[0] != '\0') fprintf(stderr, "%s\n", dsp_stats + 1);
        // One 40-column row: frames drawn and each core's load.
        char line[64];
        // Frames drawn (the frame cap passes some over; frame interpolation
        // adds its in-betweens).
        const int shown_fps = rt64_3ds::settings().frame_cap == 2 && g_desc != nullptr && g_desc->render.frame_interpolation
                                  ? st.presented_per_sec : st.dl_per_sec - st.dl_skipped_per_sec;
        // All four cores (a New 3DS's core 3 when the system lets the
        // application use it) fit the row only as c0-c3.
        if (busy0 < 0) snprintf(line, sizeof(line), "%3d fps (cap %d fps)", shown_fps, rt64_3ds::settings().fps_cap);
        else if (busy2 >= 0 && busy3 >= 0) snprintf(line, sizeof(line), "%3d fps c0 %3d%% c1 %3d%% c2 %3d%% c3 %3d%%", shown_fps, busy0, busy1, busy2, busy3);
        else if (busy2 >= 0) snprintf(line, sizeof(line), "%3d fps cpu0 %3d%% cpu1 %3d%% cpu2 %3d%%", shown_fps, busy0, busy1, busy2);
        else snprintf(line, sizeof(line), "%3d fps cpu0 %3d%% cpu1 %3d%%", shown_fps, busy0, busy1);   // two cores
        recomp3ds::screen_printf("\x1b[2;0H%-39.39s\n", line);
        // settings.ini's dbg_rows=1: the game threads' shares (wake-ups a
        // second last) and the audio rows below.
        const bool debug_rows = recomp3ds::settings_debug_rows();
        if (debug_rows) recomp3ds::screen_printf("\x1b[3;0H%-39.39s", thread_row);
        // The audio pipeline's counters: tasks run a second, frames the game
        // handed over a second against the rate, frames the DSP still holds,
        // underruns and frames dropped for a full ring or stale-queue recovery.
        // lw: the fewest frames the DSP held when a buffer arrived (near 0:
        // it ran short); q: frames queued now; ur: underruns caught.
        const unsigned long low_water = ac.low_water == 0xFFFFFFFFu ? 0ul : (unsigned long)ac.low_water;
        snprintf(line, sizeof(line), "aud %ut in %lu q %zu lw %lu ur %lu", ucode_tasks, (unsigned long)ac.submitted,
                 recomp3ds::audio_frames_queued(), low_water, (unsigned long)ac.underruns);
        if (debug_rows) {
            recomp3ds::screen_printf("\x1b[27;0H%-39.39s", line);
            recomp3ds::screen_printf("\x1b[29;0H%-39.39s", hle_row);   // the interpreter's ms a second by command
        }
    }
    // Watchdog: a frame that stays in the replay or the GPU wait for 4 s is
    // a hung GPU; say which draw it was on, once.
    g_main_stage = 7;
    {
        static u32 last_frames = 0; static u64 since = 0; static bool reported = false;
        const rt64_3ds::Progress& pg = rt64_3ds::progress();
        if (pg.frames != last_frames || pg.phase == 0 || pg.phase == 1) { last_frames = pg.frames; since = now; }
        else if (!reported && since != 0 && now - since > 4ull * SYSCLOCK_ARM11) {
            reported = true;
            fprintf(stderr, "recomp3ds: WATCHDOG: no frame for 4 s\n");
            rt64_3ds::dump_progress();
        }
    }
    g_main_stage = 8;
    if (g_exit_requested || !aptMainLoop()) {
        fprintf(stderr, "recomp3ds: quitting\n");
        recomp3ds::audio_set_paused(true);
        rt64_3ds::wait_idle_for_exit();
        finish_exit();
    }
}

// The runtime shows a message box just before it quits, so everything logged
// goes onto the card now: the exit that follows may not get that far.
void message_box(const char* msg) {
    fprintf(stderr, "[message] %s\n", msg);
    recomp3ds::screen_printf("\n%s\n", msg);
    recomp3ds::log_flush();
}

std::string game_thread_name(const OSThread* t) {
    if (g_desc != nullptr && g_desc->get_game_thread_name != nullptr) {
        return g_desc->get_game_thread_name(t);
    }
    return "Game Thread " + std::to_string(t->id);
}

std::unique_ptr<ultramodern::renderer::RendererContext>
make_render_context(uint8_t* rdram, ultramodern::renderer::WindowHandle handle, bool developer_mode) {
    if (g_desc != nullptr && g_desc->null_renderer) {
        return rt64_3ds::create_null_render_context(rdram, handle, developer_mode);
    }
    return rt64_3ds::create_render_context(rdram, handle, developer_mode);
}

// libctru splits the process's memory between the application heap and the
// linear heap at start (a weak function, replaced here). Its default gives
// the linear heap up to 32 MB and caps the application heap at 24 MB when
// memory is short: on an Old 3DS (64 MB) that leaves no room for the N64's
// RDRAM beside everything else. Here the linear heap (what does not fit in
// VRAM, the draw lists, audio buffers: under 8 MB in use in DK64) gets
// 32 MB when there is plenty, as before on a New 3DS, and 16 MB otherwise;
// the application heap gets the rest.
extern "C" char* fake_heap_start;
extern "C" char* fake_heap_end;
extern "C" u32 __ctru_heap, __ctru_heap_size, __ctru_linear_heap, __ctru_linear_heap_size;
extern "C" void __system_allocateHeaps(void) {
    Handle reslimit = 0;
    if (R_FAILED(svcGetResourceLimit(&reslimit, CUR_PROCESS_HANDLE))) svcBreak(USERBREAK_PANIC);
    s64 max_commit = 0, current_commit = 0;
    ResourceLimitType type = RESLIMIT_COMMIT;
    svcGetResourceLimitLimitValues(&max_commit, reslimit, &type, 1);
    svcGetResourceLimitCurrentValues(&current_commit, reslimit, &type, 1);
    svcCloseHandle(reslimit);
    const u32 remaining = (u32)(max_commit - current_commit) & ~0xFFFu;
#ifdef RT64_3DS_LINEAR_HEAP_MB
    // The game's own choice (CMake RT64_3DS_LINEAR_HEAP_MB): Dinosaur Planet
    // takes 16 MB so its 64 MB ROM fits the application heap beside RDRAM.
    __ctru_linear_heap_size = (u32)RT64_3DS_LINEAR_HEAP_MB << 20;
    if (__ctru_linear_heap_size > remaining / 2) __ctru_linear_heap_size = remaining / 2;
#else
    __ctru_linear_heap_size = remaining >= (96u << 20) ? (32u << 20) : (16u << 20);
#endif
    __ctru_heap_size = remaining - __ctru_linear_heap_size;
    if (R_FAILED(svcControlMemory(&__ctru_heap, OS_HEAP_AREA_BEGIN, 0x0, __ctru_heap_size, MEMOP_ALLOC, (MemPerm)(MEMPERM_READ | MEMPERM_WRITE)))) svcBreak(USERBREAK_PANIC);
    if (R_FAILED(svcControlMemory(&__ctru_linear_heap, 0x0, 0x0, __ctru_linear_heap_size, MEMOP_ALLOC_LINEAR, (MemPerm)(MEMPERM_READ | MEMPERM_WRITE)))) svcBreak(USERBREAK_PANIC);
    mappableInit(OS_MAP_AREA_BEGIN, OS_MAP_AREA_END);
    fake_heap_start = (char*)__ctru_heap;
    fake_heap_end = fake_heap_start + __ctru_heap_size;
}

void log_memory(const char* when) {
    // The memory the process got: libctru gives all of it, less the
    // executable, to the two heaps at start, so heap + linear heap + the
    // executable is the memory mode (64, 96, 124 MB...). The region's own
    // size says the same on the console (Azahar reports 96 MB there while
    // handing out 124 MB), and its free space reads 0 after the split.
    const struct mallinfo mi = mallinfo();
    fprintf(stderr, "recomp3ds: %s: heap %lu KB + linear heap %lu KB (%s; app region %lu KB); heap in use %lu KB (%lu KB taken), linear free %lu KB\n", when,
            (unsigned long)(envGetHeapSize() / 1024), (unsigned long)(envGetLinearHeapSize() / 1024),
            envIsHomebrew() ? ".3dsx" : "title",
            (unsigned long)(osGetMemRegionSize(MEMREGION_APPLICATION) / 1024),
            (unsigned long)(mi.uordblks / 1024), (unsigned long)(mi.arena / 1024),
            (unsigned long)(linearSpaceFree() / 1024));
}

// The CPU clock, from a loop of single-cycle ALU ops timed against the system
// tick (268 MHz whatever the CPU runs at). Best of three to ride out preemption.
u32 measure_cpu_mhz() {
    constexpr u32 kIters = 100000, kOpsPerIter = 64 + 2;
    u64 best = UINT64_MAX;
    for (int run = 0; run < 3; run++) {
        u32 n = kIters, a = 0;
        u64 t0 = svcGetSystemTick();
        __asm__ volatile(
            "1:\n"
            ".rept 64\n"
            "add %1, %1, #1\n"
            ".endr\n"
            "subs %0, %0, #1\n"
            "bne 1b\n"
            : "+r"(n), "+r"(a) : : "cc");
        u64 ticks = svcGetSystemTick() - t0;
        if (ticks < best) best = ticks;
    }
    return (u32)((u64)kIters * kOpsPerIter * (SYSCLOCK_ARM11 / 1000) / best / 1000);
}

// Average latency of a dependent load walk over 1 MB: slow from FCRAM, far
// quicker when the New 3DS L2 cache (2 MB) is on.
u32 measure_load_ns() {
    constexpr u32 kNodes = (1024 * 1024) / 32, kHops = 100000;
    u32* buf = static_cast<u32*>(malloc(kNodes * 32));
    u32* order = static_cast<u32*>(malloc(kNodes * sizeof(u32)));
    if (buf == nullptr || order == nullptr) { free(buf); free(order); return 0; }
    // One random cycle through all nodes, 32 bytes (one cache line) apart.
    for (u32 i = 0; i < kNodes; i++) order[i] = i;
    u32 seed = 12345;
    for (u32 i = kNodes - 1; i > 0; i--) {
        seed = seed * 1103515245u + 12345u;
        u32 j = (seed >> 8) % (i + 1);
        u32 t = order[i]; order[i] = order[j]; order[j] = t;
    }
    for (u32 i = 0; i < kNodes; i++) {
        buf[order[i] * 8] = order[(i + 1) % kNodes] * 8;
    }
    free(order);
    u32 p = 0;
    for (u32 i = 0; i < kNodes; i++) p = buf[p];    // warm up
    u64 t0 = svcGetSystemTick();
    for (u32 i = 0; i < kHops; i++) p = buf[p];
    u64 ticks = svcGetSystemTick() - t0;
    volatile u32 sink = p; (void)sink;
    free(buf);
    return (u32)(ticks * 1000000000ull / SYSCLOCK_ARM11 / kHops);
}

u32 log_cpu(const char* when) {
    u32 mhz = measure_cpu_mhz();
    // loadmon's calibrations hold at the clock they were taken at: the
    // two clocks are 268 and 804 MHz (exactly 1:3).
    recomp3ds::loadmon_set_mhz(mhz > 500 ? 804 : 268);
    fprintf(stderr, "recomp3ds: %s: CPU ~%lu MHz, 1 MB load walk %lu ns/load\n", when,
            (unsigned long)mhz, (unsigned long)measure_load_ns());
    return mhz;
}

// The New 3DS clock and L2 cache (settings menu: CPU speed). Off, a New 3DS
// runs at an Old 3DS's 268 MHz without L2 - the CPU side of an Old 3DS,
// though it keeps the fourth core and the memory.
bool g_speedup = true;
bool g_clock_booted = false;

}   // namespace

void recomp3ds::set_cpu_speed(bool new3ds) {
    g_speedup = new3ds;
    if (!g_clock_booted) return;       // run() applies the saved choice at boot
    osSetSpeedupEnable(new3ds);
    log_cpu(new3ds ? "CPU speed set to New 3DS" : "CPU speed set to Old 3DS");
}

const char* recomp3ds::base_path() { return g_base_path; }

void recomp3ds::request_exit() { g_exit_requested = true; }



// A termination reporter, installed before any host thread exists.
//
// An exception that escapes a host thread - a std::filesystem call the
// firmware declined, a std::bad_alloc from the small heap - lands in
// std::terminate, which prints to a console nobody is watching and calls
// abort. devkitARM's abort runs the C++ exit path, so libctru's __appExit
// tears the services down (closing handles and unmapping the HID shared
// memory) while the game, the renderer, the audio task and the ROM reader are
// still running. Those threads fault a moment later on the freed state, and the
// crash dump names a libctru function instead of the code that threw. Reporting
// here and ending the process at once keeps the log honest.
namespace {

[[noreturn]] void report_termination_and_exit() {
    std::fprintf(stderr, "recomp3ds: fatal: terminating\n");
    if (const auto e = std::current_exception()) {
        try {
            std::rethrow_exception(e);
        } catch (const std::filesystem::filesystem_error& fe) {
            std::fprintf(stderr, "recomp3ds:   uncaught filesystem_error: %s\n", fe.what());
            std::fprintf(stderr, "recomp3ds:     path1=%s path2=%s\n",
                fe.path1().string().c_str(), fe.path2().string().c_str());
        } catch (const std::exception& ex) {
            std::fprintf(stderr, "recomp3ds:   uncaught exception: %s\n", ex.what());
        } catch (...) {
            std::fprintf(stderr, "recomp3ds:   uncaught exception of an unknown type\n");
        }
    } else {
        std::fprintf(stderr, "recomp3ds:   no exception was in flight (abort/assert?)\n");
    }
    std::fflush(stderr);
    std::fflush(stdout);
    // Not exit(): that is the path that frees the services other threads use.
    svcExitProcess();
    __builtin_unreachable();
}

}  // namespace

int recomp3ds::run(const GameDesc& desc) {
    g_desc = &desc;

    // Keep the main UI / APT thread (which sleeps 15 ms per pass) above the
    // N64 game threads (0x30) on Core 0: Horizon OS does not time-slice equal
    // priorities, so at 0x30 a busy game thread starved main in sleep and
    // froze the bottom-screen settings menu and HOME button handling.
    svcSetThreadPriority(CUR_THREAD_HANDLE, 0x28);
    aptSetHomeAllowed(false);

    gfxInitDefault();
    consoleInit(GFX_BOTTOM, nullptr);          // status text on the touch screen (screen_printf)
    recomp3ds::screen_init();
    if (__3dslink_host.s_addr != 0) {
        link3dsStdio();
    }
    snprintf(g_base_path, sizeof(g_base_path), "sdmc:/3ds/%s", desc.sd_dir);
    mkdir(g_base_path, 0777);
    recomp3ds::log_init(g_base_path);          // stderr: debug log + <base>/log.txt
    std::set_terminate([] { report_termination_and_exit(); });
    recomp3ds::autotest_load(g_base_path);
    bool is_new_3ds = false;
    APT_CheckNew3DS(&is_new_3ds);
    fprintf(stderr, "recomp3ds: %s starting on %s 3DS\n", desc.render.game_name, is_new_3ds ? "a New" : "an Old");
    recomp3ds::screen_printf("%s\n", desc.render.game_name);
    log_memory("boot");
    // Before the settings: a loaded setting's on_change may pick another map.
    recomp3ds::input_set_map(desc.button_map, desc.button_map_count);
    recomp3ds::input_set_controller_pak(desc.controller_pak);
    recomp3ds::settings_menu_init(g_base_path, desc);
    {
        // dbg_slow_gfx_ms / dbg_slow_audio_ms: pad every display list and
        // audio task, to mimic a slower console in the emulator.
        const recomp3ds::DebugSettings& dbg = recomp3ds::debug_settings();
        if (dbg.slow_gfx_ms > 0 || dbg.slow_audio_ms > 0) {
            g_slow_audio_ms = dbg.slow_audio_ms;
            rt64_3ds::set_debug_gfx_delay_ms(dbg.slow_gfx_ms);
            fprintf(stderr, "recomp3ds: dbg_slow: +%d ms per display list, +%d ms per audio task\n", dbg.slow_gfx_ms, dbg.slow_audio_ms);
        }
    }
    {
        // The ROM in memory, or read from the SD card as the game needs it:
        // the game's choice for this console (GameDesc::rom_new3ds /
        // rom_old3ds), unless settings.ini's rom_stream says (1 in memory, 2
        // from the SD card). Auto holds it when the heap has room for it
        // beside RDRAM and what the rest of the port takes
        // (GameDesc::rom_room_mb, the game's measured figure), else streams.
        const int mode = recomp3ds::settings_rom_stream();
        const recomp3ds::GameDesc::RomPlace place = is_new_3ds ? desc.rom_new3ds : desc.rom_old3ds;
        char rom_path[192];
        snprintf(rom_path, sizeof(rom_path), "%s/%s", g_base_path, (const char*)desc.entry.stored_filename().c_str());
        struct stat rom_st;
        const uint64_t rom_bytes = stat(rom_path, &rom_st) == 0 ? (uint64_t)rom_st.st_size : (32u << 20);
        const uint64_t room = (uint64_t)(desc.rom_room_mb > 0 ? desc.rom_room_mb : 24) << 20;
        const uint64_t need = rom_bytes + recomp::mem_size + room;
        const uint64_t heap = envGetHeapSize();
        const bool heap_short = heap < need;
        using RomPlace = recomp3ds::GameDesc::RomPlace;
        const bool stream = mode == 2 || (mode == 0 && (place == RomPlace::Stream || (place == RomPlace::Auto && heap_short)));
        if (stream) recomp3ds::rom_stream_install((size_t)desc.rom_cache_mb << 20, (size_t)desc.rom_block_kb << 10);
        const char* why = mode != 0 ? ", settings.ini"
                        : place != RomPlace::Auto ? ", the game's choice"
                        : heap_short ? ", auto: the heap is short" : ", auto: it fits";
        fprintf(stderr, "recomp3ds: ROM %s (rom_stream %d%s): heap %lu MB, ROM %lu + RDRAM %lu + room %lu = %lu MB\n",
                stream ? "read from the SD card as needed" : "held in memory", mode, why,
                (unsigned long)(heap >> 20), (unsigned long)(rom_bytes >> 20), (unsigned long)(recomp::mem_size >> 20),
                (unsigned long)(room >> 20), (unsigned long)(need >> 20));
        if (!stream && heap_short)
            fprintf(stderr, "recomp3ds: the ROM held in a heap %lu MB short of the game's need: expect failed allocations\n",
                    (unsigned long)((need - heap + (1u << 20) - 1) >> 20));
    }
    u32 cpu_mhz = log_cpu("boot");
    g_clock_booted = true;
    if (is_new_3ds && g_speedup) {
        // The exheader asks for 804 MHz and the L2 cache, but on hardware the
        // CIA still starts at 268 MHz without L2 (measured: 271 MHz, 230 ns
        // loads; 816 MHz, 33 ns after this). libctru re-applies it after
        // every HOME Menu visit.
        osSetSpeedupEnable(true);
        cpu_mhz = log_cpu("after speedup request");
    }
    {
        char sub[160];
        snprintf(sub, sizeof(sub), "%s/saves", g_base_path);
        mkdir(sub, 0777);
    }
    recomp::register_config_path(std::filesystem::path(g_base_path));

    const int audio_margin_override = recomp3ds::settings_audio_margin_override();
    const int audio_queue_override = recomp3ds::settings_audio_max_queued_override();
    const int audio_margin = audio_margin_override < 0 ? desc.audio_margin_frames : audio_margin_override;
    const uint32_t audio_queue_ms = audio_queue_override < 0 ? desc.audio_max_queued_ms : (uint32_t)audio_queue_override;
    recomp3ds::audio_set_margin_frames(audio_margin);
    recomp3ds::audio_set_max_queued_ms(audio_queue_ms);
    fprintf(stderr, "recomp3ds: audio policy: margin %d video frames, max NDSP queue %lu ms (0 disables)\n",
            audio_margin, (unsigned long)audio_queue_ms);
    recomp3ds::audio_init();
    rt64_3ds::set_render_desc(desc.render);
    rt64_3ds::set_data_dir(g_base_path);   // the renderer's debug switches and captures

    // The runtime looks for <config>/<entry.stored_filename()>; put the ROM
    // there by that name (baserom.z64 when the entry overrides the default).
    // The game's init runs after the runtime's last mod scan and just before
    // the mods load: the built-in mods' saved state goes in there first.
    {
        recomp::GameEntry entry = desc.entry;
        g_game_on_init = entry.on_init_callback;
        entry.on_init_callback = [](uint8_t* rdram, recomp_context* ctx) {
            g_rdram = rdram;
            recomp3ds::settings_apply_mods();
            if (g_game_on_init != nullptr) g_game_on_init(rdram, ctx);
        };
        recomp::register_game(entry);
    }
    if (desc.register_overlays) {
        desc.register_overlays();
    }
    if (desc.register_patches) {
        desc.register_patches();
    }
    // Hashes <config>/<game_id>.z64 and marks the game valid; is_rom_valid
    // only reads that set. (A ROM with the wrong hash is deleted by this.)
    recomp::check_all_stored_roms();

    ultramodern::renderer::callbacks_t renderer_callbacks{};
    renderer_callbacks.create_render_context = make_render_context;

    ultramodern::audio_callbacks_t audio_callbacks{};
    audio_callbacks.queue_samples = recomp3ds::audio_queue_samples;
    audio_callbacks.get_frames_remaining = recomp3ds::audio_frames_remaining;
    audio_callbacks.set_frequency = recomp3ds::audio_set_frequency;

    ultramodern::input::callbacks_t input_callbacks{};
    input_callbacks.poll_input = recomp3ds::input_poll;
    input_callbacks.get_input = recomp3ds::input_get;
    input_callbacks.set_rumble = recomp3ds::input_set_rumble;
    input_callbacks.get_connected_device_info = recomp3ds::input_device_info;

    ultramodern::gfx_callbacks_t gfx_callbacks{};
    gfx_callbacks.create_gfx = create_gfx;
    gfx_callbacks.create_window = create_window;
    gfx_callbacks.update_gfx = update_gfx;

    ultramodern::events::callbacks_t events_callbacks{};
    ultramodern::error_handling::callbacks_t error_callbacks{};
    error_callbacks.message_box = message_box;
    ultramodern::threads::callbacks_t threads_callbacks{};
    threads_callbacks.get_game_thread_name = game_thread_name;

    recomp::Configuration cfg{};
    cfg.project_version = desc.project_version;
    cfg.rsp_callbacks = desc.rsp;
    // Time the audio microcode: the game's callback hands back the ucode
    // function and this trampoline runs it under the tick counter.
    g_game_get_ucode = desc.rsp.get_rsp_microcode;
    g_audio_hle = desc.audio_hle;
    ultramodern::set_async_audio_tasks(desc.audio_async);
    g_audio_hle_family = desc.audio_hle_family;
    recomp3ds::naudio_hle_set_variant(desc.audio_hle_variant);
    if (g_game_get_ucode != nullptr) {
        cfg.rsp_callbacks.get_rsp_microcode = timed_get_ucode;
    }
    cfg.renderer_callbacks = renderer_callbacks;
    cfg.audio_callbacks = audio_callbacks;
    cfg.input_callbacks = input_callbacks;
    cfg.gfx_callbacks = gfx_callbacks;
    cfg.events_callbacks = events_callbacks;
    cfg.error_handling_callbacks = error_callbacks;
    cfg.threads_callbacks = threads_callbacks;
    cfg.message_queue_control.requeue_timer = false;
    cfg.synchronous_rsp_tasks = desc.synchronous_rsp_tasks;

    if (!recomp::is_rom_valid(desc.game_id)) {
        recomp3ds::screen_printf("\nROM not found or wrong hash.\nPut it at %s/%s\n\nPress START to exit.\n",
               g_base_path, (const char*)desc.entry.stored_filename().c_str());
        fprintf(stderr, "recomp3ds: no valid ROM at %s/%s\n", g_base_path, (const char*)desc.entry.stored_filename().c_str());
        while (aptMainLoop()) {
            hidScanInput();
            if (hidKeysDown() & KEY_START) break;
            gfxFlushBuffers(); gfxSwapBuffers(); gspWaitForVBlank();
        }
        gfxExit();
        return 1;
    }

    // The audio microcode interpreter shares core 2 with the renderer and
    // outranks it there, so every audio task stalls a frame. Core 1 (the
    // system core, time-limited for applications) takes it when available.
    // The game's N64 threads go to core 1 and the renderer, the audio task
    // and the DSP synthesizer to core 0 on an Old 3DS, which has no core 2:
    // the renderer is the larger load, and core 0 is the core the system
    // does not share. Goemon at the Old clock with two cores drew 17.5
    // frames a second with the renderer squeezed into core 1's share and
    // 24.4 swapped (three cores: 26.9; New 3DS, CPU speed Old 3DS,
    // 2026-10-03). The Cores row (settings.ini cores, read at start) picks
    // that layout on a New 3DS too, to test an Old 3DS on one.
    {
        (void)cpu_mhz;
        const int cores_row = recomp3ds::settings_cores();
        const bool two_cores = !is_new_3ds || cores_row != 0;
        const bool core2 = !two_cores;
        // With two cores, which one the game gets (GameDesc::two_cores_game_on_core0).
        const bool game_on_0 = cores_row == 2 || (cores_row == 0 && desc.two_cores_game_on_core0);
        g_has_core2 = core2;
        g_sp_core = core2 ? 2 : 0;
        g_gfx_core = core2 ? 2 : 0;
        g_watch_cores = core2 ? 0x5 : 0x1;
        {
            // New 3DS puts the renderer on dedicated Core 2 and only runs ~8%
            // audio on Core 1, so capping Core 1 at <= 30% keeps Luma3DS's
            // Rosalina menu responsive at zero FPS cost.
            // Old 3DS has no Core 2 and runs the renderer + audio task + synth
            // together on Core 1: it needs the full 80% Core 1 ceiling during
            // gameplay (~18% audio + ~62% renderer), and drops to 30% on the
            // fly whenever L + D-Pad Down are held for Rosalina.
            u32 limit = 0;
            Result rc = -1;
            static const u32 kTryNew3ds[] = { 30, 25, 20 };
            static const u32 kTryOld3ds[] = { 80, 70, 60, 50, 40, 30, 25, 20 };
            if (core2) {
                for (u32 pct : kTryNew3ds) {
                    rc = APT_SetAppCpuTimeLimit(pct);
                    if (R_SUCCEEDED(rc)) break;
                }
            } else {
                for (u32 pct : kTryOld3ds) {
                    rc = APT_SetAppCpuTimeLimit(pct);
                    if (R_SUCCEEDED(rc)) break;
                }
            }
            APT_GetAppCpuTimeLimit(&limit);
            if (limit > 0) g_core1_normal_limit = limit;
            Thread probe = R_SUCCEEDED(rc) ? threadCreate([](void*) {}, nullptr, 4096, 0x30, 1, false) : nullptr;
            if (probe != nullptr) {
                threadJoin(probe, UINT64_MAX);
                threadFree(probe);
                g_core1_granted = true;
                g_watch_cores |= 0x2;
                if (core2) g_sp_core = 1;               // the audio task beside the renderer's core
                else if (game_on_0) g_gfx_core = g_sp_core = 1;   // two cores: the rest on core 1
                else g_game_core = 1;                   // two cores: the game on core 1
            }
            // Without time on core 1 everything shares core 0.
            g_helper_core = (core2 || game_on_0) && g_core1_granted ? 1 : 0;
            fprintf(stderr, "recomp3ds: core 1 time limit %lu%% (rc %08lx); %s: game on core %d, audio task on core %d, renderer on core %d, synth on core %d\n",
                    (unsigned long)limit, (unsigned long)rc, core2 ? "three cores" : "two cores",
                    g_game_core, g_sp_core, g_gfx_core, g_helper_core);
        }
        if (is_new_3ds) {
            // Core 3 is the system's (head tracking and other services): an
            // application's threads are refused there. Logged as evidence.
            // A .3dsx from the Homebrew Launcher was allowed (2026-10-03):
            // loadmon then watches it too, its calibration showing how much
            // of it the system leaves (against core 0's).
            Thread probe3 = threadCreate([](void*) {}, nullptr, 4096, 0x30, 3, false);
            fprintf(stderr, "recomp3ds: a thread on core 3: %s\n", probe3 != nullptr ? "created" : "refused");
            if (probe3 != nullptr) { threadJoin(probe3, UINT64_MAX); threadFree(probe3); g_core3 = true; g_watch_cores |= 0x8; }
        }
        // The renderer's own core-1 helper (the in-between builder) is a
        // New 3DS's extra: none when core 2 is left out.
        rt64_3ds::settings().no_core2 = two_cores;
        // GameDesc::two_cores_read_on_game_core: the lists' read on core 0
        // with the game, the renderer on core 1.
        rt64_3ds::settings().read_core = (two_cores && desc.two_cores_read_on_game_core && g_game_core == 0 && g_gfx_core == 1) ? 0 : -1;
        // Just below the game's threads (host_thread_spec): they go first.
        rt64_3ds::settings().read_priority = 0x31;
        ultramodern::set_host_thread_spec_callback(host_thread_spec);
    }
    // The DSP synthesizer's decoding thread wants core 1, granted just above.
    if (desc.synth.flavor != recomp3ds::SynthFlavor::None) recomp3ds::dsp_synth_init(desc.synth);
    // The game's own audio (GameDesc::on_audio_ready): the first ndsp channel
    // the platform leaves free, above the AI stream's (0) and the synth's.
    if (desc.on_audio_ready != nullptr) {
        const int first_free = desc.synth.flavor != recomp3ds::SynthFlavor::None ? 24 - desc.synth.reserve_channels : 1;
        desc.on_audio_ready(first_free);
    }
    {
        // Debug: the FPU control state threads start with (rounding mode in
        // bits 22-23, flush-to-zero in bit 24, default NaN in bit 25).
        u32 main_fpscr; __asm__ volatile("vmrs %0, fpscr" : "=r"(main_fpscr));
        static volatile u32 thread_fpscr = 0;
        Thread t = threadCreate([](void*) { u32 v; __asm__ volatile("vmrs %0, fpscr" : "=r"(v)); thread_fpscr = v; }, nullptr, 4096, 0x30, 0, false);
        if (t) { threadJoin(t, UINT64_MAX); threadFree(t); }
        fprintf(stderr, "recomp3ds: FPSCR main %08lx, new thread %08lx\n", (unsigned long)main_fpscr, (unsigned long)thread_fpscr);
    }
    // The game or one of its game modes (with the mod system).
    recomp3ds::game_modes_init(g_base_path, desc);
    const std::string game_mode = recomp3ds::pick_game_mode(desc);
    recomp3ds::game_mode_begin(desc, game_mode);
    if (!game_mode.empty() && recomp::get_rom_stream() == nullptr) {
        // The mode's ROM is streamed from the card; the game's needs no room either.
        recomp3ds::rom_stream_install((size_t)desc.rom_cache_mb << 20, (size_t)desc.rom_block_kb << 10);
    }
    recomp::start_game(desc.game_id, game_mode);
    // Only spin idle calibration/load-monitor threads when debug rows are
    // requested: spinning Core 1 at 100% interferes with Luma3DS Rosalina.
    if (recomp3ds::settings_debug_rows()) {
        recomp3ds::loadmon_start(g_watch_cores);
    }
    recomp3ds::stall_watch_start(&g_rdram, &desc);
    log_memory("before start");
    recomp3ds::log_start_writer();
    recomp::start(cfg);        // returns when the game has quit
    log_memory("after exit");
    finish_exit();
}
