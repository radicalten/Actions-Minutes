#!/usr/bin/env python3
"""
post_recomp_patches.py — idempotent post-N64Recomp optimizer for DKR-3DS.

Applies three deterministic transformations to RecompiledFuncs/ so Diddy Kong
Racing compiles with RECOMP_GPR32=1, RECOMP_VOLATILE_RDRAM=1, and native ARM11
VFP frustum culling on Nintendo 3DS:

  1. Adds `__restrict` to `(uint8_t* __restrict rdram, recomp_context* __restrict ctx)`
     across `funcs.h` and `funcs_*.c` (paired with RECOMP_VOLATILE_RDRAM=1 so
     GCC keeps MIPS registers in ARM11/VFP registers across RDRAM stores while
     preserving volatile RDRAM polling).
  2. Rewrites the 10 `$ra` stack save/restore `SD`/`LD` pairs in `funcs_19.c`
     into 32-bit `MEM_W` operations so no generated function stores a 64-bit
     GPR via `SD`/`LD`.
  3. Redirects `rand_range`, `atan2s` (`funcs_19.c`), `dmacopy_doubleword`
     (`funcs_20.c`), and `block_visible` (`funcs_8.c`) to native `-O3`
     ARM11/VFP implementations in `platform/3ds/recomp_api_3ds.cpp`, allowing
     `rt64_3ds_check_gpr32` to pass with zero 64-bit GPR instructions across
     all 24 generated files while eliminating ~168 soft-float int64 conversions
     per level-segment AABB test.
"""

import glob
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RECOMP_DIR = os.path.join(ROOT, "RecompiledFuncs")

NATIVE_REDIRECTS = {
    "funcs_8.c": [
        ("block_visible", "dkr_block_visible"),
    ],
    "funcs_19.c": [
        ("rand_range", "dkr_rand_range"),
        ("atan2s", "dkr_atan2s"),
    ],
    "funcs_20.c": [
        ("dmacopy_doubleword", "dkr_dmacopy_doubleword"),
    ],
}


def add_restrict(text: str) -> str:
    return text.replace(
        "(uint8_t* rdram, recomp_context* ctx)",
        "(uint8_t* __restrict rdram, recomp_context* __restrict ctx)",
    )


def rewrite_ra_sd_ld(text: str) -> str:
    text = text.replace(
        "    SD(ctx->r31, 0X0, ctx->r29);",
        "    MEM_W(0X0, ctx->r29) = S32(ctx->r31) >> 31; MEM_W(0X4, ctx->r29) = ctx->r31;",
    )
    text = text.replace(
        "    ctx->r31 = LD(ctx->r29, 0X0);",
        "    ctx->r31 = MEM_W(0X4, ctx->r29);",
    )
    return text


def redirect_function(text: str, func_name: str, native_name: str) -> tuple[str, bool]:
    marker = f"/* @dkr3ds-native: {native_name} */"
    if marker in text:
        return text, False

    decl = f"extern void {native_name}(uint8_t* __restrict rdram, recomp_context* __restrict ctx);\n"
    sig_re = re.compile(
        rf"RECOMP_FUNC void {re.escape(func_name)}\(uint8_t\*\s*(?:__restrict\s+)?rdram,\s*recomp_context\*\s*(?:__restrict\s+)?ctx\)\s*\{{"
    )
    m = sig_re.search(text)
    if not m:
        raise RuntimeError(f"Could not find {func_name} in expected file")

    end_idx = text.find("\n;}", m.end())
    if end_idx == -1:
        raise RuntimeError(f"Could not find end ';}}' of {func_name}")
    end_idx += len("\n;}")

    replacement = (
        f"{decl}"
        f"RECOMP_FUNC void {func_name}(uint8_t* __restrict rdram, recomp_context* __restrict ctx) {{\n"
        f"    {marker}\n"
        f"    {native_name}(rdram, ctx);\n"
        f";}}"
    )
    return text[: m.start()] + replacement + text[end_idx:], True


def main() -> int:
    if not os.path.isdir(RECOMP_DIR):
        print(f"error: {RECOMP_DIR} not found", file=sys.stderr)
        return 1

    patched_files = 0
    funcs_h = os.path.join(RECOMP_DIR, "funcs.h")
    if os.path.exists(funcs_h):
        orig = open(funcs_h, "r", encoding="utf-8").read()
        updated = add_restrict(orig)
        if updated != orig:
            open(funcs_h, "w", encoding="utf-8").write(updated)
            patched_files += 1

    for path in sorted(glob.glob(os.path.join(RECOMP_DIR, "funcs_*.c"))):
        fname = os.path.basename(path)
        orig = open(path, "r", encoding="utf-8").read()
        updated = add_restrict(orig)
        if fname == "funcs_19.c":
            updated = rewrite_ra_sd_ld(updated)
        for func_name, native_name in NATIVE_REDIRECTS.get(fname, []):
            updated, _ = redirect_function(updated, func_name, native_name)
        if updated != orig:
            open(path, "w", encoding="utf-8").write(updated)
            patched_files += 1

    print(f"post_recomp_patches.py: updated {patched_files} file(s) in {RECOMP_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
