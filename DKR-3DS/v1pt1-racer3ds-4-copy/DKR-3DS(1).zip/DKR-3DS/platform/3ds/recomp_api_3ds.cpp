// Native ARM11 / VFP fast paths and 64-bit leaf helpers for DKR-3DS.
//
// Replacing the three tiny 64-bit assembly helpers (rand_range, atan2s,
// dmacopy_doubleword) lets all 24 generated RecompiledFuncs files compile with
// RECOMP_GPR32=1 (32-bit N64 registers on 32-bit ARM11). Replacing
// block_visible eliminates Rare's accidental s64 accumulator in tracks.c
// (~168 float<->int64 soft-float helper calls + an unused sqrtf per segment
// bounding box) in favor of an exact VFP p-vertex plane test.

#include <cmath>
#include <cstdint>

#include "recomp.h"

namespace {

inline float load_f32(uint8_t* __restrict rdram, uint32_t addr) {
    uint32_t bits = static_cast<uint32_t>(MEM_W(0, static_cast<gpr>(addr)));
    float out;
    __builtin_memcpy(&out, &bits, sizeof(out));
    return out;
}

} // namespace

// Exact N64 PRNG (0x8006FB8C, state at 0x800DD9A4) using local 64-bit words.
extern "C" void dkr_rand_range(uint8_t* __restrict rdram, recomp_context* __restrict ctx) {
    const int32_t min_val = static_cast<int32_t>(ctx->r4);
    const int32_t max_val = static_cast<int32_t>(ctx->r5);
    constexpr gpr kRngBase = static_cast<gpr>(0x800E0000u);

    const uint64_t r8 = static_cast<uint64_t>(static_cast<int64_t>(MEM_W(-0x265C, kRngBase)));
    const uint32_t span = static_cast<uint32_t>(max_val - min_val) + 1u;

    uint64_t r9 = (r8 << 63) >> 31;
    const uint64_t r10 = (r8 << 31) >> 32;
    r9 |= r10;
    uint64_t r11 = (r8 << 44) >> 32;
    r9 ^= r11;
    r11 = (r9 >> 20) & 0xFFFu;
    const uint32_t seed = static_cast<uint32_t>(r11 ^ r9);

    MEM_W(-0x265C, kRngBase) = static_cast<int32_t>(seed);
    if (span == 0u) {
        do_break(2147941356u);
        ctx->r2 = static_cast<gpr>(min_val);
        return;
    }

    const uint32_t rem = (seed - static_cast<uint32_t>(min_val)) % span;
    ctx->r2 = static_cast<gpr>(static_cast<int32_t>(static_cast<uint32_t>(min_val) + rem));
}

// Exact N64 integer atan2s (0x800708AC, lookup table at 0x800DE1AE).
extern "C" void dkr_atan2s(uint8_t* __restrict rdram, recomp_context* __restrict ctx) {
    int32_t a0 = static_cast<int32_t>(ctx->r4);
    int32_t a1 = static_cast<int32_t>(ctx->r5);
    if ((a0 | a1) == 0) {
        ctx->r2 = 0;
        return;
    }

    int32_t v0 = 0;
    if (a0 < 0) {
        a0 = static_cast<int32_t>(0u - static_cast<uint32_t>(a0));
        if (a1 < 0) {
            a1 = static_cast<int32_t>(0u - static_cast<uint32_t>(a1));
            v0 = 0x8000;
        } else {
            v0 = 0xC000;
            const int32_t tmp = a0;
            a0 = a1;
            a1 = tmp;
        }
    } else if (a1 < 0) {
        a1 = static_cast<int32_t>(0u - static_cast<uint32_t>(a1));
        v0 = 0x4000;
        const int32_t tmp = a0;
        a0 = a1;
        a1 = tmp;
    }

    constexpr uint32_t kTableAddr = 0x800DE1AEu;
    const int32_t diff = static_cast<int32_t>(static_cast<uint32_t>(a0) - static_cast<uint32_t>(a1));
    if (diff < 0) {
        if (a1 == 0) {
            do_break(2147944812u);
            ctx->r2 = static_cast<gpr>(v0 & 0xFFFF);
            return;
        }
        const uint64_t num = static_cast<uint64_t>(static_cast<int64_t>(a0)) << 11;
        const uint64_t den = static_cast<uint64_t>(static_cast<int64_t>(a1));
        const uint32_t idx = static_cast<uint32_t>(num / den) & 0xFFEu;
        const int32_t lut = MEM_H(0, static_cast<gpr>(kTableAddr + idx));
        v0 = static_cast<int32_t>(static_cast<uint32_t>(v0) + static_cast<uint32_t>(lut));
    } else {
        if (a0 == 0) {
            do_break(2147944752u);
            ctx->r2 = static_cast<gpr>((v0 + 0x4000) & 0xFFFF);
            return;
        }
        const uint64_t num = static_cast<uint64_t>(static_cast<int64_t>(a1)) << 11;
        const uint64_t den = static_cast<uint64_t>(static_cast<int64_t>(a0));
        const uint32_t idx = static_cast<uint32_t>(num / den) & 0xFFEu;
        const int32_t lut = MEM_H(0, static_cast<gpr>(kTableAddr + idx));
        v0 = static_cast<int32_t>(static_cast<uint32_t>(v0 + 0x4000) - static_cast<uint32_t>(lut));
    }

    ctx->r2 = static_cast<gpr>(v0 & 0xFFFF);
}

// Exact N64 16-byte block copy (0x80070D44: dmacopy_doubleword).
extern "C" void dkr_dmacopy_doubleword(uint8_t* __restrict rdram, recomp_context* __restrict ctx) {
    uint32_t src = static_cast<uint32_t>(ctx->r4);
    uint32_t dst = static_cast<uint32_t>(ctx->r5);
    const uint32_t end = static_cast<uint32_t>(ctx->r6);
    do {
        const int32_t w0 = MEM_W(0x0, static_cast<gpr>(src));
        const int32_t w1 = MEM_W(0x4, static_cast<gpr>(src));
        const int32_t w2 = MEM_W(0x8, static_cast<gpr>(src));
        const int32_t w3 = MEM_W(0xC, static_cast<gpr>(src));
        dst += 0x10u;
        src += 0x10u;
        MEM_W(-0x10, static_cast<gpr>(dst)) = w0;
        MEM_W(-0x0C, static_cast<gpr>(dst)) = w1;
        MEM_W(-0x08, static_cast<gpr>(dst)) = w2;
        MEM_W(-0x04, static_cast<gpr>(dst)) = w3;
    } while (dst != end);
    ctx->r4 = static_cast<gpr>(static_cast<int32_t>(src));
    ctx->r5 = static_cast<gpr>(static_cast<int32_t>(dst));
}

// Native ARM11 VFP replacement for tracks.c::block_visible (0x8002A638).
// Tests a LevelModelSegmentBoundingBox (int16_t x1,y1,z1,x2,y2,z2) against the
// 3 active camera frustum planes at 0x8011D678 (D_8011D0F8[3]) using the AABB
// p-vertex instead of 8 corners x 7 int64<->float conversions + dead sqrtf.
extern "C" void dkr_block_visible(uint8_t* __restrict rdram, recomp_context* __restrict ctx) {
    const gpr bb = ctx->r4;
    const float x1 = static_cast<float>(MEM_H(0x0, bb));
    const float y1 = static_cast<float>(MEM_H(0x2, bb));
    const float z1 = static_cast<float>(MEM_H(0x4, bb));
    const float x2 = static_cast<float>(MEM_H(0x6, bb));
    const float y2 = static_cast<float>(MEM_H(0x8, bb));
    const float z2 = static_cast<float>(MEM_H(0xA, bb));

    constexpr uint32_t kFrustumPlanesAddr = 0x8011D678u;
    for (uint32_t j = 0; j < 3; j++) {
        const uint32_t p = kFrustumPlanesAddr + j * 16u;
        const float dx = load_f32(rdram, p + 0x0u);
        const float dy = load_f32(rdram, p + 0x4u);
        const float dz = load_f32(rdram, p + 0x8u);
        const float dw = load_f32(rdram, p + 0xCu);

        const float px = (dx > 0.0f) ? x2 : x1;
        const float py = (dy > 0.0f) ? y2 : y1;
        const float pz = (dz > 0.0f) ? z2 : z1;
        const float max_dot = px * dx + py * dy + pz * dz + dw;
        if (max_dot <= 0.0f) {
            ctx->r2 = 0;
            return;
        }
    }

    ctx->r2 = 1;
}
