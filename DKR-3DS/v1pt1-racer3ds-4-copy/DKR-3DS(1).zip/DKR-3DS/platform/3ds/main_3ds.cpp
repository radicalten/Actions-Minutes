// Diddy Kong Racing Recompiled — Nintendo 3DS entry point (rt64-3ds + N64ModernRuntime).
#include <cstdio>
#include <cstring>
#include <string>
#include <sys/stat.h>

#include <3ds.h>

#include "recomp.h"
#include "recomp3ds.h"
#include "librecomp/addresses.hpp"
#include "librecomp/game.hpp"
#include "librecomp/overlays.hpp"
#include "librecomp/rsp.hpp"
#include "ultramodern/ultramodern.hpp"

#include "recomp_overlays.inl"

extern "C" void recomp_entrypoint(uint8_t* __restrict rdram, recomp_context* __restrict ctx);
extern RspUcodeFunc aspMain;

namespace {

// XXH3_64 of Diddy Kong Racing USA v1.1 (NDYE, SHA1 6d96743d46f8c0cd0edb0ec5600b003c89b93755).
constexpr uint64_t kRomHash = 0xB55D4348B9AB07F5ULL;

using namespace recomp3ds;

// 3DS -> N64 controller button mapping for Diddy Kong Racing:
//   A       = Accelerate             B       = Brake / Reverse
//   L/ZL/Y  = Fire item (N64 Z)      R/ZR    = Hop / Drift (N64 R)
//   START   = Pause / Start          D-Pad   = N64 D-Pad (menus & steering)
//   X       = Rear-view (C-Up)       SELECT  = Camera view toggle (C-Right)
//   C-Stick = N64 C-Buttons
const ButtonMap kButtons[] = {
    { KEY_A, N64_A },
    { KEY_B, N64_B },
    { KEY_L | KEY_ZL | KEY_Y, N64_Z },
    { KEY_R | KEY_ZR, N64_R },
    { KEY_START, N64_START },
    { KEY_DUP, N64_DUP },
    { KEY_DDOWN, N64_DDOWN },
    { KEY_DLEFT, N64_DLEFT },
    { KEY_DRIGHT, N64_DRIGHT },
    { KEY_X, N64_CUP },
    { KEY_SELECT, N64_CRIGHT },
};

const MenuDefault kDefaults[] = {
    { "stereo_enabled", 1 },
    { "separation", 50 },
    { "convergence_tenths", 20 },
    { "hud_depth", 50 },
    { "auto_convergence", 1 },
    { "comfort_target", 0 },
    { "stereo_ghost_contrast", 100 },
    { "stereo_ghost_black_floor", 0 },
    { "stick_deadzone", 15 },
    { "cstick_deadzone", 20 },
    { "frame_cap", 0 },
    { "fps_cap", 60 },
};

// Always return a single ucode function pointer so recomp3ds's timed_get_ucode
// caches the right game_ucode even when the first task has data_size == 0.
RspExitReason dkr_aspMain(uint8_t* rdram, uint32_t ucode_addr) {
    OSTask task;
    std::memcpy(&task, &dmem[0xFC0], sizeof(OSTask));
    if (task.t.data_size == 0) {
        return RspExitReason::Broke;
    }
    return aspMain(rdram, ucode_addr);
}

RspUcodeFunc* get_rsp_microcode(const OSTask* task) {
    if (task->t.type == M_AUDTASK) {
        return dkr_aspMain;
    }
    return nullptr;
}

void widen_widescreen_frustum(uint8_t* rdram) {
    // D_800DC8AC[3][3] at 0x800DCE1C defines the 3 camera-space frustum planes
    // used by both block_visible (track segments) and check_if_in_draw_range
    // (racers, trees, balloons, coins, zippers). Widening the left/right plane
    // x-extents from +-130.0f (4:3) to +-175.0f covers the full 400x240 (5:3)
    // 3DS top screen plus stereoscopic 3D eye parallax without side pop-in.
    constexpr uint32_t kPlus130  = 0x43020000u; // +130.0f
    constexpr uint32_t kMinus130 = 0xC3020000u; // -130.0f
    constexpr uint32_t kPlus175  = 0x432F0000u; // +175.0f
    constexpr uint32_t kMinus175 = 0xC32F0000u; // -175.0f

    uint32_t* p1_a = reinterpret_cast<uint32_t*>(rdram + 0x0DCE4Cu);
    uint32_t* p1_b = reinterpret_cast<uint32_t*>(rdram + 0x0DCE58u);
    uint32_t* p2_a = reinterpret_cast<uint32_t*>(rdram + 0x0DCE70u);
    uint32_t* p2_b = reinterpret_cast<uint32_t*>(rdram + 0x0DCE7Cu);
    if (*p1_a == kPlus130 && *p1_b == kPlus130 && *p2_a == kMinus130 && *p2_b == kMinus130) {
        *p1_a = kPlus175;
        *p1_b = kPlus175;
        *p2_a = kMinus175;
        *p2_b = kMinus175;
    }

    // Scale DKR's 4 static Vec2s screen-wipe tables (BarnHorizontal, BarnVertical,
    // BarnDiag, Wave) in X by 5/4 (-160..+160 -> -200..+200) so wipes/fades cover
    // the full 400x240 5:3 screen instead of stopping at the 4:3 pillarbox edges.
    if (*reinterpret_cast<const uint32_t*>(rdram + 0x0E37F8u) == 0xFFA00168u) {
        static constexpr struct { uint32_t off; uint32_t count; } kTables[] = {
            { 0x0E37C0u, 14 }, // gTransitionBarnHorizontalCoords
            { 0x0E37F8u, 14 }, // gTransitionBarnVerticalCoords
            { 0x0E386Cu, 12 }, // gTransitionBarnDiagCoords
            { 0x0E38D4u, 63 }, // gTransitionWaveCoords
        };
        for (const auto& t : kTables) {
            uint32_t* words = reinterpret_cast<uint32_t*>(rdram + t.off);
            for (uint32_t i = 0; i < t.count; ++i) {
                const uint32_t w = words[i];
                const int16_t x = static_cast<int16_t>(w >> 16);
                const uint16_t y = static_cast<uint16_t>(w);
                const uint16_t wide_x = static_cast<uint16_t>(static_cast<int16_t>((static_cast<int32_t>(x) * 5) / 4));
                words[i] = (static_cast<uint32_t>(wide_x) << 16) | y;
            }
        }
    }
}

void on_init(uint8_t* rdram, recomp_context*) {
    // Low RDRAM words and IPL3 CIC-6103 seed expected by DKR's checks.
    // All KSEG1/MMIO/ROM reads (0xA4000000..0xB0000FFF) are patched out in dkr.recomp.toml
    // so DKR runs inside a compact 16 MB 3DS RDRAM allocation with zero bounds-guard branches.
    *reinterpret_cast<uint32_t*>(rdram + 0x200) = 0xAC290000u;
    *reinterpret_cast<uint32_t*>(rdram + 0x284) = 0x240B17D7u;
    *reinterpret_cast<int32_t*>(rdram + 0x310) = 6103;
    widen_widescreen_frustum(rdram);
}

void register_overlays() {
    recomp::overlays::overlay_section_table_data_t sections{ section_table, num_sections, num_sections };
    recomp::overlays::overlays_by_index_t overlays{ overlay_sections_by_index,
        sizeof(overlay_sections_by_index) / sizeof(overlay_sections_by_index[0]) };
    recomp::overlays::register_overlays(sections, overlays);
}

std::string get_game_thread_name(const OSThread* t) {
    return "DKR thread " + std::to_string(t->id);
}

// Accept common ROM filenames inside sdmc:/3ds/DKR/ by normalizing to dkr.us.z64.
void normalize_rom_filename() {
    const char* target = "sdmc:/3ds/DKR/dkr.us.z64";
    struct stat st{};
    if (stat(target, &st) == 0) {
        return;
    }
    static const char* const kCandidates[] = {
        "sdmc:/3ds/DKR/baserom.us.z64",
        "sdmc:/3ds/DKR/baserom.z64",
        "sdmc:/3ds/DKR/dkr.z64",
        "sdmc:/3ds/DKR/Diddy Kong Racing (U) [!].z64",
    };
    for (const char* src : kCandidates) {
        if (stat(src, &st) == 0) {
            std::rename(src, target);
            return;
        }
    }
}

} // namespace

int main(int argc, char** argv) {
    (void)argc;
    (void)argv;

    normalize_rom_filename();

    recomp3ds::GameDesc desc{};
    desc.game_id = u8"dkr.us";
    desc.sd_dir = "DKR"; // ROM path on SD card: sdmc:/3ds/DKR/dkr.us.z64
    desc.project_version = { 0, 4, 0, "-3ds" };
    desc.entry = recomp::GameEntry{
        .rom_hash = kRomHash,
        .internal_name = "Diddy Kong Racing",
        .display_name = "Diddy Kong Racing",
        .game_id = u8"dkr.us",
        .mod_game_id = "",
        .rom_filename_override = u8"dkr.us.z64",
        .save_type = recomp::SaveType::Eep4k,
        .thumbnail_bytes = {},
        .is_enabled = true,
        .decompression_routine = nullptr,
        .has_compressed_code = false,
        .entrypoint_address = static_cast<gpr>(static_cast<int32_t>(0x80000400u)),
        .entrypoint = reinterpret_cast<recomp_func_t*>(recomp_entrypoint),
        .on_init_callback = on_init,
    };
    desc.rsp.get_rsp_microcode = get_rsp_microcode;
    desc.register_overlays = register_overlays;
    desc.get_game_thread_name = get_game_thread_name;
    desc.rom_room_mb = 8;
    desc.two_cores_game_on_core0 = true;

    // Renderer configuration: Rare's F3DDKR microcode + 400x240 (5:3) Hor+ widescreen + stereo 3D.
    desc.render.game_name = "Diddy Kong Racing";
    desc.render.gbi = rt64_3ds::Gbi::F3DDKR;
    desc.render.unclassified_persp = rt64_3ds::StereoClass::World;
    desc.render.unclassified_ortho = rt64_3ds::StereoClass::Hud;
    desc.render.vi_width = 320;
    desc.render.vi_height = 240;
    desc.render.scissor_edge_slack = 8;       // Open 0..319x239 scissors across the 400x240 5:3 top screen
    desc.render.fix_rect_lr = true;           // Extend full-frame clear/fade rectangles across 400x240
    desc.render.stretch_tint_quads = true;    // Stretch full-frame screen-tint quads across 400x240
    desc.render.fill_clear = true;            // Fold leading full-frame fill into GPU eye clear
    desc.render.eye_depth16 = true;           // 16-bit eye depth buffer (halves PICA200 depth bandwidth)
    desc.render.intensity_textures16 = true;  // 16-bit LA8/L8 for I4/I8/IA4/IA8 textures
    desc.render.early_drawn = true;

    // Hardware RSP ordering: DKR frees/rebuilds display lists & textures once RSP parse finishes,
    // while PICA200 GPU replay proceeds concurrently on Core 1.
    desc.synchronous_rsp_tasks = true;

    // Native ARM11 HLE for libaudio ABI 1 aspMain with stale-queue recovery guard.
    desc.audio_hle = true;
    desc.audio_hle_family = recomp3ds::AudioHle::Aspmain;
    desc.audio_margin_frames = 2;
    desc.audio_max_queued_ms = 300;
    desc.audio_async = false;

    desc.button_map = kButtons;
    desc.button_map_count = sizeof(kButtons) / sizeof(kButtons[0]);
    desc.menu_defaults = kDefaults;
    desc.menu_default_count = sizeof(kDefaults) / sizeof(kDefaults[0]);

#ifdef DKR_NULL_RENDERER
    desc.null_renderer = true;
#endif

    return recomp3ds::run(desc);
}
