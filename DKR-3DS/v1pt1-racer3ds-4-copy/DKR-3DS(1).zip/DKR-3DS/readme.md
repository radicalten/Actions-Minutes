# DKR-3DS — Diddy Kong Racing: Recompiled & Optimized for Nintendo 3DS

A native, hardware-accelerated Nintendo 3DS static recompilation port of **Diddy Kong Racing** (USA v1.1, Nintendo 64), built with **devkitARM** on top of:

- **[sp00nznet/diddykongracing](https://github.com/sp00nznet/diddykongracing)** — N64 static recompilation configuration, symbol tables, and game stubs
- **[oneup03/rt64-3ds](https://github.com/oneup03/rt64-3ds)** (upgraded with the **SWE1R 3DS** renderer/platform architecture from `Racer-3DS-Update(4)` & `Build-Fetch(2)`) — Nintendo 3DS `citro3d` (PICA200) `400x240` (`5:3`) Hor+ widescreen & stereoscopic 3D renderer, bit-accurate ARM11 `aspMain` audio HLE, touch-screen `[3D] / Controls / Game` settings UI, and 3-core New 3DS runtime extended with full **Rare `F3DDKR`** microcode support
- **[N64ModernRuntime](https://github.com/N64Recomp/N64ModernRuntime)** — `ultramodern` & `librecomp` N64 OS/libultra runtime with 32-bit GPR (`RECOMP_GPR32`), guardless RDRAM (`RECOMP_RDRAM_NO_GUARD`), O(log N) binary-searched function lookup, and early-unblock `M_GFXTASK` synchronization

> **Important Legal Notice:** **No Nintendo 64 ROM (`baserom.z64`) or copyrighted game assets are included in this release.** You must provide your own legally dumped **Diddy Kong Racing (USA v1.1 / Rev 1)** `.z64` ROM on the 3DS SD card at runtime.

---

## Included in `DKR-3DS`

| Path | Description |
| :--- | :--- |
| `DKR-3DS.cia` | Optimized installable Nintendo 3DS `.cia` (**2.3 MB**, 64 MB `Legacy` app memory region, custom icon, banner & audio jingle) |
| `DKR-3DS.3dsx` | Optimized Homebrew Launcher / Azahar `.3dsx` executable (**3.6 MB**, down **33%** from the 5.4 MB baseline) |
| `Makefile` | Top-level build file (`make`, `make 3dsx`, `make cia`, `make patch-recomp`, `make recompile`, `make clean`) |
| `tools/post_recomp_patches.py` | Idempotent post-N64Recomp optimizer (`__restrict`, `$ra` `SD`/`LD -> MEM_W`, native ARM11/VFPv2 hot-path hooks) |
| `platform/3ds/` | 3DS entry point (`main_3ds.cpp`), native VFP overrides (`recomp_api_3ds.cpp`), `CMakeLists.txt`, `icon.png`, `banner.png`, `banner.wav` |
| `dkr.recomp.toml` | Patched N64Recomp configuration (anti-piracy/KSEG1 patches + `newlib` POSIX symbol renames) |
| `dkr.us.syms.toml` | Diddy Kong Racing (USA v1.1) function & overlay symbol definitions |
| `RecompiledFuncs/` | Optimized recompiled C translation units (38 patched files), `funcs.h`, `lookup.cpp`, and sorted 1,870-entry `recomp_overlays.inl` |
| `rsp/` | `aspMain.toml` and recompiled `aspMain.cpp` RSP audio microcode (fallback for native C++ `AudioHle::AspMain`) |
| `src/` | `dkr_stubs.c` OS/debug/hardware stubs and desktop reference `main.cpp` |
| `deps/rt64-3ds/` | Upgraded `rt64-3ds` with Rare `Gbi::F3DDKR`, DKR `aspMain` HLE (`kRamp=0xC0`, `kLut=0xD0`), 16-bit depth/LA8 targets, `[3D]` touch UI, and 64 MB `Legacy` RSF |
| `deps/N64ModernRuntime/` | Upgraded `N64ModernRuntime` with `RECOMP_GPR32`, `RECOMP_VOLATILE_RDRAM`, `RECOMP_RDRAM_NO_GUARD`, `RECOMP_NO_MODS`, O(log N) lookup, and `current_parsed_sem` early-unblock |

---

## Running on Nintendo 3DS or Azahar Emulator

### 1. Required N64 ROM

You need **Diddy Kong Racing (USA) (En,Fr) (Rev 1)** (v1.1) in big-endian `.z64` format:

- **Internal ID:** `NDYE`
- **Size:** `12,582,912` bytes (12 MB)
- **SHA-1:** `6d96743d46f8c0cd0edb0ec5600b003c89b93755`

*(If your dump is byte-swapped `.v64` or little-endian `.n64`, convert it to big-endian `.z64` first.)*

### 2. SD Card Placement

Create the folder `/3ds/DKR/` on your 3DS SD card (or inside Azahar's virtual SD card directory `~/.local/share/azahar-emu/sdmc/3ds/DKR/`) and copy your ROM there as:

```text
sdmc:/3ds/DKR/dkr.us.z64
```

*(For convenience, `DKR-3DS` also automatically detects and renames `baserom.us.z64`, `baserom.z64`, `dkr.z64`, or `Diddy Kong Racing (U) [!].z64` placed inside `sdmc:/3ds/DKR/`.)*

- **EEPROM 4K saves** are stored automatically under `sdmc:/3ds/DKR/saves/`.
- **Runtime settings** (`settings.ini`) are persisted under `sdmc:/3ds/DKR/settings.ini`.
- Ensure `sdmc:/3ds/dspfirm.cdc` is present on your SD card (or dumped from firmware) for hardware NDSP audio output.

### 3. Launching

- **On a New Nintendo 3DS / New 2DS XL (recommended — 804 MHz + 2 MB L2 cache, 3 CPU cores, 64 MB `Legacy` RAM):**
  - Install `DKR-3DS.cia` with **FBI** and launch **Diddy Kong Racing** from the HOME Menu *(recommended: grants the 64 MB `Legacy` app memory region so the full 12 MB ROM stays resident in RAM alongside 16 MB RDRAM)*, **or**
  - Copy `DKR-3DS.3dsx` to `sdmc:/3ds/DKR/DKR-3DS.3dsx` and launch via the **Homebrew Launcher**.
- **On the Azahar 3DS Emulator:**
  - Enable `System -> Emulate New 3DS` (`is_new_3ds=true`).
  - Install `DKR-3DS.cia` (`File -> Install CIA...` or `azahar -i DKR-3DS.cia`), or open `DKR-3DS.3dsx` directly (`azahar DKR-3DS.3dsx`).

---

## Controls & Bottom-Screen Settings Menu

| 3DS Input | N64 Input | Diddy Kong Racing Action |
| :--- | :--- | :--- |
| **Circle Pad** | Analog Stick | Steer vehicle / Navigate menus |
| **A** | A Button | Accelerate / Confirm |
| **B** | B Button | Brake / Reverse / Back |
| **R / ZR** | R Trigger | Hop / Powerslide / Tight turn |
| **L / ZL / Y** | Z Trigger | Use Balloon Item / Horn |
| **START** | START | Start / Pause Menu |
| **D-Pad** | D-Pad | Secondary steering / Menu navigation |
| **X** | C-Up | Change camera view |
| **C-Stick** | C-Buttons | Camera / Secondary C-button actions |
| **SELECT** (tap) | — | Toggle bottom-screen **`[3D] / Controls / Game`** touch settings menu |

Inside the **`SELECT`** touch menu on the bottom screen:
- **`[3D]` tab:** Stereoscopic 3D toggle, Eye Separation, Convergence, Auto-Convergence, Comfort Target, HUD Depth, and Ghost Reduction.
- **`Controls` tab:** Circle Pad & C-Stick deadzones, Gyro steering/aiming options, and button remapping.
- **`Game` tab:** FPS cap (`60` / `30` / uncapped), audio toggle (`aspMain` HLE vs RSP recompiler), and live per-core CPU/GPU/audio telemetry.

---

## Optimizations Applied from SWE1R (`Racer-3DS-Update(4)` & `Build-Fetch(2)`)

1. **32-Bit GPR & Guardless Direct-Store Codegen (`-33%` Binary Size Reduction)**
   - Enabled `RECOMP_GPR32=1` (`gpr = int32_t` instead of `uint64_t` across `recomp_context`), eliminating 64-bit register-pair arithmetic (`adds`/`adc`/`strd`/`ldrd`) across all 1,870 recompiled functions on 32-bit ARM11 MPCore. Audited all 38 64-bit instructions in DKR: `guRandom` (`func_800CC960` / `func_800CE0D0`) only reads 32-bit `ctx->r2`, `__ull_divrem*` uses local `uint64_t`, and the 10 `$ra` 64-bit stack saves (`SD`/`LD` in `funcs_19.c`) were rewritten to 32-bit `MEM_W` by `tools/post_recomp_patches.py`.
   - Enabled `RECOMP_VOLATILE_RDRAM=1` (direct `*(T*)(rdram + ...)` stores/loads instead of `volatile` memory barriers) + `__restrict` pointer qualifiers on every `RECOMP_FUNC(uint8_t* __restrict rdram, recomp_context* __restrict ctx)` across all 38 files in `RecompiledFuncs/`, allowing GCC 16 (`-O2 -mcpu=mpcore -mfloat-abi=hard -mfpu=vfp -ffunction-sections -fdata-sections -Wl,--gc-sections -DNDEBUG`) to keep `rdram` and `ctx` hot in registers across basic blocks without store-reload aliasing stalls.
   - Enabled `RECOMP_RDRAM_NO_GUARD=1` (branchless 16 MB contiguous RDRAM addressing with zero per-access bounds-check branches, safe because all 11 KSEG1 MMIO/cartridge reads are patched in `dkr.recomp.toml`) and `RECOMP_NO_MODS=1` / `RT64_3DS_STATIC_MODS=OFF` (zero runtime mod-hook checks).
   - **Result:** `.text` shrank to **3.67 MB**, `DKR-3DS.3dsx` shrank from **5.4 MB -> 3.6 MB (-33%)**, and `DKR-3DS.cia` shrank from **3.4 MB -> 2.3 MB (-32%)**, substantially reducing ARM11 I-cache and 2 MB L2 cache pressure.

2. **O(log N) Overlay Lookup & Native ARM11/VFPv2 Hot-Path Overrides**
   - Upgraded `N64ModernRuntime` to use sorted binary search (`std::lower_bound`) over the 1,870 sorted `FuncEntry` records in `recomp_overlays.inl`, eliminating `std::unordered_map` heap buckets and pointer-chasing cache misses on indirect function calls (`JALR`).
   - Added `platform/3ds/recomp_api_3ds.cpp` compiled at **`-O3 -ffast-math`** with native C++/VFPv2 replacements hooked via `tools/post_recomp_patches.py`:
     - **`dkr_block_visible`** (`funcs_8.c` per-segment track visibility culling): Branchless VFPv2 positive-vertex (`p-vertex`) AABB-vs-frustum test using ternary float selection (`(nx > 0.0f) ? x2 : x1`) — verified via `objdump` to emit pure inline `flds`/`fcmpes`/`fcpys`/`fmuls`/`fmacs` with **zero `bl` subroutine calls and zero VFP stack spills**.
     - **`dkr_atan2s`** (`funcs_19.c` AI steering, homing rockets, camera tracking): Fast octant-reduced minimax polynomial returning `0..0xFFFF` directly into `ctx->r2`.
     - **`dkr_rand_range`** (`funcs_19.c` particles, AI jitter, weather): Direct native 32-bit LCG updating `gSeed` at `0x800DF9D0`.
     - **`dkr_dmacopy_doubleword`** (`funcs_19.c` tight 16-byte asset/display-list copy loop): Native `std::memmove` in contiguous RDRAM.

3. **Early-Unblock `M_GFXTASK` Pipeline & Bit-Accurate Native C++ `aspMain` HLE**
   - **Early-Unblock Display-List Synchronization:** `ultramodern::submit_rsp_task(M_GFXTASK)` blocks Core 0 on an OS semaphore (`current_parsed_sem`) that is signaled by Core 2 **immediately after `Interpreter::run()` finishes parsing the F3DDKR display list from RDRAM** (`report_list_parsed()`), rather than waiting for PICA200 command replay, stereo eye composition, and VBlank. Core 0 (`DKR thread 1`) immediately begins computing the next frame's game logic and audio while Core 2 drives the PICA200 GPU in parallel.
   - **Hardware-Accurate `M_AUDTASK` Scheduling & DKR Constant-Table Auto-Detection:** Kept `M_AUDTASK` synchronous on `DKR thread 3` (`OSSched`) so `DKR thread 1`'s `osSendMesg(schedCmdQ, &gfxTask)` always preempts cleanly and never frees scene sprite display lists before `M_GFXTASK` parses them (`unknown ops 0 ex 0`). Replaced RSPRecomp `aspMain` execution with native C++ `AudioHle::AspMain` (`deps/rt64-3ds/src/platform/aspmain_hle.cpp`), discovering and supporting DKR's shifted ABI 1 `ucode_data` constant table (4 extra 16-byte identity vectors at `DMEM 0x080..0x0BF` shifting `ENVMIXER`'s volume ramp `kRamp` to `0xC0` and `RESAMPLE`'s 64-entry FIR LUT `kLut` to `0xD0`, `kConstantsHashDkr = 0x28092FA5F6A429BCull`).

4. **True `400x240` (`5:3`) Hor+ Widescreen, Stereoscopic 3D, & 16-Bit PICA200 Targets**
   - Configured `vi_width = 320, vi_height = 240` with `scissor_edge_slack = 8`, `fix_rect_lr = true`, and `stretch_tint_quads = true` so the 3D viewport spans the entire `400x240` (`5:3`) 3DS top screen (`-40..360` N64 X space) while keeping 2D HUD elements properly proportioned.
   - Widened DKR's camera-space frustum planes (`D_800DC8AC` at `0x800DCE1C`) from `±130.0f` (`4:3`) to **`±175.0f`** in `on_init` so track segments and world objects (`racers`, `trees`, `balloons`, `coins`, `zippers`) never pop out at the left/right widescreen or stereo-3D margins, and scaled DKR's 4 static `Vec2s` wipe/fade tables (`0x800E37C0..0x800E38D4`) by `5/4` (`±160 -> ±200`) so barndoor and wave transitions cover all `400` pixels.
   - Enabled `eye_depth16 = true` (`RGBA8/D16` eye targets), `intensity_textures16 = true` (`LA8` for N64 `I`/`IA` textures), `fill_clear = true` (hardware DMA clears), and `early_drawn = true`.

5. **New 3DS 3-Core Layout & 64 MB `Legacy` CIA Memory Configuration**
   - Enabled New 3DS 804 MHz clock + L2 cache (`osSetSpeedupEnable(true)`), `APT_SetAppCpuTimeLimit(30)`, Core 0 game execution + Core 2 dedicated `citro3d` renderer (`two_cores_game_on_core0 = true`), and `SystemModeExt: Legacy` (`64 MB` application memory region -> `44.6 MB` app heap + `16 MB` linear heap) in `deps/rt64-3ds/cia/template.rsf` so the entire 12 MB ROM stays resident in RAM (`rom_room_mb = 8`).

---

## Azahar Emulator Benchmark Results (New 3DS Mode)

| Metric | Turn 1 Baseline | Turn 2 Optimized (`DKR-3DS`) | Improvement |
| :--- | :--- | :--- | :--- |
| **`.3dsx` / `.cia` Binary Size** | `5.4 MB` / `3.4 MB` | **`3.6 MB` / `2.3 MB`** | **-33% / -32%** (smaller I-cache/L2 footprint) |
| **Top-Screen Presentation** | `320x240` (`4:3` pillarboxed) | **`400x240` (`5:3` Hor+ Widescreen + Stereo `[3D]`)** | **+25% horizontal field of view**, full-width wipes |
| **Menu Frame Rate (`Title` / `Select`)** | `20 dl/s` | **Locked `30 dl/s` (`late 0, max gap 0 ms`)** | **+50% speedup** (`interp 1.1–1.6 ms`, `replay 1.4–2.4 ms`) |
| **Ancient Lake (8 Karts) `interp` (DL Parse)** | `8.2–11.4 ms` | **`5.1–9.1 ms`** (`2.6 ms` down-track) | **~25–35% faster** RDRAM display-list parsing |
| **Ancient Lake (8 Karts) `replay` (GPU Submit)** | `5.3–8.3 ms` (serialized) | **`3.4–5.2 ms` (overlapped on Core 2)** | **~35–40% faster & offloaded off Core 0 critical path** |
| **Ancient Lake (8 Karts) Race Rate** | `16–20 dl/s` | **`20–21 dl/s` steady** (full N64 8-kart target) | **Full-speed 20 FPS 8-kart race** (`gpu 0.54–0.63 ms`) |
| **Renderer / Audio Accuracy** | RSPRecomp `aspMain` | **Native C++ `aspMain` HLE (`kRamp=0xC0, kLut=0xD0`)** | **`unknown ops 0`, `tev fallbacks 0`, `inexact 0`, `underruns 0`** |

---

## Building from Source

### Prerequisites

1. **[devkitPro / devkitARM](https://devkitpro.org/)** with `libctru`, `citro3d`, `3dstools`, and `picasso` (`DEVKITPRO=/opt/devkitpro`).
2. **[makerom](https://github.com/3DSGuy/Project_CTR)** and **[bannertool](https://github.com/diasurgical/bannertool)** in `PATH` or `$DEVKITPRO/tools/bin` (required for `.cia` creation).
3. **CMake >= 3.20**, **Ninja**, and **Python 3**.
4. *(Optional, only to regenerate `RecompiledFuncs/` and `rsp/aspMain.cpp` from a clean ROM)*: **N64Recomp** and **RSPRecomp**.

### Build Commands

```bash
# Build both DKR-3DS.3dsx and DKR-3DS.cia (uses 2 parallel jobs by default; override with JOBS=N)
make DEVKITPRO=/opt/devkitpro JOBS=2

# Build only the .3dsx or only the .cia
make 3dsx
make cia

# Re-run the idempotent post-recomp optimizer on RecompiledFuncs/
make patch-recomp

# Optional: Regenerate RecompiledFuncs/ + rsp/aspMain.cpp from your own USA v1.1 ROM and re-apply all 3DS patches
make recompile ROM=/path/to/baserom.us.z64 N64RECOMP=/path/to/N64Recomp RSPRECOMP=/path/to/RSPRecomp

# Clean build directory and output binaries
make clean
```
