# Conservative ARM/Thumb JIT mode

This tree adds an opt-in, correctness-first mode to the Agents interpreter-integrated PPC JIT. It keeps native execution deliberately narrow and preserves the interpreter as the fallback.

## Build

With devkitPPC installed:

```sh
source /etc/profile.d/devkit-env.sh
make clean JIT=1 BLOCKS=0 SAFE=1
make -j4 JIT=1 BLOCKS=0 SAFE=1
```

The build output is `NooDS-Wii.dol`. `SAFE=0` remains the default and preserves the prior build behavior. The Makefile includes `SAFE` in the build-directory tag to prevent object-file reuse between modes.

The standard safe-mode DOL produced for this comparison is `build-artifacts/NooDS-Wii-conservative-safe-jit.dol` (SHA-256 `2fb683f12bfe7a95a02440d53f36bde82562d704dc50a41dfbfa87d4c08b1c5e`). To reproduce the separate full-RAM test build, apply `patch -p1 < ../scripts/conservative-safe-fullram.patch` from `conservative-jit/` before building; it changes only the test harness dump length from 256 KiB to 4 MiB. That DOL is `build-artifacts/NooDS-Wii-conservative-safe-jit-fullram.dol` (SHA-256 `f1509841e01502da6255d3450913b1204436dd514b1c27a46ce3502c6aa29173`).

## Safe-mode policy

`NOODS_JIT_SAFE_MODE=1` disables multi-instruction block dispatch and uses per-instruction PPC stubs only for a small whitelist:

- **ARM:** condition `AL`, data-processing instructions, no flag writes, no PC source/destination, no memory/system/branch operation, no ADC/SBC/RSC, and only immediate operands or unshifted register operands.
- **Thumb:** high-register `ADD` and `MOV` only, with neither source nor destination PC.

Everything outside those sets goes directly to the existing interpreter handler. This deliberately sacrifices coverage and speed for a small, auditable native subset. The opcode and guest PC are checked by the existing instruction-stub cache; memory writes, branch targets, condition evaluation, flags, and system behavior stay interpreted.

## Validation against `suite.nds`

- ROM SHA-256: `8259d5b024014bd24b6fa2dc669c7fd7e1793d9f2e90a3158b553010475872f3`.
- The 600-frame safe-mode capture finished the suite with 0 unrun groups. `JIT_STATS` reported `enabled=1 blocks=0 safe=1`.
- Against the interpreter-only capture, the full 4 MiB main-RAM image is byte-for-byte identical (SHA-256 `e40d55e873d842d4ffd47a829f5570725d49bc20a3af63cc0ea16d4f98fa20a1`). The complete ARM9 trace slot (13,380 records), ARM7 trace slot (12,056 records), and 81,984-byte assertion journal also match byte-for-byte.
- The framebuffer hashes match at frames 120, 300, and 600. The suite counts also match the interpreter: 21/27 groups passed; CPU9 12,804 pass / 576 fail; CPU7 11,884 pass / 172 fail.
- At frame 600 the standard test run's 64-bit RAM and framebuffer hashes were `C5CC5C5610698830` and `3E91E1580B034EE5`, respectively, matching the interpreter. The raw full-RAM comparator result is saved at `dolphin-test/trace-diff-interpreter-vs-safe.json`.

## Scope caveat

This is a conservative parity mode, not a fix for the interpreter's existing failed vectors: it reproduces the interpreter's 748 failing vectors on this ROM. The suite and the interpreter are comparison references, not an independent hardware oracle. Keep the ROM hash, build hash, run budget, and vector-level evidence together when interpreting results.
