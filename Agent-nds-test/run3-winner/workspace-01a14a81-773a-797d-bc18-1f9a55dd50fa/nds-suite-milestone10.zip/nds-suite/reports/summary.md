# Verification summary — milestone 10

**Partial coverage, not an exhaustive suite.** See readme.md, coverage.json and
[current compare/test scope](../docs/compare-operand2.md) and
[system/exception oracle limits](../docs/arm9-milestone8.md).

ROM SHA-256: `a4975b04dc9affac095550abbf2f83bcf91686dd5cc4f796c065afc2c2a1689e`

| CPU | Total | PASS | FAIL |
|---|---:|---:|---:|
| ARM9 | 6,498 | 6,178 | 320 |
| ARM7 | 5,174 | 5,151 | 23 |

Added256 flag-only register-controlled operand2 cases per CPU; all512 new DS executions PASS. ARM9 failures are 64 CP15 region mirrors,
96 AP aliases,32 Thumb undefined nonentries,128 MPU-abort nonentries. The earlier
23 ARM7 mismatches remain. Expectations were not changed to match the backend.
These are reference discrepancies, not hardware-confirmed emulator findings.

**Independent QEMU evidence:** shared3390 PASS on ARM946 and ti925t proxy;
2012 portable ARM9 PASS;208 ARM946 CP15 aliases PASS;956 portable ARM7 privileged
PASS on both models;11 original CPU groups PASS ARM946. Separate raw-exception
oracle:128 SWI/UDF PASS with explicitly adapted low-RAM vectors,128 MPU-abort
UNSUPPORTED (MPU-enable reads zero). No ITCM enforcement, exact ARM7TDMI or physical
DS claim. Unsupported cases are not counted as PASS. Both the retained256 register-operand2 and new256 flag-only
cases additionally PASS ARM946 and the ti925t proxy; actual helper bytes match on
both DS CPUs and runtime ELF addresses are verified.

[Search all 11,672 vector rows](debugger.html) · [CSV](debugger.csv) ·
[Debugging protocol](../docs/debugging.md)

The full resumed run retains160 assertion events from117 instrumented sites.
Other paths remain group-only/unknown. Historical traces survive native crashes
and are labeled. Original groups are internally fail-fast; zero unrun groups is
not proof every original assertion executed.

**Isolated: 17/25 = 68.00%**, 0 unrun.

**Checkpointed sequential: 17/25 = 68.00%**, 0 unrun.

Six returned failures and two native division crashes; supervised execution is
explicitly resumed, not one uninterrupted boot. Both LCDs show the actual score
and per-case/group details; lower-screen browsing leaves the score unchanged.

![Actual completed score](score-screen.png)

| Group | Result | Assertion / process code |
|---|---|---|
| CPU ARM9 VECTORS | FAIL | 5524 |
| CPU ARM7 VECTORS | FAIL | 3412 |
| CONDITION CODES | PASS | 0 |
| CLZ | PASS | 0 |
| QADD, QSUB | PASS | 0 |
| QDADD, QDSUB | PASS | 0 |
| SMULxy | PASS | 0 |
| SMLAxy | PASS | 0 |
| SMULWy | PASS | 0 |
| SMLAWy | PASS | 0 |
| SMLALxy | PASS | 0 |
| BLX | PASS | 0 |
| LDR r15, POP {r15}, LDM {r15} | PASS | 0 |
| LDM / STM | FAIL | 4 |
| IPCSYNC | PASS | 0 |
| IPCFIFO | FAIL | 37 |
| IPCFIFO IRQ | PASS | 0 |
| SQRT 32 | PASS | 0 |
| SQRT 64 | PASS | 0 |
| DIV 32/32 | FAIL | 21 |
| DIV 64/32 | EMULATOR_CRASH | -8 |
| DIV 64/64 | EMULATOR_CRASH | -8 |
| WRAM CNT | PASS | 0 |
| VRAM CNT | PASS | 0 |
| TCM | FAIL | 0 |

**Regression:**36 host checks;12 real-key lower-screen pages;six ARM7 attribution
checks;five diagnostic scenarios;three recovery scenarios;retained negative and
privileged injections. Nine new compare/test scenarios detect16 primary and16 NZCV
expectation mutations per CPU and212 unintended source-write cases per CPU, with
unchanged flags. The remaining44 opcode-mutated cases coincidentally leave Rn
unchanged and are not claimed as detected faults. Nine retained operand2 scenarios test both CPUs, including16 primary and16 NZCV
expectation mutations per CPU plus64 lost carry-input cases per CPU through actual
ADC-to-ADD/SBC-to-SUB instruction mutations. Retained eight milestone-8 scenarios include220 primary expectation
mutations,a sticky-Q auxiliary mutation,96 missing ARM9 IRQ counters,64 missing
raw SWI counters and32 missing second ARM7 IRQ counters. Injection ROMs were
temporary copies; the distributed ROM has no injected faults or enabled resume seed.
A deterministic rebuild matched the recorded ROM hash.

Diagnostic binaries are deduplicated into byte-hashed `reports/blobs`; JSON paths
and SHA-256 checks preserve every referenced observation. Keep those files together.
