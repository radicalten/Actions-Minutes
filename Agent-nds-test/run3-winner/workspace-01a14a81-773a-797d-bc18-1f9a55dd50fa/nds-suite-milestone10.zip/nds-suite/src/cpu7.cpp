#include "count.h"
extern "C" unsigned cpu_checks(unsigned*);
extern "C" unsigned arm7_checks(unsigned*);
extern "C" void cpu_trace_init(unsigned,unsigned,unsigned,unsigned);
extern "C" void cpu_trace_complete();
extern "C" void auto_cpu7() {
 for(unsigned i=0;i<4;i++) ((volatile unsigned*)0x023ee000)[i]=0;
 volatile unsigned* p=(volatile unsigned*)0x023ef000;
 unsigned detail[6]={0,0,0,0,0,0};
 cpu_trace_init(0x02340000,7,CPU7_VECTOR_TOTAL,CPU_MANIFEST_CRC);
 unsigned extra[6];unsigned result=cpu_checks(detail),specific=arm7_checks(extra);cpu_trace_complete();
 if(!result && specific){result=specific;for(unsigned i=0;i<4;i++)detail[i]=extra[i];}
 detail[4]+=extra[4];detail[5]+=extra[5];
 for(unsigned i=0;i<6;i++) p[2+i]=detail[i];
 p[1]=result; p[0]=0x43505537;
}
