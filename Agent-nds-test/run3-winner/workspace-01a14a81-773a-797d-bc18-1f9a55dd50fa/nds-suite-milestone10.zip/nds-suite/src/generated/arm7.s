.syntax unified
.arch armv4t
.text
.arm
.balign 4
.global cpu_arm7_arm_ldr_alignment
.type cpu_arm7_arm_ldr_alignment, %function
cpu_arm7_arm_ldr_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
ldr r0,[r5,r6]
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_ldrh_alignment
.type cpu_arm7_arm_ldrh_alignment, %function
cpu_arm7_arm_ldrh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
ldrh r0,[r5,r6]
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_ldrsh_alignment
.type cpu_arm7_arm_ldrsh_alignment, %function
cpu_arm7_arm_ldrsh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
ldrsh r0,[r5,r6]
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_str_alignment
.type cpu_arm7_arm_str_alignment, %function
cpu_arm7_arm_str_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
ldr r7,=0xa5a5a5a5
str r7,[r5]
str r0,[r5,r6]
ldr r0,[r5]
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_strh_alignment
.type cpu_arm7_arm_strh_alignment, %function
cpu_arm7_arm_strh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
ldr r7,=0xa5a5a5a5
str r7,[r5]
strh r0,[r5,r6]
ldr r0,[r5]
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_ldr_alignment
.type cpu_arm7_thumb_ldr_alignment, %function
cpu_arm7_thumb_ldr_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
adr r7,1f
orr r7,r7,#1
adr r8,2f
bx r7
.thumb
.balign 4
1:
ldr r0,[r5,r6]
bx r8
.arm
.balign 4
2:
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_ldrh_alignment
.type cpu_arm7_thumb_ldrh_alignment, %function
cpu_arm7_thumb_ldrh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
adr r7,1f
orr r7,r7,#1
adr r8,2f
bx r7
.thumb
.balign 4
1:
ldrh r0,[r5,r6]
bx r8
.arm
.balign 4
2:
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_ldrsh_alignment
.type cpu_arm7_thumb_ldrsh_alignment, %function
cpu_arm7_thumb_ldrsh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
str r0,[r5]
adr r7,1f
orr r7,r7,#1
adr r8,2f
bx r7
.thumb
.balign 4
1:
ldrsh r0,[r5,r6]
bx r8
.arm
.balign 4
2:
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_str_alignment
.type cpu_arm7_thumb_str_alignment, %function
cpu_arm7_thumb_str_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
ldr r7,=0xa5a5a5a5
str r7,[r5]
adr r7,1f
orr r7,r7,#1
adr r8,2f
bx r7
.thumb
.balign 4
1:
str r0,[r5,r6]
ldr r0,[r5]
bx r8
.arm
.balign 4
2:
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_strh_alignment
.type cpu_arm7_thumb_strh_alignment, %function
cpu_arm7_thumb_strh_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
mov r6,r1
ldr r7,=0x6d37c2a9
str r7,[r5,#4]
ldr r7,=0xa5a5a5a5
str r7,[r5]
adr r7,1f
orr r7,r7,#1
adr r8,2f
bx r7
.thumb
.balign 4
1:
strh r0,[r5,r6]
ldr r0,[r5]
bx r8
.arm
.balign 4
2:
ldr r1,[r5,#4]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_swp_alignment
.type cpu_arm7_arm_swp_alignment, %function
cpu_arm7_arm_swp_alignment:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
str r0,[r5]
add r6,r5,r1
mvn r7,r0
swp r0,r7,[r6]
ldr r1,[r5]
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_pc_mov
.type cpu_arm7_arm_pc_mov, %function
cpu_arm7_arm_pc_mov:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r5,1f
mov r1,#0
mov r2,#0
mov r7,sp
1:
mov r0,pc
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_pc_shift_rm
.type cpu_arm7_arm_pc_shift_rm, %function
cpu_arm7_arm_pc_shift_rm:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r5,1f
mov r1,#0
mov r2,#0
mov r7,sp
1:
mov r0,pc,lsl r1
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_pc_shift_rn
.type cpu_arm7_arm_pc_shift_rn, %function
cpu_arm7_arm_pc_shift_rn:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r5,1f
mov r1,#0
mov r2,#0
mov r7,sp
1:
add r0,pc,r1,lsl r2
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_pc_str
.type cpu_arm7_arm_pc_str, %function
cpu_arm7_arm_pc_str:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r5,1f
mov r1,#0
mov r2,#0
mov r7,sp
1:
str pc,[sp]
ldr r0,[sp]
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_pc_stm
.type cpu_arm7_arm_pc_stm, %function
cpu_arm7_arm_pc_stm:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r5,1f
mov r1,#0
mov r2,#0
mov r7,sp
1:
stmia r7,{pc}
ldr r0,[sp]
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_pc_mov_0
.type cpu_arm7_thumb_pc_mov_0, %function
cpu_arm7_thumb_pc_mov_0:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r0,#0
adr r5,2f
adr r6,3f
adr r7,1f
orr r7,r7,#1
bx r7
.thumb
.balign 4
1:
2:
mov r0,pc
bx r6
.arm
.balign 4
3:
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_pc_mov_2
.type cpu_arm7_thumb_pc_mov_2, %function
cpu_arm7_thumb_pc_mov_2:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r0,#0
adr r5,2f
adr r6,3f
adr r7,1f
orr r7,r7,#1
bx r7
.thumb
.balign 4
1:
nop
2:
mov r0,pc
bx r6
.arm
.balign 4
3:
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_pc_add_0
.type cpu_arm7_thumb_pc_add_0, %function
cpu_arm7_thumb_pc_add_0:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r0,#0
adr r5,2f
adr r6,3f
adr r7,1f
orr r7,r7,#1
bx r7
.thumb
.balign 4
1:
2:
add r0,pc
bx r6
.arm
.balign 4
3:
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_pc_add_2
.type cpu_arm7_thumb_pc_add_2, %function
cpu_arm7_thumb_pc_add_2:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r0,#0
adr r5,2f
adr r6,3f
adr r7,1f
orr r7,r7,#1
bx r7
.thumb
.balign 4
1:
nop
2:
add r0,pc
bx r6
.arm
.balign 4
3:
sub r0,r0,r5
mov r1,#0
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_ldr_pc_no_exchange
.type cpu_arm7_arm_ldr_pc_no_exchange, %function
cpu_arm7_arm_ldr_pc_no_exchange:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r0,1f
orr r0,r0,#1
str r0,[sp]
ldr pc,[sp]
.balign 4
1:
mov r0,#0x79
mrs r1,cpsr
and r1,r1,#0x20
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_arm_ldm_pc_no_exchange
.type cpu_arm7_arm_ldm_pc_no_exchange, %function
cpu_arm7_arm_ldm_pc_no_exchange:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
adr r0,1f
orr r0,r0,#1
str r0,[sp]
ldmia sp,{pc}
.balign 4
1:
mov r0,#0x79
mrs r1,cpsr
and r1,r1,#0x20
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_thumb_pop_pc_no_exchange
.type cpu_arm7_thumb_pop_pc_no_exchange, %function
cpu_arm7_thumb_pop_pc_no_exchange:
push {r4-r8,lr}
mov r4,r3
sub sp,sp,#16
mov r5,sp
adr r0,2f
str r0,[sp,#-4]!
adr r6,3f
adr r7,1f
orr r7,r7,#1
bx r7
.thumb
.balign 4
1:
pop {pc}
.balign 4
2:
movs r0,#0x7d
bx r6
.arm
.balign 4
3:
sub r1,sp,r5
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#16
pop {r4-r8,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_sys_fiq
.type cpu_arm7_bank_sp_sys_fiq, %function
cpu_arm7_bank_sp_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,sp
mov sp,r0
msr cpsr_c,#209
mov r5,sp
mov sp,r1
msr cpsr_c,#223
mov r0,sp
mov sp,r2
msr cpsr_c,#209
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_sys_fiq
.type cpu_arm7_bank_lr_sys_fiq, %function
cpu_arm7_bank_lr_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,lr
mov lr,r0
msr cpsr_c,#209
mov r5,lr
mov lr,r1
msr cpsr_c,#223
mov r0,lr
mov lr,r2
msr cpsr_c,#209
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_sys_irq
.type cpu_arm7_bank_sp_sys_irq, %function
cpu_arm7_bank_sp_sys_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,sp
mov sp,r0
msr cpsr_c,#210
mov r5,sp
mov sp,r1
msr cpsr_c,#223
mov r0,sp
mov sp,r2
msr cpsr_c,#210
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_sys_irq
.type cpu_arm7_bank_lr_sys_irq, %function
cpu_arm7_bank_lr_sys_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,lr
mov lr,r0
msr cpsr_c,#210
mov r5,lr
mov lr,r1
msr cpsr_c,#223
mov r0,lr
mov lr,r2
msr cpsr_c,#210
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_sys_svc
.type cpu_arm7_bank_sp_sys_svc, %function
cpu_arm7_bank_sp_sys_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,sp
mov sp,r0
msr cpsr_c,#211
mov r5,sp
mov sp,r1
msr cpsr_c,#223
mov r0,sp
mov sp,r2
msr cpsr_c,#211
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_sys_svc
.type cpu_arm7_bank_lr_sys_svc, %function
cpu_arm7_bank_lr_sys_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,lr
mov lr,r0
msr cpsr_c,#211
mov r5,lr
mov lr,r1
msr cpsr_c,#223
mov r0,lr
mov lr,r2
msr cpsr_c,#211
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_sys_abt
.type cpu_arm7_bank_sp_sys_abt, %function
cpu_arm7_bank_sp_sys_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,sp
mov sp,r0
msr cpsr_c,#215
mov r5,sp
mov sp,r1
msr cpsr_c,#223
mov r0,sp
mov sp,r2
msr cpsr_c,#215
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_sys_abt
.type cpu_arm7_bank_lr_sys_abt, %function
cpu_arm7_bank_lr_sys_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,lr
mov lr,r0
msr cpsr_c,#215
mov r5,lr
mov lr,r1
msr cpsr_c,#223
mov r0,lr
mov lr,r2
msr cpsr_c,#215
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_sys_und
.type cpu_arm7_bank_sp_sys_und, %function
cpu_arm7_bank_sp_sys_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,sp
mov sp,r0
msr cpsr_c,#219
mov r5,sp
mov sp,r1
msr cpsr_c,#223
mov r0,sp
mov sp,r2
msr cpsr_c,#219
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_sys_und
.type cpu_arm7_bank_lr_sys_und, %function
cpu_arm7_bank_lr_sys_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,lr
mov lr,r0
msr cpsr_c,#219
mov r5,lr
mov lr,r1
msr cpsr_c,#223
mov r0,lr
mov lr,r2
msr cpsr_c,#219
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_fiq_sys
.type cpu_arm7_bank_sp_fiq_sys, %function
cpu_arm7_bank_sp_fiq_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,sp
mov sp,r0
msr cpsr_c,#223
mov r5,sp
mov sp,r1
msr cpsr_c,#209
mov r0,sp
mov sp,r2
msr cpsr_c,#223
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_fiq_sys
.type cpu_arm7_bank_lr_fiq_sys, %function
cpu_arm7_bank_lr_fiq_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,lr
mov lr,r0
msr cpsr_c,#223
mov r5,lr
mov lr,r1
msr cpsr_c,#209
mov r0,lr
mov lr,r2
msr cpsr_c,#223
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_fiq_irq
.type cpu_arm7_bank_sp_fiq_irq, %function
cpu_arm7_bank_sp_fiq_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,sp
mov sp,r0
msr cpsr_c,#210
mov r5,sp
mov sp,r1
msr cpsr_c,#209
mov r0,sp
mov sp,r2
msr cpsr_c,#210
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_fiq_irq
.type cpu_arm7_bank_lr_fiq_irq, %function
cpu_arm7_bank_lr_fiq_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,lr
mov lr,r0
msr cpsr_c,#210
mov r5,lr
mov lr,r1
msr cpsr_c,#209
mov r0,lr
mov lr,r2
msr cpsr_c,#210
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_fiq_svc
.type cpu_arm7_bank_sp_fiq_svc, %function
cpu_arm7_bank_sp_fiq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,sp
mov sp,r0
msr cpsr_c,#211
mov r5,sp
mov sp,r1
msr cpsr_c,#209
mov r0,sp
mov sp,r2
msr cpsr_c,#211
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_fiq_svc
.type cpu_arm7_bank_lr_fiq_svc, %function
cpu_arm7_bank_lr_fiq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,lr
mov lr,r0
msr cpsr_c,#211
mov r5,lr
mov lr,r1
msr cpsr_c,#209
mov r0,lr
mov lr,r2
msr cpsr_c,#211
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_fiq_abt
.type cpu_arm7_bank_sp_fiq_abt, %function
cpu_arm7_bank_sp_fiq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,sp
mov sp,r0
msr cpsr_c,#215
mov r5,sp
mov sp,r1
msr cpsr_c,#209
mov r0,sp
mov sp,r2
msr cpsr_c,#215
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_fiq_abt
.type cpu_arm7_bank_lr_fiq_abt, %function
cpu_arm7_bank_lr_fiq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,lr
mov lr,r0
msr cpsr_c,#215
mov r5,lr
mov lr,r1
msr cpsr_c,#209
mov r0,lr
mov lr,r2
msr cpsr_c,#215
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_fiq_und
.type cpu_arm7_bank_sp_fiq_und, %function
cpu_arm7_bank_sp_fiq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,sp
mov sp,r0
msr cpsr_c,#219
mov r5,sp
mov sp,r1
msr cpsr_c,#209
mov r0,sp
mov sp,r2
msr cpsr_c,#219
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_fiq_und
.type cpu_arm7_bank_lr_fiq_und, %function
cpu_arm7_bank_lr_fiq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mov r2,lr
mov lr,r0
msr cpsr_c,#219
mov r5,lr
mov lr,r1
msr cpsr_c,#209
mov r0,lr
mov lr,r2
msr cpsr_c,#219
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_irq_sys
.type cpu_arm7_bank_sp_irq_sys, %function
cpu_arm7_bank_sp_irq_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,sp
mov sp,r0
msr cpsr_c,#223
mov r5,sp
mov sp,r1
msr cpsr_c,#210
mov r0,sp
mov sp,r2
msr cpsr_c,#223
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_irq_sys
.type cpu_arm7_bank_lr_irq_sys, %function
cpu_arm7_bank_lr_irq_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,lr
mov lr,r0
msr cpsr_c,#223
mov r5,lr
mov lr,r1
msr cpsr_c,#210
mov r0,lr
mov lr,r2
msr cpsr_c,#223
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_irq_fiq
.type cpu_arm7_bank_sp_irq_fiq, %function
cpu_arm7_bank_sp_irq_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,sp
mov sp,r0
msr cpsr_c,#209
mov r5,sp
mov sp,r1
msr cpsr_c,#210
mov r0,sp
mov sp,r2
msr cpsr_c,#209
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_irq_fiq
.type cpu_arm7_bank_lr_irq_fiq, %function
cpu_arm7_bank_lr_irq_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,lr
mov lr,r0
msr cpsr_c,#209
mov r5,lr
mov lr,r1
msr cpsr_c,#210
mov r0,lr
mov lr,r2
msr cpsr_c,#209
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_irq_svc
.type cpu_arm7_bank_sp_irq_svc, %function
cpu_arm7_bank_sp_irq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,sp
mov sp,r0
msr cpsr_c,#211
mov r5,sp
mov sp,r1
msr cpsr_c,#210
mov r0,sp
mov sp,r2
msr cpsr_c,#211
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_irq_svc
.type cpu_arm7_bank_lr_irq_svc, %function
cpu_arm7_bank_lr_irq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,lr
mov lr,r0
msr cpsr_c,#211
mov r5,lr
mov lr,r1
msr cpsr_c,#210
mov r0,lr
mov lr,r2
msr cpsr_c,#211
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_irq_abt
.type cpu_arm7_bank_sp_irq_abt, %function
cpu_arm7_bank_sp_irq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,sp
mov sp,r0
msr cpsr_c,#215
mov r5,sp
mov sp,r1
msr cpsr_c,#210
mov r0,sp
mov sp,r2
msr cpsr_c,#215
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_irq_abt
.type cpu_arm7_bank_lr_irq_abt, %function
cpu_arm7_bank_lr_irq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,lr
mov lr,r0
msr cpsr_c,#215
mov r5,lr
mov lr,r1
msr cpsr_c,#210
mov r0,lr
mov lr,r2
msr cpsr_c,#215
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_irq_und
.type cpu_arm7_bank_sp_irq_und, %function
cpu_arm7_bank_sp_irq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,sp
mov sp,r0
msr cpsr_c,#219
mov r5,sp
mov sp,r1
msr cpsr_c,#210
mov r0,sp
mov sp,r2
msr cpsr_c,#219
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_irq_und
.type cpu_arm7_bank_lr_irq_und, %function
cpu_arm7_bank_lr_irq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mov r2,lr
mov lr,r0
msr cpsr_c,#219
mov r5,lr
mov lr,r1
msr cpsr_c,#210
mov r0,lr
mov lr,r2
msr cpsr_c,#219
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_svc_sys
.type cpu_arm7_bank_sp_svc_sys, %function
cpu_arm7_bank_sp_svc_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,sp
mov sp,r0
msr cpsr_c,#223
mov r5,sp
mov sp,r1
msr cpsr_c,#211
mov r0,sp
mov sp,r2
msr cpsr_c,#223
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_svc_sys
.type cpu_arm7_bank_lr_svc_sys, %function
cpu_arm7_bank_lr_svc_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,lr
mov lr,r0
msr cpsr_c,#223
mov r5,lr
mov lr,r1
msr cpsr_c,#211
mov r0,lr
mov lr,r2
msr cpsr_c,#223
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_svc_fiq
.type cpu_arm7_bank_sp_svc_fiq, %function
cpu_arm7_bank_sp_svc_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,sp
mov sp,r0
msr cpsr_c,#209
mov r5,sp
mov sp,r1
msr cpsr_c,#211
mov r0,sp
mov sp,r2
msr cpsr_c,#209
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_svc_fiq
.type cpu_arm7_bank_lr_svc_fiq, %function
cpu_arm7_bank_lr_svc_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,lr
mov lr,r0
msr cpsr_c,#209
mov r5,lr
mov lr,r1
msr cpsr_c,#211
mov r0,lr
mov lr,r2
msr cpsr_c,#209
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_svc_irq
.type cpu_arm7_bank_sp_svc_irq, %function
cpu_arm7_bank_sp_svc_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,sp
mov sp,r0
msr cpsr_c,#210
mov r5,sp
mov sp,r1
msr cpsr_c,#211
mov r0,sp
mov sp,r2
msr cpsr_c,#210
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_svc_irq
.type cpu_arm7_bank_lr_svc_irq, %function
cpu_arm7_bank_lr_svc_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,lr
mov lr,r0
msr cpsr_c,#210
mov r5,lr
mov lr,r1
msr cpsr_c,#211
mov r0,lr
mov lr,r2
msr cpsr_c,#210
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_svc_abt
.type cpu_arm7_bank_sp_svc_abt, %function
cpu_arm7_bank_sp_svc_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,sp
mov sp,r0
msr cpsr_c,#215
mov r5,sp
mov sp,r1
msr cpsr_c,#211
mov r0,sp
mov sp,r2
msr cpsr_c,#215
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_svc_abt
.type cpu_arm7_bank_lr_svc_abt, %function
cpu_arm7_bank_lr_svc_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,lr
mov lr,r0
msr cpsr_c,#215
mov r5,lr
mov lr,r1
msr cpsr_c,#211
mov r0,lr
mov lr,r2
msr cpsr_c,#215
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_svc_und
.type cpu_arm7_bank_sp_svc_und, %function
cpu_arm7_bank_sp_svc_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,sp
mov sp,r0
msr cpsr_c,#219
mov r5,sp
mov sp,r1
msr cpsr_c,#211
mov r0,sp
mov sp,r2
msr cpsr_c,#219
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_svc_und
.type cpu_arm7_bank_lr_svc_und, %function
cpu_arm7_bank_lr_svc_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mov r2,lr
mov lr,r0
msr cpsr_c,#219
mov r5,lr
mov lr,r1
msr cpsr_c,#211
mov r0,lr
mov lr,r2
msr cpsr_c,#219
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_abt_sys
.type cpu_arm7_bank_sp_abt_sys, %function
cpu_arm7_bank_sp_abt_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,sp
mov sp,r0
msr cpsr_c,#223
mov r5,sp
mov sp,r1
msr cpsr_c,#215
mov r0,sp
mov sp,r2
msr cpsr_c,#223
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_abt_sys
.type cpu_arm7_bank_lr_abt_sys, %function
cpu_arm7_bank_lr_abt_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,lr
mov lr,r0
msr cpsr_c,#223
mov r5,lr
mov lr,r1
msr cpsr_c,#215
mov r0,lr
mov lr,r2
msr cpsr_c,#223
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_abt_fiq
.type cpu_arm7_bank_sp_abt_fiq, %function
cpu_arm7_bank_sp_abt_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,sp
mov sp,r0
msr cpsr_c,#209
mov r5,sp
mov sp,r1
msr cpsr_c,#215
mov r0,sp
mov sp,r2
msr cpsr_c,#209
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_abt_fiq
.type cpu_arm7_bank_lr_abt_fiq, %function
cpu_arm7_bank_lr_abt_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,lr
mov lr,r0
msr cpsr_c,#209
mov r5,lr
mov lr,r1
msr cpsr_c,#215
mov r0,lr
mov lr,r2
msr cpsr_c,#209
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_abt_irq
.type cpu_arm7_bank_sp_abt_irq, %function
cpu_arm7_bank_sp_abt_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,sp
mov sp,r0
msr cpsr_c,#210
mov r5,sp
mov sp,r1
msr cpsr_c,#215
mov r0,sp
mov sp,r2
msr cpsr_c,#210
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_abt_irq
.type cpu_arm7_bank_lr_abt_irq, %function
cpu_arm7_bank_lr_abt_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,lr
mov lr,r0
msr cpsr_c,#210
mov r5,lr
mov lr,r1
msr cpsr_c,#215
mov r0,lr
mov lr,r2
msr cpsr_c,#210
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_abt_svc
.type cpu_arm7_bank_sp_abt_svc, %function
cpu_arm7_bank_sp_abt_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,sp
mov sp,r0
msr cpsr_c,#211
mov r5,sp
mov sp,r1
msr cpsr_c,#215
mov r0,sp
mov sp,r2
msr cpsr_c,#211
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_abt_svc
.type cpu_arm7_bank_lr_abt_svc, %function
cpu_arm7_bank_lr_abt_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,lr
mov lr,r0
msr cpsr_c,#211
mov r5,lr
mov lr,r1
msr cpsr_c,#215
mov r0,lr
mov lr,r2
msr cpsr_c,#211
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_abt_und
.type cpu_arm7_bank_sp_abt_und, %function
cpu_arm7_bank_sp_abt_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,sp
mov sp,r0
msr cpsr_c,#219
mov r5,sp
mov sp,r1
msr cpsr_c,#215
mov r0,sp
mov sp,r2
msr cpsr_c,#219
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_abt_und
.type cpu_arm7_bank_lr_abt_und, %function
cpu_arm7_bank_lr_abt_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mov r2,lr
mov lr,r0
msr cpsr_c,#219
mov r5,lr
mov lr,r1
msr cpsr_c,#215
mov r0,lr
mov lr,r2
msr cpsr_c,#219
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_und_sys
.type cpu_arm7_bank_sp_und_sys, %function
cpu_arm7_bank_sp_und_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,sp
mov sp,r0
msr cpsr_c,#223
mov r5,sp
mov sp,r1
msr cpsr_c,#219
mov r0,sp
mov sp,r2
msr cpsr_c,#223
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_und_sys
.type cpu_arm7_bank_lr_und_sys, %function
cpu_arm7_bank_lr_und_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,lr
mov lr,r0
msr cpsr_c,#223
mov r5,lr
mov lr,r1
msr cpsr_c,#219
mov r0,lr
mov lr,r2
msr cpsr_c,#223
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_und_fiq
.type cpu_arm7_bank_sp_und_fiq, %function
cpu_arm7_bank_sp_und_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,sp
mov sp,r0
msr cpsr_c,#209
mov r5,sp
mov sp,r1
msr cpsr_c,#219
mov r0,sp
mov sp,r2
msr cpsr_c,#209
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_und_fiq
.type cpu_arm7_bank_lr_und_fiq, %function
cpu_arm7_bank_lr_und_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,lr
mov lr,r0
msr cpsr_c,#209
mov r5,lr
mov lr,r1
msr cpsr_c,#219
mov r0,lr
mov lr,r2
msr cpsr_c,#209
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_und_irq
.type cpu_arm7_bank_sp_und_irq, %function
cpu_arm7_bank_sp_und_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,sp
mov sp,r0
msr cpsr_c,#210
mov r5,sp
mov sp,r1
msr cpsr_c,#219
mov r0,sp
mov sp,r2
msr cpsr_c,#210
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_und_irq
.type cpu_arm7_bank_lr_und_irq, %function
cpu_arm7_bank_lr_und_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,lr
mov lr,r0
msr cpsr_c,#210
mov r5,lr
mov lr,r1
msr cpsr_c,#219
mov r0,lr
mov lr,r2
msr cpsr_c,#210
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_und_svc
.type cpu_arm7_bank_sp_und_svc, %function
cpu_arm7_bank_sp_und_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,sp
mov sp,r0
msr cpsr_c,#211
mov r5,sp
mov sp,r1
msr cpsr_c,#219
mov r0,sp
mov sp,r2
msr cpsr_c,#211
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_und_svc
.type cpu_arm7_bank_lr_und_svc, %function
cpu_arm7_bank_lr_und_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,lr
mov lr,r0
msr cpsr_c,#211
mov r5,lr
mov lr,r1
msr cpsr_c,#219
mov r0,lr
mov lr,r2
msr cpsr_c,#211
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_sp_und_abt
.type cpu_arm7_bank_sp_und_abt, %function
cpu_arm7_bank_sp_und_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,sp
mov sp,r0
msr cpsr_c,#215
mov r5,sp
mov sp,r1
msr cpsr_c,#219
mov r0,sp
mov sp,r2
msr cpsr_c,#215
mov r1,sp
mov sp,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_lr_und_abt
.type cpu_arm7_bank_lr_und_abt, %function
cpu_arm7_bank_lr_und_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mov r2,lr
mov lr,r0
msr cpsr_c,#215
mov r5,lr
mov lr,r1
msr cpsr_c,#219
mov r0,lr
mov lr,r2
msr cpsr_c,#215
mov r1,lr
mov lr,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_r8_sys_fiq
.type cpu_arm7_bank_r8_sys_fiq, %function
cpu_arm7_bank_r8_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,r8
mov r8,r0
msr cpsr_c,#209
mov r5,r8
mov r8,r1
msr cpsr_c,#223
mov r0,r8
mov r8,r2
msr cpsr_c,#209
mov r1,r8
mov r8,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_r9_sys_fiq
.type cpu_arm7_bank_r9_sys_fiq, %function
cpu_arm7_bank_r9_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,r9
mov r9,r0
msr cpsr_c,#209
mov r5,r9
mov r9,r1
msr cpsr_c,#223
mov r0,r9
mov r9,r2
msr cpsr_c,#209
mov r1,r9
mov r9,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_r10_sys_fiq
.type cpu_arm7_bank_r10_sys_fiq, %function
cpu_arm7_bank_r10_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,r10
mov r10,r0
msr cpsr_c,#209
mov r5,r10
mov r10,r1
msr cpsr_c,#223
mov r0,r10
mov r10,r2
msr cpsr_c,#209
mov r1,r10
mov r10,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_r11_sys_fiq
.type cpu_arm7_bank_r11_sys_fiq, %function
cpu_arm7_bank_r11_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,r11
mov r11,r0
msr cpsr_c,#209
mov r5,r11
mov r11,r1
msr cpsr_c,#223
mov r0,r11
mov r11,r2
msr cpsr_c,#209
mov r1,r11
mov r11,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_bank_r12_sys_fiq
.type cpu_arm7_bank_r12_sys_fiq, %function
cpu_arm7_bank_r12_sys_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#223
mov r2,r12
mov r12,r0
msr cpsr_c,#209
mov r5,r12
mov r12,r1
msr cpsr_c,#223
mov r0,r12
mov r12,r2
msr cpsr_c,#209
mov r1,r12
mov r12,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_fiq_irq
.type cpu_arm7_spsr_banks_fiq_irq, %function
cpu_arm7_spsr_banks_fiq_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#210
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#209
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#210
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_fiq_svc
.type cpu_arm7_spsr_banks_fiq_svc, %function
cpu_arm7_spsr_banks_fiq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#211
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#209
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#211
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_fiq_abt
.type cpu_arm7_spsr_banks_fiq_abt, %function
cpu_arm7_spsr_banks_fiq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#215
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#209
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#215
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_fiq_und
.type cpu_arm7_spsr_banks_fiq_und, %function
cpu_arm7_spsr_banks_fiq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#219
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#209
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#219
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_irq_fiq
.type cpu_arm7_spsr_banks_irq_fiq, %function
cpu_arm7_spsr_banks_irq_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#209
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#210
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#209
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_irq_svc
.type cpu_arm7_spsr_banks_irq_svc, %function
cpu_arm7_spsr_banks_irq_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#211
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#210
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#211
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_irq_abt
.type cpu_arm7_spsr_banks_irq_abt, %function
cpu_arm7_spsr_banks_irq_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#215
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#210
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#215
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_irq_und
.type cpu_arm7_spsr_banks_irq_und, %function
cpu_arm7_spsr_banks_irq_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#219
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#210
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#219
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_svc_fiq
.type cpu_arm7_spsr_banks_svc_fiq, %function
cpu_arm7_spsr_banks_svc_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#209
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#211
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#209
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_svc_irq
.type cpu_arm7_spsr_banks_svc_irq, %function
cpu_arm7_spsr_banks_svc_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#210
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#211
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#210
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_svc_abt
.type cpu_arm7_spsr_banks_svc_abt, %function
cpu_arm7_spsr_banks_svc_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#215
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#211
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#215
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_svc_und
.type cpu_arm7_spsr_banks_svc_und, %function
cpu_arm7_spsr_banks_svc_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#219
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#211
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#219
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_abt_fiq
.type cpu_arm7_spsr_banks_abt_fiq, %function
cpu_arm7_spsr_banks_abt_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#209
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#215
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#209
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_abt_irq
.type cpu_arm7_spsr_banks_abt_irq, %function
cpu_arm7_spsr_banks_abt_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#210
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#215
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#210
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_abt_svc
.type cpu_arm7_spsr_banks_abt_svc, %function
cpu_arm7_spsr_banks_abt_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#211
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#215
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#211
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_abt_und
.type cpu_arm7_spsr_banks_abt_und, %function
cpu_arm7_spsr_banks_abt_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#219
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#215
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#219
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_und_fiq
.type cpu_arm7_spsr_banks_und_fiq, %function
cpu_arm7_spsr_banks_und_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#209
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#219
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#209
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_und_irq
.type cpu_arm7_spsr_banks_und_irq, %function
cpu_arm7_spsr_banks_und_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#210
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#219
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#210
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_und_svc
.type cpu_arm7_spsr_banks_und_svc, %function
cpu_arm7_spsr_banks_und_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#211
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#219
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#211
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_banks_und_abt
.type cpu_arm7_spsr_banks_und_abt, %function
cpu_arm7_spsr_banks_und_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr cpsr_c,#215
mrs r5,spsr
msr spsr_fsxc,r1
msr cpsr_c,#219
mrs r0,spsr
msr spsr_fsxc,r2
msr cpsr_c,#215
mrs r1,spsr
msr spsr_fsxc,r5
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_f_fiq
.type cpu_arm7_spsr_field_f_fiq, %function
cpu_arm7_spsr_field_f_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_f,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_c_fiq
.type cpu_arm7_spsr_field_c_fiq, %function
cpu_arm7_spsr_field_c_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_c,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_f_irq
.type cpu_arm7_spsr_field_f_irq, %function
cpu_arm7_spsr_field_f_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_f,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_c_irq
.type cpu_arm7_spsr_field_c_irq, %function
cpu_arm7_spsr_field_c_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_c,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_f_svc
.type cpu_arm7_spsr_field_f_svc, %function
cpu_arm7_spsr_field_f_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_f,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_c_svc
.type cpu_arm7_spsr_field_c_svc, %function
cpu_arm7_spsr_field_c_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_c,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_f_abt
.type cpu_arm7_spsr_field_f_abt, %function
cpu_arm7_spsr_field_f_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_f,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_c_abt
.type cpu_arm7_spsr_field_c_abt, %function
cpu_arm7_spsr_field_c_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_c,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_f_und
.type cpu_arm7_spsr_field_f_und, %function
cpu_arm7_spsr_field_f_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_f,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_spsr_field_c_und
.type cpu_arm7_spsr_field_c_und, %function
cpu_arm7_spsr_field_c_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
msr spsr_fsxc,r0
msr spsr_c,r1
mrs r0,spsr
msr spsr_fsxc,r2
mrs r1,spsr
eor r1,r1,r2
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_sys
.type cpu_arm7_cpsr_mode_sys, %function
cpu_arm7_cpsr_mode_sys:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#223
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_fiq
.type cpu_arm7_cpsr_mode_fiq, %function
cpu_arm7_cpsr_mode_fiq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#209
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_irq
.type cpu_arm7_cpsr_mode_irq, %function
cpu_arm7_cpsr_mode_irq:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#210
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_svc
.type cpu_arm7_cpsr_mode_svc, %function
cpu_arm7_cpsr_mode_svc:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#211
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_abt
.type cpu_arm7_cpsr_mode_abt, %function
cpu_arm7_cpsr_mode_abt:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#215
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_cpsr_mode_und
.type cpu_arm7_cpsr_mode_und, %function
cpu_arm7_cpsr_mode_und:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r0
msr cpsr_c,#219
mrs r0,cpsr
ldr r2,=0xf00000ff
and r0,r0,r2
mov r1,#0
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_fiq_arm
.type cpu_arm7_return_movs_fiq_arm, %function
cpu_arm7_return_movs_fiq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_fiq_thumb
.type cpu_arm7_return_movs_fiq_thumb, %function
cpu_arm7_return_movs_fiq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_fiq_arm
.type cpu_arm7_return_subs_fiq_arm, %function
cpu_arm7_return_subs_fiq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_fiq_thumb
.type cpu_arm7_return_subs_fiq_thumb, %function
cpu_arm7_return_subs_fiq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_fiq_arm
.type cpu_arm7_return_ldm_fiq_arm, %function
cpu_arm7_return_ldm_fiq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_fiq_thumb
.type cpu_arm7_return_ldm_fiq_thumb, %function
cpu_arm7_return_ldm_fiq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#209
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#209
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_irq_arm
.type cpu_arm7_return_movs_irq_arm, %function
cpu_arm7_return_movs_irq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_irq_thumb
.type cpu_arm7_return_movs_irq_thumb, %function
cpu_arm7_return_movs_irq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_irq_arm
.type cpu_arm7_return_subs_irq_arm, %function
cpu_arm7_return_subs_irq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_irq_thumb
.type cpu_arm7_return_subs_irq_thumb, %function
cpu_arm7_return_subs_irq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_irq_arm
.type cpu_arm7_return_ldm_irq_arm, %function
cpu_arm7_return_ldm_irq_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_irq_thumb
.type cpu_arm7_return_ldm_irq_thumb, %function
cpu_arm7_return_ldm_irq_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#210
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#210
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_svc_arm
.type cpu_arm7_return_movs_svc_arm, %function
cpu_arm7_return_movs_svc_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_svc_thumb
.type cpu_arm7_return_movs_svc_thumb, %function
cpu_arm7_return_movs_svc_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_svc_arm
.type cpu_arm7_return_subs_svc_arm, %function
cpu_arm7_return_subs_svc_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_svc_thumb
.type cpu_arm7_return_subs_svc_thumb, %function
cpu_arm7_return_subs_svc_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_svc_arm
.type cpu_arm7_return_ldm_svc_arm, %function
cpu_arm7_return_ldm_svc_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_svc_thumb
.type cpu_arm7_return_ldm_svc_thumb, %function
cpu_arm7_return_ldm_svc_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#211
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#211
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_abt_arm
.type cpu_arm7_return_movs_abt_arm, %function
cpu_arm7_return_movs_abt_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_abt_thumb
.type cpu_arm7_return_movs_abt_thumb, %function
cpu_arm7_return_movs_abt_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_abt_arm
.type cpu_arm7_return_subs_abt_arm, %function
cpu_arm7_return_subs_abt_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_abt_thumb
.type cpu_arm7_return_subs_abt_thumb, %function
cpu_arm7_return_subs_abt_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_abt_arm
.type cpu_arm7_return_ldm_abt_arm, %function
cpu_arm7_return_ldm_abt_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_abt_thumb
.type cpu_arm7_return_ldm_abt_thumb, %function
cpu_arm7_return_ldm_abt_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#215
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#215
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_und_arm
.type cpu_arm7_return_movs_und_arm, %function
cpu_arm7_return_movs_und_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_movs_und_thumb
.type cpu_arm7_return_movs_und_thumb, %function
cpu_arm7_return_movs_und_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
mov lr,r1
movs pc,lr
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_und_arm
.type cpu_arm7_return_subs_und_arm, %function
cpu_arm7_return_subs_und_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_subs_und_thumb
.type cpu_arm7_return_subs_und_thumb, %function
cpu_arm7_return_subs_und_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
add lr,r1,#4
subs pc,lr,#4
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_und_arm
.type cpu_arm7_return_ldm_und_arm, %function
cpu_arm7_return_ldm_und_arm:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#223
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.arm
.balign 4
1:
mov r0,#4
2:
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_return_ldm_und_thumb
.type cpu_arm7_return_ldm_und_thumb, %function
cpu_arm7_return_ldm_und_thumb:
push {r4-r11,lr}
sub sp,sp,#20
mov r7,sp
mov r4,r3
mrs r6,cpsr
msr cpsr_c,#219
mrs r2,spsr
str r2,[r7]
str lr,[r7,#4]
orr r0,r0,#255
msr spsr_fsxc,r0
adr r1,1f
str r1,[r7,#8]
adr r2,2f
str r1,[r7,#12]
add r5,r7,#12
ldmia r5,{pc}^
.thumb
.balign 4
1:
mov r0,pc
bx r2
.arm
.balign 4
2:
ldr r2,[r7,#8]
sub r0,r0,r2
mrs r1,cpsr
msr cpsr_c,#219
ldr r2,[r7]
msr spsr_fsxc,r2
ldr lr,[r7,#4]
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#20
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_arm
.type cpu_arm7_irq_entry_arm, %function
cpu_arm7_irq_entry_arm:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
mov r10,r0
orr r0,r0,#95
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
str r2,[r3]
.rept 2048
nop
.endr
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_thumb
.type cpu_arm7_irq_entry_thumb, %function
cpu_arm7_irq_entry_thumb:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
mov r10,r0
orr r0,r0,#95
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
adr r0,1f
orr r0,r0,#1
bx r0
.thumb
.balign 4
1:
str r2,[r3]
.rept 2048
nop
.endr
bx r8
.arm
.balign 4
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_user
.type cpu_arm7_irq_entry_user, %function
cpu_arm7_irq_entry_user:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
mov r10,r0
eor r0,r0,#0xf0000000
orr r0,r0,#95
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
msr cpsr_c,#0x50
msr cpsr_f,r10
msr cpsr_c,#0xd3
sub r9,sp,r7
str r2,[r3]
.rept 2048
nop
.endr
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
cmp r9,#0
movne r9,#0x20000
orr r1,r1,r9
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_masked_i
.type cpu_arm7_irq_entry_masked_i, %function
cpu_arm7_irq_entry_masked_i:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
mov r10,r0
orr r0,r0,#223
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
str r2,[r3]
.rept 2048
nop
.endr
ldr r0,=cpu_arm7_irq_capture
ldr r11,[r0]
mrs r0,cpsr
bic r0,r0,#0x80
msr cpsr_c,r0
b 8f
.ltorg
8:
.rept 2048
nop
.endr
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
cmp r11,#0
movne r11,#0x40000
orr r1,r1,r11
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_masked_ime
.type cpu_arm7_irq_entry_masked_ime, %function
cpu_arm7_irq_entry_masked_ime:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
mov r10,r0
orr r0,r0,#95
msr cpsr_fsxc,r0
mov r1,#0
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
str r2,[r3]
.rept 2048
nop
.endr
ldr r0,=cpu_arm7_irq_capture
ldr r11,[r0]
mov r0,#1
str r0,[r5,#8]
b 8f
.ltorg
8:
.rept 2048
nop
.endr
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
cmp r11,#0
movne r11,#0x40000
orr r1,r1,r11
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_entry_masked_ie
.type cpu_arm7_irq_entry_masked_ie, %function
cpu_arm7_irq_entry_masked_ie:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_timer_irq_handler
str r2,[r3]
ldr r3,=0x0400010c
ldr r2,[r3]
str r2,[r7,#12]
str r1,[r3]
ldr r8,=cpu_arm7_irq_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
str r2,[r8,#8]
mov r2,#64
str r2,[r5,#16]
str r2,[r5,#20]
mov r1,#0
str r1,[r5,#16]
ldr r0,[r7,#16]
mov r10,r0
orr r0,r0,#95
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
str r2,[r3]
.rept 2048
nop
.endr
ldr r0,=cpu_arm7_irq_capture
ldr r11,[r0]
mov r0,#64
str r0,[r5,#16]
b 8f
.ltorg
8:
.rept 2048
nop
.endr
2:
mrs r0,cpsr
orr r0,r0,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x0400010c
str r1,[r3]
mov r1,#64
str r1,[r5,#20]
ldr r2,[r7,#12]
str r2,[r3]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_irq_capture
ldr r0,[r3,#8]
ldr r2,=0xf00000ff
and r0,r0,r2
ldr r1,[r3,#4]
and r1,r1,#0xff
ldr r2,[r3]
eor r2,r2,#1
orr r1,r1,r2,lsl #16
cmp r11,#0
movne r11,#0x40000
orr r1,r1,r11
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_timer_irq_handler
cpu_arm7_timer_irq_handler:
ldr r0,=0x0400010c
mov r1,#0
strh r1,[r0,#2]
ldr r0,=0x04000214
mov r1,#64
str r1,[r0]
ldr r0,=cpu_arm7_irq_capture
mrs r1,cpsr
str r1,[r0,#4]
mrs r1,spsr
str r1,[r0,#8]
and r2,r1,#0x1f
cmp r2,#0x10
bne 1f
bic r1,r1,#0x1f
orr r1,r1,#0x1f
msr spsr_c,r1
1:
ldr r1,[r0]
add r1,r1,#1
str r1,[r0]
bx lr
.ltorg
.bss
.balign 4
cpu_arm7_irq_capture:
.space 12
.text
.arm
.balign 4
.global cpu_arm7_irq_nested_arm
.type cpu_arm7_irq_nested_arm, %function
cpu_arm7_irq_nested_arm:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_nested_handler
str r2,[r3]
ldr r3,=0x04000108
ldr r2,[r3]
str r2,[r7,#20]
str r1,[r3]
ldr r2,[r3,#4]
str r2,[r7,#12]
str r1,[r3,#4]
ldr r8,=cpu_arm7_nested_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
mov r2,#0x60
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
orr r0,r0,#0x5f
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r3,=0x0400010c
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
str r2,[r3]
.rept 4096
nop
.endr
2:
mrs r8,cpsr
orr r0,r8,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x04000108
str r1,[r3]
str r1,[r3,#4]
mov r1,#0x60
str r1,[r5,#20]
ldr r2,[r7,#20]
str r2,[r3]
ldr r2,[r7,#12]
str r2,[r3,#4]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_nested_capture
ldr r0,[r3,#4]
ldr r2,=0xf00000ff
and r0,r0,r2
and r1,r8,r2
ldr r2,[r3]
cmp r2,#2
orrne r1,r1,#0x100
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_irq_nested_thumb
.type cpu_arm7_irq_nested_thumb, %function
cpu_arm7_irq_nested_thumb:
push {r4-r11,lr}
sub sp,sp,#36
mov r7,sp
mov r4,r3
mrs r6,cpsr
str r0,[r7,#16]
orr r1,r6,#0xc0
msr cpsr_c,r1
ldr r5,=0x04000200
ldr r2,[r5,#8]
str r2,[r7]
mov r1,#0
str r1,[r5,#8]
ldr r2,[r5,#16]
str r2,[r7,#4]
ldr r3,=0x0380fffc
ldr r2,[r3]
str r2,[r7,#8]
ldr r2,=cpu_arm7_nested_handler
str r2,[r3]
ldr r3,=0x04000108
ldr r2,[r3]
str r2,[r7,#20]
str r1,[r3]
ldr r2,[r3,#4]
str r2,[r7,#12]
str r1,[r3,#4]
ldr r8,=cpu_arm7_nested_capture
str r1,[r8]
ldr r2,=0xbaadc0de
str r2,[r8,#4]
mov r2,#0x60
str r2,[r5,#16]
str r2,[r5,#20]
ldr r0,[r7,#16]
orr r0,r0,#0x5f
msr cpsr_fsxc,r0
mov r1,#1
str r1,[r5,#8]
ldr r3,=0x0400010c
ldr r2,=0x00c0ff80
ldr r8,=2f
b 9f
.ltorg
9:
adr r0,1f
orr r0,r0,#1
bx r0
.thumb
.balign 4
1:
str r2,[r3]
.rept 4096
nop
.endr
bx r8
.arm
.balign 4
2:
mrs r8,cpsr
orr r0,r8,#0xc0
msr cpsr_c,r0
mov r1,#0
str r1,[r5,#8]
ldr r3,=0x04000108
str r1,[r3]
str r1,[r3,#4]
mov r1,#0x60
str r1,[r5,#20]
ldr r2,[r7,#20]
str r2,[r3]
ldr r2,[r7,#12]
str r2,[r3,#4]
ldr r3,=0x0380fffc
ldr r2,[r7,#8]
str r2,[r3]
ldr r2,[r7,#4]
str r2,[r5,#16]
ldr r2,[r7]
str r2,[r5,#8]
ldr r3,=cpu_arm7_nested_capture
ldr r0,[r3,#4]
ldr r2,=0xf00000ff
and r0,r0,r2
and r1,r8,r2
ldr r2,[r3]
cmp r2,#2
orrne r1,r1,#0x100
msr cpsr_fsxc,r6
mov sp,r7
str r0,[r4]
str r1,[r4,#4]
add sp,sp,#36
pop {r4-r11,lr}
bx lr
.ltorg
.arm
.balign 4
.global cpu_arm7_nested_handler
cpu_arm7_nested_handler:
ldr r0,=cpu_arm7_nested_capture
ldr r1,[r0]
cmp r1,#0
bne 2f
push {r4-r11,lr}
mrs r4,spsr
mov r5,r0
mov r1,#1
str r1,[r5]
ldr r0,=0x0400010c
mov r1,#0
strh r1,[r0,#2]
ldr r0,=0x04000214
mov r1,#64
str r1,[r0]
and r0,r4,#0xf0000000
orr r0,r0,#0x52
msr cpsr_fsxc,r0
ldr r0,=0x04000108
ldr r1,=0x00c0ff80
b 9f
.ltorg
9:
str r1,[r0]
.rept 2048
nop
.endr
mrs r0,cpsr
orr r0,r0,#0x80
msr cpsr_c,r0
msr spsr_fsxc,r4
pop {r4-r11,lr}
bx lr
2:
mrs r1,spsr
str r1,[r0,#4]
mov r1,#2
str r1,[r0]
ldr r0,=0x04000108
mov r1,#0
strh r1,[r0,#2]
ldr r0,=0x04000214
mov r1,#32
str r1,[r0]
bx lr
.ltorg
.bss
.balign 4
cpu_arm7_nested_capture:
.space 8
.text
.arm
.balign 4
.global cpu_arm7_adc_register_operand2_lsl
.type cpu_arm7_adc_register_operand2_lsl, %function
cpu_arm7_adc_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
adcs r0,r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_adc_register_operand2_lsr
.type cpu_arm7_adc_register_operand2_lsr, %function
cpu_arm7_adc_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
adcs r0,r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_adc_register_operand2_asr
.type cpu_arm7_adc_register_operand2_asr, %function
cpu_arm7_adc_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
adcs r0,r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_adc_register_operand2_ror
.type cpu_arm7_adc_register_operand2_ror, %function
cpu_arm7_adc_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
adcs r0,r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_sbc_register_operand2_lsl
.type cpu_arm7_sbc_register_operand2_lsl, %function
cpu_arm7_sbc_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
sbcs r0,r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_sbc_register_operand2_lsr
.type cpu_arm7_sbc_register_operand2_lsr, %function
cpu_arm7_sbc_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
sbcs r0,r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_sbc_register_operand2_asr
.type cpu_arm7_sbc_register_operand2_asr, %function
cpu_arm7_sbc_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
sbcs r0,r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_sbc_register_operand2_ror
.type cpu_arm7_sbc_register_operand2_ror, %function
cpu_arm7_sbc_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
sbcs r0,r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_and_register_operand2_lsl
.type cpu_arm7_and_register_operand2_lsl, %function
cpu_arm7_and_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
ands r0,r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_and_register_operand2_lsr
.type cpu_arm7_and_register_operand2_lsr, %function
cpu_arm7_and_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
ands r0,r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_and_register_operand2_asr
.type cpu_arm7_and_register_operand2_asr, %function
cpu_arm7_and_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
ands r0,r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_and_register_operand2_ror
.type cpu_arm7_and_register_operand2_ror, %function
cpu_arm7_and_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
ands r0,r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_eor_register_operand2_lsl
.type cpu_arm7_eor_register_operand2_lsl, %function
cpu_arm7_eor_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
eors r0,r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_eor_register_operand2_lsr
.type cpu_arm7_eor_register_operand2_lsr, %function
cpu_arm7_eor_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
eors r0,r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_eor_register_operand2_asr
.type cpu_arm7_eor_register_operand2_asr, %function
cpu_arm7_eor_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
eors r0,r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_eor_register_operand2_ror
.type cpu_arm7_eor_register_operand2_ror, %function
cpu_arm7_eor_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
eors r0,r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_tst_register_operand2_lsl
.type cpu_arm7_tst_register_operand2_lsl, %function
cpu_arm7_tst_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
tst r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_tst_register_operand2_lsr
.type cpu_arm7_tst_register_operand2_lsr, %function
cpu_arm7_tst_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
tst r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_tst_register_operand2_asr
.type cpu_arm7_tst_register_operand2_asr, %function
cpu_arm7_tst_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
tst r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_tst_register_operand2_ror
.type cpu_arm7_tst_register_operand2_ror, %function
cpu_arm7_tst_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
tst r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_teq_register_operand2_lsl
.type cpu_arm7_teq_register_operand2_lsl, %function
cpu_arm7_teq_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
teq r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_teq_register_operand2_lsr
.type cpu_arm7_teq_register_operand2_lsr, %function
cpu_arm7_teq_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
teq r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_teq_register_operand2_asr
.type cpu_arm7_teq_register_operand2_asr, %function
cpu_arm7_teq_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
teq r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_teq_register_operand2_ror
.type cpu_arm7_teq_register_operand2_ror, %function
cpu_arm7_teq_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
teq r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmp_register_operand2_lsl
.type cpu_arm7_cmp_register_operand2_lsl, %function
cpu_arm7_cmp_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmp r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmp_register_operand2_lsr
.type cpu_arm7_cmp_register_operand2_lsr, %function
cpu_arm7_cmp_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmp r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmp_register_operand2_asr
.type cpu_arm7_cmp_register_operand2_asr, %function
cpu_arm7_cmp_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmp r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmp_register_operand2_ror
.type cpu_arm7_cmp_register_operand2_ror, %function
cpu_arm7_cmp_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmp r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmn_register_operand2_lsl
.type cpu_arm7_cmn_register_operand2_lsl, %function
cpu_arm7_cmn_register_operand2_lsl:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmn r0,r1,lsl r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmn_register_operand2_lsr
.type cpu_arm7_cmn_register_operand2_lsr, %function
cpu_arm7_cmn_register_operand2_lsr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmn r0,r1,lsr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmn_register_operand2_asr
.type cpu_arm7_cmn_register_operand2_asr, %function
cpu_arm7_cmn_register_operand2_asr:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmn r0,r1,asr r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
.arm
.balign 4
.global cpu_arm7_cmn_register_operand2_ror
.type cpu_arm7_cmn_register_operand2_ror, %function
cpu_arm7_cmn_register_operand2_ror:
push {r4-r6,lr}
mov r4,r3
mrs r6,cpsr
msr cpsr_f,r2
cmn r0,r1,ror r2
mrs r1,cpsr
str r0,[r4]
str r1,[r4,#4]
msr cpsr_f,r6
pop {r4-r6,lr}
bx lr
