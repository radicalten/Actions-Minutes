#!/usr/bin/env python3
"""Generate a self-contained searchable debugger and full CSV, with no external assets."""
import argparse,csv,json
from pathlib import Path
from diagnostics import cpu_rows,assertion_rows,ROOT
p=argparse.ArgumentParser();p.add_argument('report',nargs='?',default='reports/resilient.json');p.add_argument('--output',default='reports/debugger.html');a=p.parse_args()
r=json.loads(Path(a.report).read_text());entries=r.get('diagnostics',{})
if not entries:
 for result in r.get('results',[r]):
  for name,entry in result.get('diagnostics',{}).items():
   if name not in entries or (name=='arm9' and result.get('id')==0) or (name=='arm7' and result.get('id')==1):entries[name]=entry
rows=[]
for name in ('arm9','arm7'):
 if name in entries:rows+=cpu_rows(entries[name])
events=assertion_rows(entries['assertions']) if 'assertions' in entries else []
groups=r.get('groups',r.get('results',[r]));payload={'vectors':rows,'events':events,'groups':groups,'score':r.get('score',{}),'rom':r.get('base_rom_sha256',r.get('rom_sha256','unknown'))}
# The static case source is a reference; recorded runtime values take precedence.
out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
keys=['cpu','id','name','status','a','b','initial','result','observed','result_xor','flags','observed_aux','mask','aux_masked_xor','primary_pass','aux_pass','function_pc','historical','runtime_differs_manifest','source','assembly_source']
with out.with_suffix('.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,keys,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
out.with_name(out.stem+'-assertions.json').write_text(json.dumps(events,indent=2)+'\n')
html='''<!doctype html><html><meta charset="utf-8"><title>NDS suite · vector debugger</title><style>
:root{color-scheme:dark;font:15px system-ui;background:#0d1523;color:#dce6f6}body{max-width:1400px;margin:32px auto;padding:0 24px}h1{font-size:32px;margin-bottom:6px}h2{font-size:21px}small,.muted{color:#9dadc7}input,select,button{background:#1b2a40;color:#e8f0ff;border:1px solid #42536c;border-radius:5px;padding:9px;margin:4px}input{width:310px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:9px;text-align:left;border-bottom:1px solid #29364c;vertical-align:top}th{color:#9dadc7}code,pre{font:12px ui-monospace,monospace}pre{white-space:pre-wrap;line-height:1.6}details{cursor:pointer}.PASS{color:#6ee7b7}.FAIL,.TRACE_INCONSISTENT{color:#fda4af}.NOT_RUN,.INTERRUPTED{color:#fcd34d}.box{background:#152137;border:1px solid #29364c;border-radius:10px;padding:18px;margin:18px 0}.cards{display:flex;gap:16px;flex-wrap:wrap}.card{background:#152137;border-radius:8px;padding:16px;min-width:180px}.card b{font-size:25px;display:block}summary{overflow-wrap:anywhere}#table{overflow-x:auto}a{color:#7dd3fc}</style>
<h1>NDS correctness debugger</h1><div class="muted">Recorded execution evidence · CPU vectors + C++ assertion events</div>
<div id="stats" class="cards box"></div><div id="provenance" class="muted"></div>
<div class="box"><b>How to read this report</b><p>Each CPU vector checks its primary result and, when its mask is nonzero, a masked auxiliary result (flags or a second value). Expand a row for inputs, expected/observed values, XOR differences and helper PC. NOT_RUN and INTERRUPTED are not passes. Auxiliary values with mask zero are not checked.</p><p>Original C++ groups are internally fail-fast. Their journal contains only executed, instrumented predicates; other assertions—including assembly checks—remain group-only/unknown. A group PASS does not create synthetic per-assertion passes. Historical CPU records are identified as prior-boot evidence.</p></div>
<input id="search" placeholder="Search family, case ID, hex input, source…"><select id="cpu"><option value="">Both CPUs</option><option>ARM9</option><option>ARM7</option></select><select id="status"><option value="">All outcomes</option><option>FAIL</option><option>PASS</option><option>NOT_RUN</option><option>INTERRUPTED</option></select><select id="family"><option value="">All families</option></select>
<p><button id="arm7fail">Show ARM7 failures</button><button id="prev">← Previous</button><button id="next">Next →</button> <span id="shown"></span></p><div id="table"></div>
<h2>Original-group execution ledger</h2><div id="groups" class="box"></div><h2>C++ assertion events</h2><div class="muted">Failure predicate expected zero. The expression is evaluated once; raw MMIO operands are not separately captured. Repeated events may share a source site.</div><div id="events"></div>
<script>const DATA=__DATA__;
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),hex=n=>n===undefined?'—':(n>>>0).toString(16).toUpperCase().padStart(8,'0');
$('provenance').textContent='ROM SHA-256: '+DATA.rom;
if(DATA.score.planned)$('stats').innerHTML=`<div class="card">Test groups<b>${DATA.score.passed} / ${DATA.score.planned}</b>${DATA.score.percent}% passed · unresolved is not a pass</div>`;
for(const cpu of ['ARM9','ARM7']){const a=DATA.vectors.filter(v=>v.cpu===cpu);$('stats').innerHTML+=`<div class="card">${cpu}<b>${a.filter(v=>v.status==='PASS').length} / ${a.length}</b>vectors passed · ${a.filter(v=>v.status==='FAIL').length} failed</div>`}
$('stats').innerHTML+=`<div class="card">Original C++<b>${DATA.events.length}</b>recorded assertion events</div>`;
for(const f of [...new Set(DATA.vectors.map(v=>v.name))]){let o=document.createElement('option');o.textContent=f;$('family').append(o)}
let page=0;function render(){const q=$('search').value.toLowerCase();const a=DATA.vectors.filter(v=>(!$('cpu').value||v.cpu===$('cpu').value)&&(!$('status').value||v.status===$('status').value)&&(!$('family').value||v.name===$('family').value)&&(!q||[v.id,v.name,v.source,hex(v.a),hex(v.b),hex(v.observed),hex(v.function_pc)].join(' ').toLowerCase().includes(q)));page=Math.min(page,Math.max(0,Math.ceil(a.length/100)-1));$('shown').textContent=`${a.length} matching vectors · ${a.filter(v=>v.status==='PASS').length} PASS / ${a.filter(v=>v.status==='FAIL').length} FAIL · page ${page+1} / ${Math.max(1,Math.ceil(a.length/100))}`;
$('table').innerHTML='<table><tr><th>CPU / Case</th><th>Outcome</th><th>Family / execution details</th><th>Primary expected → observed</th></tr>'+a.slice(page*100,page*100+100).map(v=>{const done=['PASS','FAIL','TRACE_INCONSISTENT'].includes(v.status);return `<tr><td>${v.cpu} / ${v.id}</td><td class="${v.status}">${v.status}</td><td><details><summary>${esc(v.name)}</summary><pre>${esc(`Inputs       A=${hex(v.a)} B=${hex(v.b)} initial=${hex(v.initial)}\nPrimary      expected=${hex(v.result)} observed=${done?hex(v.observed):'NOT AVAILABLE'} XOR=${hex(v.result_xor)}\nAuxiliary    expected=${hex(v.flags)} observed=${done?hex(v.observed_aux):'NOT AVAILABLE'} mask=${hex(v.mask)}\nMasked XOR   ${hex(v.aux_masked_xor)}${!v.mask?' (NOT CHECKED)':''}\nHelper PC    ${v.function_pc?hex(v.function_pc):'NOT EXECUTED'}\nEvidence     ${v.historical?'PRIOR BOOT (restored)':'captured boot'}\nSource       ${v.assembly_source} ${v.source||''}\nRuntime differs from static manifest: ${!!v.runtime_differs_manifest}`)}</pre></details></td><td><code>${hex(v.result)} → ${done?hex(v.observed):'—'}</code></td></tr>`}).join('')+'</table>'}
for(const id of ['search','cpu','status','family'])$(id).oninput=()=>{page=0;render()};$('arm7fail').onclick=()=>{$('cpu').value='ARM7';$('status').value='FAIL';$('family').value='';$('search').value='';page=0;render()};$('prev').onclick=()=>{page=Math.max(0,page-1);render()};$('next').onclick=()=>{page++;render()};render();
$('groups').innerHTML=DATA.groups.map(g=>`<div>${esc(g.id)} · ${esc(g.name||'group')} · <b>${esc(g.status)}</b>${g.id>1?' · detailed evidence: executed C++ events below; remaining checks group-only':''}</div>`).join('');
$('events').innerHTML='<table><tr><th>Event / Group / ID</th><th>Outcome</th><th>Failure predicate (expected zero)</th><th>Source</th></tr>'+DATA.events.map(e=>`<tr><td>${e.event} / ${e.group} / ${e.id}</td><td class="${e.status}">${e.status}</td><td><code>${esc(e.condition||'unknown predicate')}</code><br>observed ${hex(e.observed_condition)}</td><td>${esc(e.source||'unknown')}:${e.line}</td></tr>`).join('')+'</table>';
</script></html>'''
html=html.replace('__DATA__',json.dumps(payload,separators=(',',':')).replace('<','\\u003c'))
out.write_text(html);print(out, len(rows),'vectors;',len(events),'assertion events')
