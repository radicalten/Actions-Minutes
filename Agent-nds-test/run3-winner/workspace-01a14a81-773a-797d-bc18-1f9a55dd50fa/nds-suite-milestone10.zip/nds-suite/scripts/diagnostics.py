"""Binary execution evidence. Never synthesize PASS from a static coverage manifest."""
import hashlib,json,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MANIFEST=json.loads((ROOT/'src/generated/debug-manifest.json').read_text())
VECTORS=MANIFEST['vectors']
ASSEMBLY={}
for source in ('src/generated/cpu.s','src/generated/v5.s','src/generated/arm7.s'):
 for line,text in enumerate((ROOT/source).read_text().splitlines(),1):
  if text.startswith('cpu_') and text.endswith(':'):ASSEMBLY[text[:-1]]=f'{source}:{line}'
BASES={'arm9':0x02300000,'arm7':0x02340000,'assertions':0x02380000}
def resolve_path(value):
 path=Path(value);return path if path.is_absolute() else ROOT/path
def read_words(emu,base,count):return emu.memory.read(base,base+4*count,4,False)
def extract(emu,folder):
 folder=Path(folder).resolve();folder.mkdir(parents=True,exist_ok=True);found={}
 for name,base in BASES.items():
  head=read_words(emu,base,16)
  if name=='assertions':
   if head[:2]!=[0x41535235,1] or not 0<=head[3]<=4096:continue
   length=16+5*head[3]
  else:
   if head[0]!=0x43545235 or head[1]!=1 or head[9]!=40 or head[10]!=MANIFEST['crc32']:continue
   expected=MANIFEST['arm9_count' if name=='arm9' else 'arm7_count']
   if head[3]!=expected:continue
   length=16+10*head[3]
  words=read_words(emu,base,length);data=struct.pack('<'+'I'*length,*words)
  digest=hashlib.sha256(data).hexdigest();path=folder/(name+'-'+digest+'.bin')
  if not path.exists():
   temp=path.with_suffix('.tmp');temp.write_bytes(data);temp.replace(path)
  found[name]={'path':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),'sha256':digest,'header':head}
 return found

def restore(emu,saved):
 restored={}
 for name,entry in saved.items():
  data=resolve_path(entry['path']).read_bytes()
  if hashlib.sha256(data).hexdigest()!=entry['sha256']:raise ValueError('Corrupt saved diagnostics')
  words=list(struct.unpack('<'+'I'*(len(data)//4),data));base=BASES[name]
  if name!='assertions':
   if words[10]!=MANIFEST['crc32']:raise ValueError('Diagnostics manifest differs')
   if name=='arm7' and read_words(emu,base,16)[8]!=1:
    restored[name]='not_restored_live_arm7';continue
   words[11]=1 # historical record imported from the previous boot
  # Emulator is paused between frames, at the explicit RESTORE_WAIT gate.
  emu.memory.write(base,base+len(data),4,words);restored[name]='restored'
 emu.memory.write_long(0x023ed000,0x52455335)
 return restored

def checked_blob(entry):
 data=resolve_path(entry['path']).read_bytes()
 if hashlib.sha256(data).hexdigest()!=entry['sha256']:raise ValueError('Trace SHA256 mismatch')
 return data

def cpu_rows(entry):
 data=checked_blob(entry);words=struct.unpack('<'+'I'*(len(data)//4),data);h=words[:16]
 if h[0]!=0x43545235 or h[10]!=MANIFEST['crc32']:raise ValueError('Unknown CPU trace')
 result=[]
 for i in range(h[3]):
  r=words[16+10*i:26+10*i];v=(MANIFEST['arm7_vectors'] if h[2]==7 else VECTORS)[i]
  status={0:'NOT_RUN',1:'INTERRUPTED',2:'PASS',3:'FAIL'}.get(r[0],'INVALID')
  item=dict(v,assembly_source=ASSEMBLY.get(v['name'],'unknown'),cpu='ARM'+str(h[2]),status=status,observed=r[1] if r[0] in (2,3) else None,observed_aux=r[2] if r[0] in (2,3) else None,function_pc=r[3] if r[0] else None,historical=bool(h[11]))
  if r[0]:
   item.update(a=r[4],b=r[5],initial=r[6],result=r[7],flags=r[8],mask=r[9])
   item['runtime_differs_manifest']=any(item[k]!=v[k] for k in ('a','b','initial','result','flags','mask'))
  if r[0] in (2,3):
   item.update(result_xor=r[1]^r[7],aux_masked_xor=(r[2]^r[8])&r[9])
   item['primary_pass']=r[1]==r[7];item['aux_pass']=not item['aux_masked_xor'] if r[9] else None
   if (status=='PASS') != (item['primary_pass'] and not item['aux_masked_xor']):item['status']='TRACE_INCONSISTENT'
  result.append(item)
 return result

def summarize(found):
 output={}
 for name,entry in found.items():
  if name=='assertions':
   h=entry['header'];output[name]={'executed_predicates':h[3],'dropped_events':h[4],'granularity':'117 instrumented C++ sites; assembly/multiline checks not counted'};continue
  rows=cpu_rows(entry);families={}
  for r in rows:
   f=families.setdefault(r['name'],dict(name=r['name'],planned=0,passed=0,failed=0,not_run=0,interrupted=0))
   f['planned']+=1
   key={'PASS':'passed','FAIL':'failed','NOT_RUN':'not_run','INTERRUPTED':'interrupted'}.get(r['status'],'failed');f[key]+=1
  output[name]={'planned':len(rows),'passed':sum(r['status']=='PASS' for r in rows),'failed':sum(r['status']=='FAIL' for r in rows),
   'not_run':sum(r['status']=='NOT_RUN' for r in rows),'interrupted':sum(r['status']=='INTERRUPTED' for r in rows),
   'primary_checks_executed':sum(r['status'] in ('PASS','FAIL') for r in rows),
   'aux_checks_executed':sum(r['status'] in ('PASS','FAIL') and bool(r['mask']) for r in rows),
   'failures':[r for r in rows if r['status'] in ('FAIL','TRACE_INCONSISTENT')], 'families':list(families.values())}
 return output

GROUP_FILES={14:'ipcsync.cpp',15:'ipcfifo.cpp',16:'ipcfifo_irq.cpp',17:'sqrt.cpp',18:'sqrt.cpp',19:'division.cpp',20:'division.cpp',21:'division.cpp',22:'wramcnt.cpp',23:'vramcnt.cpp',24:'tcm.cpp'}
def assertion_rows(entry):
 data=checked_blob(entry);w=struct.unpack('<'+'I'*(len(data)//4),data)
 catalog=json.loads((ROOT/'src/generated/assertions.json').read_text())['instrumented']
 sites={(Path(s['source']).name,s['line']):s for s in catalog};rows=[]
 for i in range(w[3]):
  group,identifier,line,condition,status=w[16+5*i:21+5*i]
  site=sites.get((GROUP_FILES.get(group,''),line),{})
  rows.append(dict(event=i+1,group=group,id=identifier,line=line,observed_condition=condition,expected_condition=0,status='PASS' if status==1 else 'FAIL',**{k:v for k,v in site.items() if k!='line'}))
 return rows
